#!/usr/bin/env python3
"""
Complete live price checking workflow.

This script combines candidate identification with live price verification,
providing a complete solution to the AVG7 problem.
"""

import sys
import time
from typing import List, Dict, Optional
import pandas as pd

# Import our modules
from mtg_arbitrage.data_loader import load_data_with_names
from mtg_arbitrage import filter as mtg_filter
from mtg_arbitrage.utils import get_cardmarket_url, format_currency
from mtg_arbitrage.config import get_config

# Try to import scrapers
try:
    from fetch_live_listings_simple import SimpleBrowserScraper
    SIMPLE_SCRAPER_AVAILABLE = True
except ImportError:
    SIMPLE_SCRAPER_AVAILABLE = False

try:
    from fetch_live_listings_proxy import ProxyCardmarketScraper
    PROXY_SCRAPER_AVAILABLE = True
except ImportError:
    PROXY_SCRAPER_AVAILABLE = False

# Try to import manual verification
try:
    from utilities.manual_verification import format_candidate_info, open_candidates_for_verification
    MANUAL_VERIFICATION_AVAILABLE = True
except ImportError:
    MANUAL_VERIFICATION_AVAILABLE = False


class LivePriceChecker:
    """Complete live price checking system."""
    
    def __init__(self, use_simple_scraper: bool = True, use_proxies: bool = False, max_retries: int = 3, save_images: bool = True):
        """
        Initialize the live price checker.
        
        Args:
            use_simple_scraper: Use the simple browser headers scraper (recommended)
            use_proxies: Whether to attempt proxy scraping (fallback)
            max_retries: Maximum number of retry attempts for failed requests (default: 3)
            save_images: Whether to save card images (default: True)
        """
        self.scraper = None
        
        # Try simple scraper first (it works!)
        if use_simple_scraper and SIMPLE_SCRAPER_AVAILABLE:
            self.scraper = SimpleBrowserScraper(delay_range=(3.0, 5.0), max_retries=max_retries, save_images=save_images)
            self.scraper_type = "simple"
        # Fallback to proxy scraper
        elif use_proxies and PROXY_SCRAPER_AVAILABLE:
            self.scraper = ProxyCardmarketScraper(delay_range=(2.0, 4.0))
            self.scraper_type = "proxy"
        else:
            self.scraper_type = "none"
    
    def get_candidates(self, limit: int = 10) -> pd.DataFrame:
        """Get top arbitrage candidates."""
        print("📊 Loading candidate data...")
        
        # Load data
        data = load_data_with_names()
        if data.empty:
            print("❌ No data available")
            return pd.DataFrame()
        
        # Find candidates (using config defaults)
        from mtg_arbitrage.utils import DEFAULT_CONFIG
        candidates = mtg_filter.find_candidates(
            data,
            price_min=DEFAULT_CONFIG["price_min"],
            price_max=DEFAULT_CONFIG["price_max"],
            trend_discount_threshold=DEFAULT_CONFIG["trend_discount_threshold"]
        )
        
        # Filter out cards with missing expansion names
        if not candidates.empty:
            initial_count = len(candidates)
            candidates = candidates[
                (candidates['expansionName'].notna()) & 
                (candidates['expansionName'] != 'nan') &
                (candidates['expansionName'].astype(str) != 'nan')
            ]
            filtered_count = len(candidates)
            if initial_count > filtered_count:
                print(f"Filtered out {initial_count - filtered_count} cards with missing/invalid set names")
        
        return candidates.head(limit)
    
    def check_live_prices(self, card_data: dict) -> Optional[dict]:
        """
        Check live prices for a single card.
        
        Args:
            card_data: Card information dictionary
            
        Returns:
            Live price analysis or None if failed
        """
        if not self.scraper:
            return None
        
        # Check cache first
        from mtg_arbitrage.price_cache import get_global_cache
        cache = get_global_cache()
        
        card_id = card_data.get('idProduct')
        card_name = card_data.get('name', f"Card ID {card_id}")
        expansion_name = card_data.get('expansionName')
        
        # Try to get from cache
        cached_analysis = cache.get(card_id, expansion_name)
        if cached_analysis:
            print(f"   💾 Using cached prices (from previous pipeline)")
            return cached_analysis
        
        # Generate URL
        
        # Get configuration for URL filtering
        config = get_config()
        use_german_only = config.get('USE_GERMAN_SELLERS_ONLY', False)
        
        url = get_cardmarket_url(card_id, card_name, expansion_name, 'direct', include_filters=use_german_only)
        
        # Fetch listings
        result = self.scraper.fetch_listings(url, max_listings=10)
        listings = result.listings
        available_items_total = result.available_items_total
        
        if not listings:
            return None
        
        # Analyze listings
        prices = [listing.price for listing in listings if listing.price > 0]
        
        if not prices:
            return None
        
        # Find cheapest EX+ listing (EX, NM, MT conditions)
        good_condition_listings = [
            listing for listing in listings 
            if listing.condition.upper() in ['EX', 'NM', 'MT']
        ]
        
        cheapest_good_condition = None
        top_6_sellers = []
        if good_condition_listings:
            # Sort by price to get cheapest
            sorted_good = sorted(good_condition_listings, key=lambda x: x.price)
            cheapest_good_condition = sorted_good[0]
            
            # Get top 6 cheapest sellers (we'll use #2-5 for baseline avg, excluding cheapest)
            top_6_sellers = [
                {
                    'seller': listing.seller,
                    'price': listing.price,
                    'condition': listing.condition,
                    'quantity': listing.quantity,
                    'seller_country': listing.seller_country
                }
                for listing in sorted_good[:6]
            ]
        
        # Compare with historical data
        avg7 = card_data.get('AVG7', 0)
        trend = card_data.get('TREND', 0)
        
        # Generate alternative URL for user convenience
        if use_german_only:
            # If we used German-only for checking, provide all-sellers URL as alternative
            alt_url = get_cardmarket_url(card_id, card_name, expansion_name, 'direct', include_filters=False)
            alt_url_label = 'url_all_sellers'
        else:
            # If we used all sellers for checking, provide German-only URL as alternative
            alt_url = get_cardmarket_url(card_id, card_name, expansion_name, 'direct', include_filters=True)
            alt_url_label = 'url_german'
        
        analysis = {
            'card_name': card_name,
            'card_id': card_id,
            'url': url,  # Primary URL (used for price checking)
            alt_url_label: alt_url,  # Alternative URL (for user convenience)
            'total_listings': len(listings),
            'available_items_total': available_items_total,  # Liquidity indicator - total on Cardmarket
            'cheapest_current': min(prices),
            'average_current': sum(prices) / len(prices),
            'cheapest_good_condition': cheapest_good_condition.price if cheapest_good_condition else None,
            'cheapest_good_condition_details': {
                'price': cheapest_good_condition.price,
                'condition': cheapest_good_condition.condition,
                'seller': cheapest_good_condition.seller,
                'quantity': cheapest_good_condition.quantity,
                'seller_country': cheapest_good_condition.seller_country
            } if cheapest_good_condition else None,
            'top_6_sellers': top_6_sellers,  # Top 6 cheapest EX+ sellers (use #2-5 for baseline avg)
            'historical_avg7': avg7,
            'historical_trend': trend,
            'listings': [
                {
                    'price': listing.price,
                    'condition': listing.condition,
                    'seller': listing.seller,
                    'quantity': listing.quantity,
                    'seller_country': listing.seller_country
                }
                for listing in sorted(listings, key=lambda x: x.price)[:5]
            ]
        }
        
        # Calculate comparisons
        if avg7 > 0:
            analysis['cheapest_vs_avg7_pct'] = (min(prices) - avg7) / avg7 * 100
            analysis['average_vs_avg7_pct'] = (analysis['average_current'] - avg7) / avg7 * 100
            
            # Compare good condition price vs AVG7
            if cheapest_good_condition:
                analysis['good_condition_vs_avg7_pct'] = (cheapest_good_condition.price - avg7) / avg7 * 100
        
        if trend > 0:
            analysis['cheapest_vs_trend_pct'] = (min(prices) - trend) / trend * 100
            
            # Compare good condition price vs TREND  
            if cheapest_good_condition:
                analysis['good_condition_vs_trend_pct'] = (cheapest_good_condition.price - trend) / trend * 100
        
        # Cache the result for future use
        cache.set(card_id, analysis, expansion_name)
        
        return analysis
    
    def run_complete_analysis(self, limit: int = 5, check_live: bool = True) -> List[dict]:
        """
        Run complete analysis with both candidate identification and live checking.
        
        Args:
            limit: Number of candidates to analyze
            check_live: Whether to check live prices (requires proxies)
            
        Returns:
            List of analysis results
        """
        print("🃏 MTG Live Price Analysis")
        print("=" * 40)
        
        # Get candidates
        candidates = self.get_candidates(limit)
        
        if candidates.empty:
            print("❌ No candidates found")
            return []
        
        results = []
        
        for i, (_, card) in enumerate(candidates.iterrows(), 1):
            print(f"\n📋 Analyzing candidate {i}/{len(candidates)}: {card.get('name', 'Unknown')}")
            
            card_dict = card.to_dict()
            result = {
                'rank': i,
                'card_data': card_dict,
                'live_analysis': None
            }
            
            if check_live and self.scraper:
                print(f"   🔍 Checking live prices...")
                live_analysis = self.check_live_prices(card_dict)
                result['live_analysis'] = live_analysis
                
                if live_analysis:
                    cheapest = live_analysis['cheapest_current']
                    avg7 = live_analysis['historical_avg7']
                    cheapest_good = live_analysis['cheapest_good_condition']
                    
                    print(f"   💰 Cheapest current: €{cheapest:.2f}")
                    if cheapest_good:
                        good_details = live_analysis['cheapest_good_condition_details']
                        print(f"   🎯 Cheapest EX+: €{cheapest_good:.2f} ({good_details['condition']}) - {good_details['seller']}")
                    print(f"   📊 Historical AVG7: €{avg7:.2f}")
                    
                    # Focus on the good condition comparison
                    if cheapest_good and 'good_condition_vs_avg7_pct' in live_analysis:
                        diff_pct = live_analysis['good_condition_vs_avg7_pct']
                        if diff_pct <= 15:
                            print(f"   ✅ GOOD DEAL! EX+ price only {diff_pct:+.1f}% vs AVG7")
                        elif diff_pct <= 30:
                            print(f"   🟡 Fair price: EX+ price {diff_pct:+.1f}% vs AVG7")
                        else:
                            print(f"   ❌ Expensive: EX+ price {diff_pct:+.1f}% higher than AVG7")
                    elif cheapest_good:
                        print(f"   💡 EX+ available at €{cheapest_good:.2f}")
                    else:
                        print(f"   ⚠️  No EX+ condition listings found")
                else:
                    print(f"   ❌ Could not fetch live prices")
            else:
                print(f"   ⏭️  Skipping live price check")
            
            results.append(result)
            
            # Small delay between cards
            if i < len(candidates):
                time.sleep(1)
        
        return results
    
    def print_summary(self, results: List[dict]):
        """Print a summary of the analysis results."""
        print(f"\n📊 ANALYSIS SUMMARY")
        print("=" * 50)
        
        live_checked = sum(1 for r in results if r['live_analysis'] is not None)
        good_deals = 0
        excellent_deals = 0
        
        for result in results:
            card_data = result['card_data']
            live_analysis = result['live_analysis']
            
            card_name = card_data.get('name', 'Unknown')
            avg7 = card_data.get('AVG7', 0)
            trend = card_data.get('TREND', 0)
            
            print(f"\n{result['rank']}. {card_name}")
            print(f"   Historical: AVG7=€{avg7:.2f}, TREND=€{trend:.2f}")
            
            if live_analysis:
                current_cheapest = live_analysis['cheapest_current']
                cheapest_good = live_analysis['cheapest_good_condition']
                
                print(f"   Current: Cheapest=€{current_cheapest:.2f} ({live_analysis['total_listings']} listings)")
                
                if cheapest_good:
                    good_details = live_analysis['cheapest_good_condition_details']
                    print(f"   EX+ Best: €{cheapest_good:.2f} ({good_details['condition']}) - {good_details['seller']}")
                    
                    if 'good_condition_vs_avg7_pct' in live_analysis:
                        diff_pct = live_analysis['good_condition_vs_avg7_pct']
                        if diff_pct <= 15:
                            print(f"   🎯 EXCELLENT DEAL: EX+ only {diff_pct:+.1f}% vs AVG7")
                            excellent_deals += 1
                            good_deals += 1
                        elif diff_pct <= 30:
                            print(f"   🟡 Fair Deal: EX+ {diff_pct:+.1f}% vs AVG7")
                            good_deals += 1
                        else:
                            print(f"   ❌ Expensive: EX+ {diff_pct:+.1f}% higher than AVG7")
                else:
                    print(f"   ⚠️  No EX/NM/MT listings available")
            else:
                print(f"   ⚠️  No live data available")
        
        print(f"\n🎯 SUMMARY:")
        print(f"   Candidates analyzed: {len(results)}")
        print(f"   Live prices checked: {live_checked}")
        print(f"   Good deals found: {good_deals}")
        print(f"   Excellent deals (≤15% vs AVG7): {excellent_deals}")
        
        if excellent_deals > 0:
            print(f"\n🎉 Found {excellent_deals} excellent EX+ deals!")
            print(f"   These are cards available at near-historical prices")
        elif good_deals > 0:
            print(f"\n🟡 Found {good_deals} fair EX+ deals (15-30% premium)")
            print(f"   Consider if the premium is worth it for your strategy")
        elif live_checked > 0:
            print(f"\n💡 No great deals found:")
            print(f"   Current EX+ prices are significantly higher than AVG7")
            print(f"   This confirms the AVG7 problem - good deals already taken")


def main():
    """Main function."""
    
    # Parse command line arguments
    limit = 5
    check_live = True
    use_manual = False
    
    if len(sys.argv) > 1:
        try:
            limit = int(sys.argv[1])
        except ValueError:
            pass
    
    if len(sys.argv) > 2:
        mode = sys.argv[2].lower()
        if mode == "manual":
            use_manual = True
            check_live = False
        elif mode == "nocheck":
            check_live = False
    
    print("🃏 MTG Arbitrage - Live Price Checker")
    print("=" * 50)
    
    if use_manual and MANUAL_VERIFICATION_AVAILABLE:
        print("🌐 Using manual verification mode...")
        from utilities.manual_verification import get_top_candidates, open_candidates_for_verification
        
        candidates = get_top_candidates(limit)
        if not candidates.empty:
            open_candidates_for_verification(candidates, delay=2.0)
        return
    
    # Initialize checker (use simple scraper with exponential backoff)
    checker = LivePriceChecker(use_simple_scraper=True, use_proxies=False, max_retries=3)
    
    if check_live and not checker.scraper:
        print("⚠️  No scraper available")
        print("💡 Try manual mode: python live_price_check.py 5 manual")
        check_live = False
    elif check_live:
        print(f"✅ Using {checker.scraper_type} scraper for live price checking (with 1 retry on failure)")
    
    # Run analysis
    results = checker.run_complete_analysis(limit=limit, check_live=check_live)
    
    if results:
        checker.print_summary(results)
        
        # Save results
        import json
        output_file = f"data/live_analysis_{int(time.time())}.json"
        try:
            import os
            os.makedirs('data', exist_ok=True)
            
            # Convert pandas objects to serializable format
            serializable_results = []
            for result in results:
                serializable_result = {
                    'rank': result['rank'],
                    'card_data': {k: (v if pd.notna(v) else None) for k, v in result['card_data'].items()},
                    'live_analysis': result['live_analysis']
                }
                serializable_results.append(serializable_result)
            
            with open(output_file, 'w') as f:
                json.dump(serializable_results, f, indent=2)
            
            print(f"\n💾 Results saved to: {output_file}")
            
        except Exception as e:
            print(f"⚠️  Could not save results: {e}")
    
    else:
        print("❌ No results to display")
        
        print(f"\n💡 Usage:")
        print(f"  python live_price_check.py [limit] [mode]")
        print(f"  python live_price_check.py 5          # Check 5 candidates with live prices")
        print(f"  python live_price_check.py 3 manual   # Open 3 candidates in browser")
        print(f"  python live_price_check.py 10 nocheck # Show 10 candidates without live prices")


if __name__ == "__main__":
    main()
