"""
Filter functions to find candidate rare cards in price range with liquidity.
"""

import pandas as pd
from typing import List, Dict, Any
from .utils import DEFAULT_CONFIG

def find_candidates(
    data: pd.DataFrame,
    price_min: float = None,
    price_max: float = None,
    rarity: str = None,
    min_avg7: float = None,
    trend_discount_threshold: float = None
) -> pd.DataFrame:
    """
    Find candidate cards for arbitrage based on filtering criteria.
    
    Args:
        data: Price guide DataFrame with card data
        price_min: Minimum LOWEX+ price (default from config)
        price_max: Maximum LOWEX+ price (default from config)
        rarity: Target rarity (optional, not available in price guide data)
        min_avg7: Minimum AVG7 for liquidity check (default from config)
        trend_discount_threshold: Minimum discount from trend (default from config)
        
    Returns:
        DataFrame with candidate cards
    """
    # Use defaults from config if not provided
    if price_min is None:
        price_min = DEFAULT_CONFIG["price_min"]
    if price_max is None:
        price_max = DEFAULT_CONFIG["price_max"]
    if min_avg7 is None:
        min_avg7 = DEFAULT_CONFIG["min_avg7"]
    if trend_discount_threshold is None:
        trend_discount_threshold = DEFAULT_CONFIG["trend_discount_threshold"]
    
    if data.empty:
        print("No data to filter")
        return pd.DataFrame()
    
    # Work with the data directly since it already contains all needed information
    filtered = data.copy()
    print(f"Starting with {len(filtered)} total products")
    
    # Filter by rarity (skip if not available or not specified)
    if rarity and 'Rarity' in filtered.columns:
        filtered = filtered[filtered['Rarity'] == rarity]
        print(f"After rarity filter ({rarity}): {len(filtered)} products")
    elif rarity:
        print(f"Note: Rarity filter requested but rarity data not available in price guide")
    
    # Filter by price range (using AVG30 as the baseline price indicator)
    if 'AVG30' in filtered.columns:
        # Only include cards with monthly sales (AVG30 > 0)
        filtered = filtered[filtered['AVG30'] > 0]
        filtered = filtered[
            (filtered['AVG30'] >= price_min) & 
            (filtered['AVG30'] <= price_max)
        ]
        print(f"After price range filter (€{price_min}-€{price_max} AVG30): {len(filtered)} products")
    
    # Filter by recent sales activity (AVG7 > 0)
    if 'AVG7' in filtered.columns:
        filtered = filtered[filtered['AVG7'] > min_avg7]
        print(f"After liquidity filter (AVG7 > {min_avg7}): {len(filtered)} products")
    
    # Filter out cards with poor liquidity (only sell every 3+ months)
    # We want cards that sell at least weekly (AVG7 > 0) or have consistent monthly sales
    if 'AVG7' in filtered.columns and 'AVG30' in filtered.columns:
        before_liquidity = len(filtered)
        
        # Keep cards that either:
        # 1. Have weekly sales (AVG7 > 0), OR  
        # 2. Have monthly sales AND the monthly price is reasonable (not just outliers)
        liquid_cards = filtered[
            (filtered['AVG7'] > 0) |  # Weekly sales
            (
                (filtered['AVG30'] > 0) & 
                (filtered['AVG7'] == 0) &  # No weekly sales but...
                (abs(filtered['AVG30'] - filtered['TREND']) / filtered['TREND'] < 0.5)  # Monthly price is reasonable vs trend
            )
        ]
        
        # Additional filter: Remove cards where AVG30 exists but is much higher than TREND
        # (suggests very infrequent sales with outlier prices)
        if 'TREND' in liquid_cards.columns:
            liquid_cards = liquid_cards[
                (liquid_cards['AVG30'] == 0) |  # No monthly data, or
                (liquid_cards['AVG30'] <= liquid_cards['TREND'] * 2.0)  # Monthly price not more than 2x trend
            ]
        
        filtered = liquid_cards
        removed = before_liquidity - len(filtered)
        print(f"After liquidity filter (removed {removed} illiquid cards): {len(filtered)} products")
    
    # Filter by real discount (AVG7 should be at least X% below TREND)
    if 'TREND' in filtered.columns and 'AVG7' in filtered.columns:
        # Only keep cards with meaningful trend data (> 1 EUR to avoid penny stocks)
        filtered = filtered[filtered['TREND'] > 1.0]
        
        # Add reasonable upper bound for TREND to avoid extreme outliers
        max_reasonable_trend = price_max * 3  # Allow TREND up to 3x our price range
        before_trend_filter = len(filtered)
        filtered = filtered[filtered['TREND'] <= max_reasonable_trend]
        if len(filtered) < before_trend_filter:
            print(f"Filtered out {before_trend_filter - len(filtered)} cards with extreme TREND prices (>{max_reasonable_trend:.0f})")
        
        # CONDITION BIAS FILTER: Remove cards where AVG7 is suspiciously low vs AVG30
        # This filters out cards where recent sales were likely poor condition
        if 'AVG30' in filtered.columns and 'AVG7' in filtered.columns:
            before_condition_filter = len(filtered)
            
            # Keep cards where either:
            # 1. AVG7 is at least 75% of AVG30 (consistent pricing), OR
            # 2. AVG7 is 0 (no weekly data to compare)
            condition_safe = filtered[
                (filtered['AVG7'] == 0) |  # No weekly data
                (filtered['AVG7'] >= filtered['AVG30'] * 0.75)  # AVG7 within 25% of AVG30
            ]
            
            filtered = condition_safe
            removed = before_condition_filter - len(filtered)
            print(f"After condition bias filter (removed {removed} cards with suspicious AVG7 drops): {len(filtered)} products")
        
        # Calculate real discount using AVG30 vs TREND
        # AVG30 = Real average sales (all conditions) over 30 days
        # Using 5% threshold to catch more candidates; live EX price check filters further
        filtered['real_discount'] = (filtered['TREND'] - filtered['AVG30']) / filtered['TREND']
        filtered = filtered[filtered['real_discount'] >= trend_discount_threshold]
        print(f"After real discount filter (≥{trend_discount_threshold*100:.0f}% AVG30<TREND): {len(filtered)} products")
    
    # Sort by potential profit (highest real discount first)
    if 'real_discount' in filtered.columns:
        filtered = filtered.sort_values('real_discount', ascending=False)
    
    print(f"Found {len(filtered)} candidate cards")
    
    return filtered

def filter_by_expansion(df: pd.DataFrame, expansions: List[str]) -> pd.DataFrame:
    """Filter cards by specific expansions/sets."""
    if not expansions or df.empty:
        return df
    
    filtered = df[df['Expansion'].isin(expansions)]
    print(f"After expansion filter: {len(filtered)} products")
    return filtered

def filter_by_keywords(df: pd.DataFrame, keywords: List[str], column: str = 'Name') -> pd.DataFrame:
    """Filter cards by keywords in name or other column."""
    if not keywords or df.empty:
        return df
    
    # Create a pattern that matches any of the keywords
    pattern = '|'.join(keywords)
    filtered = df[df[column].str.contains(pattern, case=False, na=False)]
    print(f"After keyword filter: {len(filtered)} products")
    return filtered

def get_top_candidates(df: pd.DataFrame, limit: int = 20) -> pd.DataFrame:
    """Get top N candidates by trend discount."""
    if df.empty:
        return df
    
    if 'trend_discount' in df.columns:
        top = df.head(limit)
    else:
        # If no trend discount, sort by LOWEX+ price
        if 'LOWEX+' in df.columns:
            top = df.sort_values('LOWEX+', ascending=True).head(limit)
        else:
            top = df.head(limit)
    
    print(f"Selected top {len(top)} candidates")
    return top

def add_calculated_fields(df: pd.DataFrame) -> pd.DataFrame:
    """Add calculated fields useful for analysis."""
    if df.empty:
        return df
    
    df = df.copy()
    
    # Calculate various price ratios if columns exist
    if 'LOWEX+' in df.columns and 'TREND' in df.columns:
        df['lowex_to_trend_ratio'] = df['LOWEX+'] / df['TREND'].replace(0, float('inf'))
    
    if 'AVG1' in df.columns and 'AVG7' in df.columns:
        df['price_momentum'] = (df['AVG1'] - df['AVG7']) / df['AVG7'].replace(0, float('inf'))
    
    if 'LOW' in df.columns and 'LOWEX+' in df.columns:
        df['condition_premium'] = (df['LOWEX+'] - df['LOW']) / df['LOW'].replace(0, float('inf'))
    
    return df

def print_candidate_summary(df: pd.DataFrame) -> None:
    """Print a summary of candidate cards."""
    if df.empty:
        print("No candidates to summarize")
        return
    
    print(f"\n=== Candidate Summary ===")
    print(f"Total candidates: {len(df)}")
    
    if 'AVG7' in df.columns:
        print(f"Recent sales range: €{df['AVG7'].min():.2f} - €{df['AVG7'].max():.2f}")
        print(f"Average recent sales: €{df['AVG7'].mean():.2f}")
    
    if 'TREND' in df.columns:
        print(f"Market trend range: €{df['TREND'].min():.2f} - €{df['TREND'].max():.2f}")
        print(f"Average market trend: €{df['TREND'].mean():.2f}")
    
    if 'real_discount' in df.columns:
        print(f"Real discount range: {df['real_discount'].min()*100:.1f}% - {df['real_discount'].max()*100:.1f}%")
        print(f"Average discount: {df['real_discount'].mean()*100:.1f}%")
    
    if 'Expansion' in df.columns:
        print(f"Top expansions: {df['Expansion'].value_counts().head(3).to_dict()}")
    
    print("\n💡 Explanation:")
    print("- AVG30: Average real sales price over 30 days (all conditions)")  
    print("- Market trend: Current market trend price")
    print("- Real discount: How much AVG30 is below trend (≥5% to find candidates)")
    print("- Live check: EX/NM prices verified during scraping for final evaluation")
    print("="*25)
