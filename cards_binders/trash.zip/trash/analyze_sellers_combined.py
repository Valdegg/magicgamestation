"""Generate combined HTML with both good deals and rejected cards in tabs."""

def generate_html_with_rejected(seller_deals_data, results, threshold, output_file):
    """Generate single HTML with tabs for good deals and rejected cards."""
    from analyze_sellers import analyze_deals
    
    seller_deals = seller_deals_data
    total_deals = sum(len(data['deals']) for data in seller_deals.values())
    multi_deal_sellers = sum(1 for data in seller_deals.values() if len(data['deals']) >= 2)
    
    # Categorize rejected cards
    rejected_cards = {
        'expensive': [],
        'no_data': [],
        'below_threshold': []
    }
    
    for result in results.get('expensive_deals', []):
        rejected_cards['expensive'].append(result)
    
    for result in results.get('no_data', []):
        rejected_cards['no_data'].append(result)
    
    # Find cards with live data that didn't meet threshold
    cards_in_seller_deals = set()
    for seller_data in seller_deals.values():
        for deal in seller_data['deals']:
            cards_in_seller_deals.add(deal['card'])
    
    for result in results.get('good_deals', []) + results.get('excellent_deals', []):
        card_name = result.get('card_name')
        if card_name and card_name not in cards_in_seller_deals:
            live_data = result.get('live_data') or result.get('live_analysis')
            if live_data:
                rejected_cards['below_threshold'].append(result)
    
    total_rejected = sum(len(cards) for cards in rejected_cards.values())
    
    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MTG Market Scanner</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #6B5844 0%, #C5A572 25%, #E8D4A0 50%, #C5A572 75%, #6B5844 100%);
            min-height: 100vh; padding: 20px; color: #333;
        }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        header {{
            background: white; border-radius: 16px; padding: 30px; margin-bottom: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }}
        h1 {{ font-size: 2.5em; color: #2d3748; margin-bottom: 10px; }}
        
        /* Tab Navigation */
        .tabs {{
            display: flex; gap: 10px; margin-bottom: 30px;
        }}
        .tab {{
            background: white; border: none; padding: 15px 30px; border-radius: 12px;
            font-size: 1em; font-weight: 600; cursor: pointer;
            transition: all 0.3s; box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        .tab.active {{
            background: linear-gradient(135deg, #6B5844 0%, #C5A572 50%, #6B5844 100%);
            color: white;
        }}
        .tab:hover:not(.active) {{
            background: #f7fafc; transform: translateY(-2px);
        }}
        
        /* Tab Content */
        .tab-content {{
            display: none;
        }}
        .tab-content.active {{
            display: block;
        }}
        
        /* Stats */
        .stats {{ display: flex; gap: 20px; margin-top: 20px; flex-wrap: wrap; }}
        .stat {{
            background: linear-gradient(135deg, #6B5844 0%, #C5A572 50%, #6B5844 100%);
            color: white; padding: 15px 25px; border-radius: 12px; font-size: 0.9em;
        }}
        .stat-number {{ font-size: 2em; font-weight: bold; display: block; }}
        
        /* Seller Card */
        .seller-card {{
            background: white; border-radius: 16px; padding: 25px; margin-bottom: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08); transition: transform 0.2s;
        }}
        .seller-card:hover {{ transform: translateY(-4px); }}
        .seller-header {{
            display: flex; justify-content: space-between; align-items: center;
            padding-bottom: 20px; border-bottom: 2px solid #e2e8f0; margin-bottom: 20px;
        }}
        .seller-name {{ font-size: 1.5em; font-weight: bold; color: #2d3748; }}
        .seller-info {{ font-size: 0.9em; color: #718096; }}
        
        /* Deals */
        .deals {{ display: grid; gap: 15px; }}
        .deal {{
            background: linear-gradient(to right, #f7fafc 0%, #edf2f7 100%);
            border-radius: 12px; padding: 20px; border-left: 4px solid #48bb78;
            display: flex; gap: 15px;
            overflow: visible;
            position: relative;
        }}
        .deal-image {{ 
            width: 100px; height: auto; border-radius: 8px; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.15); flex-shrink: 0;
            transition: all 0.3s ease;
            cursor: pointer;
            position: relative;
            z-index: 1;
        }}
        .deal-image:hover {{ 
            transform: scale(3.5);
            box-shadow: 0 8px 24px rgba(0,0,0,0.35);
            z-index: 1000;
            border: 2px solid #48bb78;
        }}
        .deal-content {{ flex: 1; }}
        .deal-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }}
        .card-name {{ font-size: 1.2em; font-weight: 600; color: #2d3748; }}
        .price-tag {{ font-size: 1.5em; font-weight: bold; color: #48bb78; }}
        .deal-info {{ display: flex; gap: 20px; margin-bottom: 12px; font-size: 0.95em; color: #4a5568; flex-wrap: wrap; }}
        .badge {{ padding: 4px 12px; border-radius: 6px; font-size: 0.85em; font-weight: 600; }}
        .badge-excellent {{ background: #9ae6b4; color: #22543d; }}
        .badge-good {{ background: #fbd38d; color: #744210; }}
        .badge-expensive {{ background: #feb2b2; color: #742a2a; }}
        .discount {{ color: #48bb78; font-weight: 600; }}
        .card-links {{ display: flex; gap: 10px; flex-wrap: wrap; }}
        .btn {{
            display: inline-block; padding: 8px 16px; border-radius: 8px;
            text-decoration: none; font-size: 0.85em; font-weight: 600;
            transition: all 0.2s;
        }}
        .btn-cardmarket {{ background: #3182ce; color: white; }}
        .btn-cardmarket:hover {{ background: #2c5282; }}
        .btn-mtgstocks {{ background: #ed8936; color: white; }}
        .btn-mtgstocks:hover {{ background: #c05621; }}
        
        /* Rejected Cards Styling */
        .rejected-section {{
            background: white; border-radius: 16px; padding: 25px; margin-bottom: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }}
        .rejected-header {{
            font-size: 1.5em; font-weight: bold; color: #2d3748;
            margin-bottom: 15px; padding-bottom: 15px; border-bottom: 2px solid #e2e8f0;
        }}
        .rejected-description {{
            background: #f7fafc; padding: 15px; border-radius: 8px;
            margin-bottom: 20px; color: #4a5568; line-height: 1.6;
        }}
        .rejected-card {{
            background: #f7fafc; border-radius: 12px; padding: 20px;
            border-left: 4px solid #cbd5e0; margin-bottom: 15px;
            display: flex; gap: 15px;
            overflow: visible;
            position: relative;
        }}
        
        /* Filters */
        .filters {{
            background: white; border-radius: 16px; padding: 20px; margin-bottom: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }}
        .filters h3 {{
            font-size: 1.2em; margin-bottom: 15px; color: #2d3748;
        }}
        .filter-section {{
            margin-bottom: 20px;
        }}
        .filter-section h4 {{
            font-size: 1em; margin-bottom: 10px; color: #4a5568;
        }}
        .filter-group {{
            display: flex; gap: 10px; flex-wrap: wrap; align-items: center;
        }}
        .checkbox-group {{
            display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 10px; max-height: 200px; overflow-y: auto;
            padding: 10px; background: #f7fafc; border-radius: 8px;
        }}
        .filter-checkbox {{
            display: flex; align-items: center; gap: 6px;
            font-size: 0.9em; cursor: pointer;
        }}
        .filter-checkbox input {{
            cursor: pointer;
        }}
        .filter-select {{
            padding: 10px 15px; border: 2px solid #e2e8f0; border-radius: 8px;
            font-size: 0.95em; background: white; cursor: pointer;
            transition: border-color 0.2s;
        }}
        .filter-select:hover {{
            border-color: #C5A572;
        }}
        .filter-select:focus {{
            outline: none; border-color: #6B5844;
        }}
        .price-input {{
            width: 100px; padding: 10px 15px; border: 2px solid #e2e8f0; border-radius: 8px;
            font-size: 0.95em; background: white;
            transition: border-color 0.2s;
        }}
        .price-input:hover {{
            border-color: #C5A572;
        }}
        .price-input:focus {{
            outline: none; border-color: #6B5844;
        }}
        .set-badge {{
            display: inline-block; padding: 4px 10px; background: #e2e8f0;
            border-radius: 6px; font-size: 0.85em; color: #4a5568; font-weight: 500;
        }}
        .source-badge {{
            display: inline-block; padding: 4px 10px; background: #C5A572;
            border-radius: 6px; font-size: 0.85em; color: white; font-weight: 600;
        }}
        .source-badge-wishlist {{ background: #9F7AEA; }}
        .source-badge-deck {{ background: #ED8936; }}
        .source-badge-reserved {{ background: #E53E3E; }}
        .source-badge-candidates {{ background: #38B2AC; }}
        .country-badge {{
            display: inline-block; padding: 4px 10px; background: #4299e1;
            border-radius: 6px; font-size: 0.85em; color: white; font-weight: 500;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🃏 MTG Market Scanner</h1>
            <div class="stats">
                <div class="stat">
                    <span class="stat-number">{total_deals}</span>
                    Good Deals
                </div>
                <div class="stat">
                    <span class="stat-number">{len(seller_deals)}</span>
                    Sellers
                </div>
                <div class="stat">
                    <span class="stat-number">{total_rejected}</span>
                    Rejected Cards
                </div>
                <div class="stat">
                    <span class="stat-number">≥{threshold:.0f}%</span>
                    Discount Threshold
                </div>
            </div>
        </header>
        
        <div class="tabs">
            <button class="tab active" onclick="showTab('deals')">✅ Good Deals ({total_deals})</button>
            <button class="tab" onclick="showTab('rejected')">❌ Rejected Cards ({total_rejected})</button>
        </div>
        
        <div class="filters">
            <h3>🔍 Filters</h3>
            
            <div class="filter-section">
                <h4>📦 Sets (select multiple)</h4>
                <div id="set-checkboxes" class="checkbox-group">
                    <!-- Populated by JavaScript -->
                </div>
            </div>
            
            <div class="filter-section">
                <h4>📋 Source (select multiple)</h4>
                <div id="source-checkboxes" class="checkbox-group">
                    <!-- Populated by JavaScript -->
                </div>
            </div>
            
            <div class="filter-section">
                <h4>🌍 Country (select multiple)</h4>
                <div id="country-checkboxes" class="checkbox-group">
                    <!-- Populated by JavaScript -->
                </div>
            </div>
            
            <div class="filter-section">
                <h4>💰 Price Range (€)</h4>
                <div class="filter-group">
                    <label for="price-min">Min:</label>
                    <input type="number" id="price-min" class="price-input" placeholder="0" min="0" step="0.01" oninput="filterCards()">
                    <label for="price-max">Max:</label>
                    <input type="number" id="price-max" class="price-input" placeholder="999" min="0" step="0.01" oninput="filterCards()">
                </div>
            </div>
            
            <div class="filter-section">
                <h4>🔄 Sort By</h4>
                <div class="filter-group">
                    <select id="sort-by" class="filter-select" onchange="sortCards()">
                        <option value="default">Default (by seller)</option>
                        <option value="price-low">Price: Low to High</option>
                        <option value="price-high">Price: High to Low</option>
                        <option value="discount-high">Discount: Highest First</option>
                        <option value="discount-low">Discount: Lowest First</option>
                        <option value="name-az">Card Name: A-Z</option>
                        <option value="name-za">Card Name: Z-A</option>
                        <option value="set-az">Set: A-Z</option>
                        <option value="quality">Quality: Excellent → Good</option>
                    </select>
                </div>
            </div>
            
            <div class="filter-section">
                <h4>👤 Seller</h4>
                <div class="filter-group">
                    <select id="seller-filter" class="filter-select" onchange="filterCards()">
                        <option value="">All Sellers</option>
                    </select>
                </div>
            </div>
            
            <div class="filter-group">
                <button onclick="selectAllSets()" class="btn btn-cardmarket">Select All Sets</button>
                <button onclick="deselectAllSets()" class="btn btn-mtgstocks">Clear Sets</button>
                <button onclick="resetFilters()" class="btn btn-cardmarket">Reset All Filters</button>
            </div>
        </div>
'''
    
    # Good Deals Tab
    html += '''
        <div id="deals-tab" class="tab-content active">
'''
    
    if seller_deals:
        for seller_name, seller_data in seller_deals.items():
            deals_html = ''
            for deal in seller_data['deals']:
                category_class = 'excellent' if deal['category'] == 'excellent_deals' else 'good' if deal['category'] == 'good_deals' else 'expensive'
                category_label = '⭐ Excellent' if deal['category'] == 'excellent_deals' else '✅ Good' if deal['category'] == 'good_deals' else '❌ Expensive'
                
                set_name = deal.get('set', 'Unknown Set')
                source = deal.get('source', 'Unknown')
                
                # Determine source badge class
                source_class = ''
                if 'Deck' in source:
                    source_class = 'source-badge-deck'
                elif 'Reserved' in source:
                    source_class = 'source-badge-reserved'
                elif 'Wishlist' in source and 'Candidates' not in source:
                    source_class = 'source-badge-wishlist'
                elif 'Candidates' in source:
                    source_class = 'source-badge-candidates'
                
                # Quality score for sorting (excellent=2, good=1, expensive=0)
                quality_score = 2 if category_class == 'excellent' else (1 if category_class == 'good' else 0)
                
                seller_country = deal.get('seller_country', 'Unknown')
                
                deals_html += f'''
            <div class="deal" data-set="{set_name}" data-seller="{seller_name}" data-source="{source}" data-country="{seller_country}" data-price="{deal['price']:.2f}" 
                 data-discount="{deal['discount']:.2f}" data-card-name="{deal['card']}" data-quality="{quality_score}">
                <img src="../card_images/{deal['card'].replace(" ", "_").replace(",", "").replace("'", "")}.jpg" alt="{deal['card']}" class="deal-image" onerror="this.style.display='none'">
                <div class="deal-content">
                    <div class="deal-header">
                        <span class="card-name">{deal['card']}</span>
                        <span class="price-tag">€{deal['price']:.2f}</span>
                    </div>
                    <div class="deal-info">
                        <span class="badge badge-{category_class}">{category_label}</span>
                        <span>{deal['condition']}</span>
                        <span class="discount">-{deal['discount']:.1f}% vs avg</span>
                        <span>(Avg of #2-5: €{deal['avg_baseline']:.2f})</span>
                        <span class="set-badge">{set_name}</span>
                        <span class="source-badge {source_class}">📋 {source}</span>
                        <span class="country-badge">🌍 {seller_country}</span>
                    </div>
                    <div class="card-links">
                        <a href="{deal['card_url']}" target="_blank" class="btn btn-cardmarket">View on Cardmarket</a>
                        <a href="{deal['mtgstocks_search']}" target="_blank" class="btn btn-mtgstocks">Price History</a>
                    </div>
                </div>
            </div>
'''
            
            html += f'''
        <div class="seller-card">
            <div class="seller-header">
                <div>
                    <div class="seller-name">{seller_name}</div>
                    <div class="seller-info">{len(seller_data['deals'])} deal{"s" if len(seller_data['deals']) > 1 else ""}</div>
                </div>
                <a href="{seller_data['url']}" target="_blank" class="btn btn-cardmarket">View Seller Profile</a>
            </div>
            <div class="deals">
                {deals_html}
            </div>
        </div>
'''
    else:
        html += '<div class="seller-card"><p>No good deals found.</p></div>'
    
    html += '</div>'  # End deals tab
    
    # Rejected Cards Tab
    html += '''
        <div id="rejected-tab" class="tab-content">
'''
    
    if total_rejected > 0:
        # Expensive cards
        if rejected_cards['expensive']:
            html += f'''
        <div class="rejected-section">
            <div class="rejected-header">❌ Expensive ({len(rejected_cards['expensive'])} cards)</div>
            <div class="rejected-description">
                These cards have live EX+ prices above the adjusted TREND (TREND + 20% condition premium).
                Not worth buying at current market prices.
            </div>
            <div class="cards">
'''
            for result in rejected_cards['expensive']:
                card = result.get('card_name', 'Unknown')
                expansion = result.get('expansion', 'Unknown')
                source = result.get('source', 'Unknown')
                trend = result.get('historical_data', {}).get('trend', 0)
                live_data = result.get('live_data') or {}
                ex_price = live_data.get('cheapest_good_condition', 0)
                url = live_data.get('url', '#')
                
                # Determine source badge class
                source_class = ''
                if 'Deck' in source:
                    source_class = 'source-badge-deck'
                elif 'Reserved' in source:
                    source_class = 'source-badge-reserved'
                elif 'Wishlist' in source and 'Candidates' not in source:
                    source_class = 'source-badge-wishlist'
                elif 'Candidates' in source:
                    source_class = 'source-badge-candidates'
                
                html += f'''
                <div class="rejected-card">
                    <img src="../card_images/{card.replace(" ", "_").replace(",", "").replace("'", "")}.jpg" alt="{card}" class="deal-image" onerror="this.style.display='none'">
                    <div class="deal-content">
                        <div class="deal-header">
                            <span class="card-name">{card}</span>
                            <span class="price-tag">€{ex_price:.2f}</span>
                        </div>
                        <div class="deal-info">
                            <span>EX+ price above TREND+20% (€{trend * 1.20:.2f})</span>
                            <span>TREND: €{trend:.2f}</span>
                            <span class="set-badge">{expansion}</span>
                            <span class="source-badge {source_class}">📋 {source}</span>
                        </div>
                        <div class="card-links">
                            <a href="{url}" target="_blank" class="btn btn-cardmarket">View on Cardmarket</a>
                        </div>
                    </div>
                </div>
'''
            html += '</div></div>'
        
        # Below threshold
        if rejected_cards['below_threshold']:
            html += f'''
        <div class="rejected-section">
            <div class="rejected-header">📊 Below Threshold ({len(rejected_cards['below_threshold'])} cards)</div>
            <div class="rejected-description">
                These cards are good deals (below TREND) but no individual seller offers ≥{threshold:.0f}% discount vs the baseline average.
                All sellers cluster at similar prices.
            </div>
            <div class="cards">
'''
            for result in rejected_cards['below_threshold']:
                card = result.get('card_name', 'Unknown')
                expansion = result.get('expansion', 'Unknown')
                source = result.get('source', 'Unknown')
                live_data = result.get('live_data') or {}
                ex_price = live_data.get('cheapest_good_condition', 0)
                url = live_data.get('url', '#')
                
                # Determine source badge class
                source_class = ''
                if 'Deck' in source:
                    source_class = 'source-badge-deck'
                elif 'Reserved' in source:
                    source_class = 'source-badge-reserved'
                elif 'Wishlist' in source and 'Candidates' not in source:
                    source_class = 'source-badge-wishlist'
                elif 'Candidates' in source:
                    source_class = 'source-badge-candidates'
                
                html += f'''
                <div class="rejected-card">
                    <img src="../card_images/{card.replace(" ", "_").replace(",", "").replace("'", "")}.jpg" alt="{card}" class="deal-image" onerror="this.style.display='none'">
                    <div class="deal-content">
                        <div class="deal-header">
                            <span class="card-name">{card}</span>
                            <span class="price-tag">€{ex_price:.2f}</span>
                        </div>
                        <div class="deal-info">
                            <span>Good price but sellers cluster together</span>
                            <span class="set-badge">{expansion}</span>
                            <span class="source-badge {source_class}">📋 {source}</span>
                        </div>
                        <div class="card-links">
                            <a href="{url}" target="_blank" class="btn btn-cardmarket">View on Cardmarket</a>
                        </div>
                    </div>
                </div>
'''
            html += '</div></div>'
        
        # No data
        if rejected_cards['no_data']:
            html += f'''
        <div class="rejected-section">
            <div class="rejected-header">⚠️ No Live Data ({len(rejected_cards['no_data'])} cards)</div>
            <div class="rejected-description">
                Could not scrape live prices for these cards. Usually due to no listings, scraping failure, or name/set mismatch.
            </div>
            <div class="cards">
'''
            for result in rejected_cards['no_data']:
                card = result.get('card_name', 'Unknown')
                expansion = result.get('expansion', 'Unknown')
                source = result.get('source', 'Unknown')
                
                # Determine source badge class
                source_class = ''
                if 'Deck' in source:
                    source_class = 'source-badge-deck'
                elif 'Reserved' in source:
                    source_class = 'source-badge-reserved'
                elif 'Wishlist' in source and 'Candidates' not in source:
                    source_class = 'source-badge-wishlist'
                elif 'Candidates' in source:
                    source_class = 'source-badge-candidates'
                
                html += f'''
                <div class="rejected-card">
                    <img src="../card_images/{card.replace(" ", "_").replace(",", "").replace("'", "")}.jpg" alt="{card}" class="deal-image" onerror="this.style.display='none'">
                    <div class="deal-content">
                        <div class="card-name">{card}</div>
                        <div class="deal-info">
                            <span class="set-badge">{expansion}</span>
                            <span>No live data available</span>
                            <span class="source-badge {source_class}">📋 {source}</span>
                        </div>
                    </div>
                </div>
'''
            html += '</div></div>'
    else:
        html += '<div class="rejected-section"><p>No rejected cards - all candidates were good deals!</p></div>'
    
    html += '</div>'  # End rejected tab
    
    # JavaScript for tabs and filters
    html += '''
    </div>
    
    <script>
        function showTab(tabName) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
            document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
            
            // Show selected tab
            document.getElementById(tabName + '-tab').classList.add('active');
            event.target.classList.add('active');
        }
        
        // Populate filter controls on page load
        window.addEventListener('DOMContentLoaded', function() {
            const deals = document.querySelectorAll('.deal[data-set]');
            const sets = new Set();
            const sellers = new Set();
            const sources = new Set();
            const countries = new Set();
            
            deals.forEach(deal => {
                const set = deal.getAttribute('data-set');
                const seller = deal.getAttribute('data-seller');
                const source = deal.getAttribute('data-source');
                const country = deal.getAttribute('data-country');
                if (set) sets.add(set);
                if (seller) sellers.add(seller);
                if (source) sources.add(source);
                if (country) countries.add(country);
            });
            
            // Populate set checkboxes
            const setCheckboxes = document.getElementById('set-checkboxes');
            Array.from(sets).sort().forEach(set => {
                const label = document.createElement('label');
                label.className = 'filter-checkbox';
                
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.value = set;
                checkbox.checked = true;  // All selected by default
                checkbox.onchange = filterCards;
                
                const text = document.createTextNode(set);
                
                label.appendChild(checkbox);
                label.appendChild(text);
                setCheckboxes.appendChild(label);
            });
            
            // Populate source checkboxes
            const sourceCheckboxes = document.getElementById('source-checkboxes');
            const sourceOrder = ['Reserved List', 'Deck Wishlist', 'Wishlist', 'Candidates', 'Price Candidates'];
            const sortedSources = Array.from(sources).sort((a, b) => {
                const indexA = sourceOrder.indexOf(a);
                const indexB = sourceOrder.indexOf(b);
                if (indexA === -1 && indexB === -1) return a.localeCompare(b);
                if (indexA === -1) return 1;
                if (indexB === -1) return -1;
                return indexA - indexB;
            });
            
            sortedSources.forEach(source => {
                const label = document.createElement('label');
                label.className = 'filter-checkbox';
                
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.value = source;
                checkbox.checked = true;  // All selected by default
                checkbox.onchange = filterCards;
                
                // Add emoji based on source
                let emoji = '📋';
                if (source.includes('Reserved')) emoji = '🔴';
                else if (source.includes('Deck')) emoji = '🟠';
                else if (source.includes('Wishlist') && !source.includes('Deck')) emoji = '🟣';
                else if (source.includes('Candidates')) emoji = '🔵';
                
                const text = document.createTextNode(` ${emoji} ${source}`);
                
                label.appendChild(checkbox);
                label.appendChild(text);
                sourceCheckboxes.appendChild(label);
            });
            
            // Populate country checkboxes
            const countryCheckboxes = document.getElementById('country-checkboxes');
            Array.from(countries).sort().forEach(country => {
                const label = document.createElement('label');
                label.className = 'filter-checkbox';
                
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.value = country;
                checkbox.checked = true;  // All selected by default
                checkbox.onchange = filterCards;
                
                const text = document.createTextNode(` ${country}`);
                
                label.appendChild(checkbox);
                label.appendChild(text);
                countryCheckboxes.appendChild(label);
            });
            
            // Populate seller filter
            const sellerFilter = document.getElementById('seller-filter');
            Array.from(sellers).sort().forEach(seller => {
                const option = document.createElement('option');
                option.value = seller;
                option.textContent = seller;
                sellerFilter.appendChild(option);
            });
        });
        
        function filterCards() {
            // Get selected sets from checkboxes
            const selectedSets = new Set();
            document.querySelectorAll('#set-checkboxes input[type="checkbox"]:checked').forEach(cb => {
                selectedSets.add(cb.value);
            });
            
            // Get selected sources from checkboxes
            const selectedSources = new Set();
            document.querySelectorAll('#source-checkboxes input[type="checkbox"]:checked').forEach(cb => {
                selectedSources.add(cb.value);
            });
            
            // Get selected countries from checkboxes
            const selectedCountries = new Set();
            document.querySelectorAll('#country-checkboxes input[type="checkbox"]:checked').forEach(cb => {
                selectedCountries.add(cb.value);
            });
            
            const sellerFilter = document.getElementById('seller-filter').value;
            const priceMin = parseFloat(document.getElementById('price-min').value) || 0;
            const priceMax = parseFloat(document.getElementById('price-max').value) || Infinity;
            
            // Filter deals in both original seller view and sorted view
            const deals = document.querySelectorAll('.deal[data-set]');
            const sellerCards = document.querySelectorAll('.seller-card');
            
            let visibleCount = 0;
            
            deals.forEach(deal => {
                const dealSet = deal.getAttribute('data-set');
                const dealSeller = deal.getAttribute('data-seller');
                const dealSource = deal.getAttribute('data-source');
                const dealCountry = deal.getAttribute('data-country');
                const dealPrice = parseFloat(deal.getAttribute('data-price')) || 0;
                
                // Match if set is in selected sets (or all sets if none selected)
                const setMatch = selectedSets.size === 0 || selectedSets.has(dealSet);
                const sourceMatch = selectedSources.size === 0 || selectedSources.has(dealSource);
                const countryMatch = selectedCountries.size === 0 || selectedCountries.has(dealCountry);
                const sellerMatch = !sellerFilter || dealSeller === sellerFilter;
                const priceMatch = dealPrice >= priceMin && dealPrice <= priceMax;
                
                if (setMatch && sourceMatch && countryMatch && sellerMatch && priceMatch) {
                    deal.style.display = 'flex';
                    visibleCount++;
                } else {
                    deal.style.display = 'none';
                }
            });
            
            // Hide seller cards that have no visible deals (only in seller-grouped view)
            // Don't toggle seller cards if we're in sorted view
            const dealsTab = document.getElementById('deals-tab');
            const sortedContainer = dealsTab ? dealsTab.querySelector('.sorted-deals-container') : null;
            const inSortedMode = sortedContainer && sortedContainer.style.display !== 'none';
            
            if (!inSortedMode) {
                sellerCards.forEach(sellerCard => {
                    const visibleDeals = sellerCard.querySelectorAll('.deal[data-set]:not([style*="display: none"])');
                    if (visibleDeals.length > 0) {
                        sellerCard.style.display = 'block';
                    } else {
                        sellerCard.style.display = 'none';
                    }
                });
            }
            
            console.log(`Filtered: ${visibleCount} deals visible (${selectedSets.size} sets selected, €${priceMin}-€${priceMax === Infinity ? '∞' : priceMax})`);
        }
        
        function selectAllSets() {
            document.querySelectorAll('#set-checkboxes input[type="checkbox"]').forEach(cb => {
                cb.checked = true;
            });
            filterCards();
        }
        
        function deselectAllSets() {
            document.querySelectorAll('#set-checkboxes input[type="checkbox"]').forEach(cb => {
                cb.checked = false;
            });
            filterCards();
        }
        
        function selectAllSources() {
            document.querySelectorAll('#source-checkboxes input[type="checkbox"]').forEach(cb => {
                cb.checked = true;
            });
            filterCards();
        }
        
        function deselectAllSources() {
            document.querySelectorAll('#source-checkboxes input[type="checkbox"]').forEach(cb => {
                cb.checked = false;
            });
            filterCards();
        }
        
        function sortCards() {
            const sortBy = document.getElementById('sort-by').value;
            console.log('sortCards called with:', sortBy);
            
            const dealsTab = document.getElementById('deals-tab');
            if (!dealsTab) {
                console.error('deals-tab not found!');
                return;
            }
            
            const sellerCards = Array.from(dealsTab.querySelectorAll('.seller-card'));
            console.log('Found seller cards:', sellerCards.length);
            
            if (sortBy === 'default') {
                // Default: keep original seller grouping
                // Hide sorted container if it exists
                const sortedContainer = dealsTab.querySelector('.sorted-deals-container');
                if (sortedContainer) {
                    sortedContainer.style.display = 'none';
                }
                // Show original seller cards
                sellerCards.forEach(card => card.style.display = 'block');
                // Trigger filter to restore visibility
                filterCards();
                return;
            }
            
            // Collect all deals across all sellers
            const allDeals = [];
            sellerCards.forEach(sellerCard => {
                const deals = Array.from(sellerCard.querySelectorAll('.deal'));
                deals.forEach(deal => {
                    allDeals.push({
                        element: deal,
                        price: parseFloat(deal.getAttribute('data-price')) || 0,
                        discount: parseFloat(deal.getAttribute('data-discount')) || 0,
                        cardName: deal.getAttribute('data-card-name') || '',
                        set: deal.getAttribute('data-set') || '',
                        quality: parseInt(deal.getAttribute('data-quality')) || 0,
                        sellerCard: sellerCard
                    });
                });
            });
            console.log('Total deals collected:', allDeals.length);
            console.log('Sample deal data:', allDeals[0]);
            
            // Sort based on selected option
            allDeals.sort((a, b) => {
                switch(sortBy) {
                    case 'price-low':
                        return a.price - b.price;
                    case 'price-high':
                        return b.price - a.price;
                    case 'discount-high':
                        return b.discount - a.discount;
                    case 'discount-low':
                        return a.discount - b.discount;
                    case 'name-az':
                        return a.cardName.localeCompare(b.cardName);
                    case 'name-za':
                        return b.cardName.localeCompare(a.cardName);
                    case 'set-az':
                        return a.set.localeCompare(b.set);
                    case 'quality':
                        // Quality first (high to low), then discount (high to low)
                        if (b.quality !== a.quality) {
                            return b.quality - a.quality;
                        }
                        return b.discount - a.discount;
                    default:
                        return 0;
                }
            });
            
            // Hide all original seller cards
            sellerCards.forEach(card => card.style.display = 'none');
            
            // Create a single container for sorted deals
            let sortedContainer = dealsTab.querySelector('.sorted-deals-container');
            if (!sortedContainer) {
                sortedContainer = document.createElement('div');
                sortedContainer.className = 'sorted-deals-container';
                sortedContainer.style.cssText = 'background: white; border-radius: 16px; padding: 25px; margin-bottom: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);';
                dealsTab.appendChild(sortedContainer);
            }
            
            // Clear and repopulate
            const sortLabel = {
                'price-low': 'Price: Low → High',
                'price-high': 'Price: High → Low',
                'discount-high': 'Discount: High → Low',
                'discount-low': 'Discount: Low → High',
                'name-az': 'Name: A → Z',
                'name-za': 'Name: Z → A',
                'set-az': 'Set: A → Z',
                'quality': 'Quality (Excellent → Good)'
            }[sortBy] || 'Sorted';
            
            sortedContainer.innerHTML = `<div style="background: linear-gradient(135deg, #6B5844, #C5A572); color: white; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                <h2 style="margin: 0; font-size: 1.3em;">🔄 Sorted View: ${sortLabel}</h2>
                <p style="margin: 5px 0 0 0; font-size: 0.9em; opacity: 0.9;">Cards are sorted and ungrouped by seller</p>
            </div><div class="deals" style="display: grid; gap: 15px;"></div>`;
            const dealsContainer = sortedContainer.querySelector('.deals');
            
            allDeals.forEach(item => {
                const clonedDeal = item.element.cloneNode(true);
                dealsContainer.appendChild(clonedDeal);
            });
            
            console.log('Sorted container populated with', allDeals.length, 'deals');
            sortedContainer.style.display = 'block';
            console.log('Sorted container should now be visible');
            
            // Apply current filters to sorted view
            filterCards();
        }
        
        function resetFilters() {
            // Select all sets and sources by default
            selectAllSets();
            selectAllSources();
            // Clear seller filter
            document.getElementById('seller-filter').value = '';
            // Clear price filters
            document.getElementById('price-min').value = '';
            document.getElementById('price-max').value = '';
            // Reset sort
            document.getElementById('sort-by').value = 'default';
            
            // Show original seller cards, hide sorted container
            const dealsTab = document.getElementById('deals-tab');
            const sortedContainer = dealsTab.querySelector('.sorted-deals-container');
            if (sortedContainer) {
                sortedContainer.style.display = 'none';
            }
            document.querySelectorAll('.seller-card').forEach(card => {
                card.style.display = 'block';
            });
        }
    </script>
</body>
</html>
'''
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html)
    
    return output_file

