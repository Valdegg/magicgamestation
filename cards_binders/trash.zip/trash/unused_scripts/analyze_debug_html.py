#!/usr/bin/env python3
"""
Analyze saved debug HTML files to understand parsing failures.
This script helps identify patterns in failed HTML responses.
"""

import os
import re
from datetime import datetime
from collections import defaultdict, Counter
from bs4 import BeautifulSoup


def analyze_debug_files():
    """Analyze all debug HTML files and provide insights."""
    debug_dir = "debug_html"
    
    if not os.path.exists(debug_dir):
        print("❌ No debug_html directory found")
        return
    
    html_files = [f for f in os.listdir(debug_dir) if f.endswith('.html')]
    txt_files = [f for f in os.listdir(debug_dir) if f.endswith('.txt')]
    
    print(f"🔍 Found {len(html_files)} HTML files and {len(txt_files)} info files")
    
    if not html_files and not txt_files:
        print("❌ No debug files found")
        return
    
    # Analyze by status
    status_counts = Counter()
    error_patterns = Counter()
    card_failures = Counter()
    
    print("\n📊 ANALYZING DEBUG FILES")
    print("=" * 50)
    
    # Analyze HTML files
    for filename in html_files:
        filepath = os.path.join(debug_dir, filename)
        
        # Extract info from filename
        parts = filename.replace('.html', '').split('_')
        if len(parts) >= 3:
            timestamp = parts[0]
            card_name = '_'.join(parts[1:-1])
            status = parts[-1]
        else:
            continue
        
        status_counts[status] += 1
        card_failures[card_name] += 1
        
        # Analyze HTML content
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Extract debug info from HTML comments
            debug_info = extract_debug_info(content)
            if debug_info.get('error'):
                error_patterns[debug_info['error']] += 1
            
            # Analyze HTML structure for no_listings_found cases
            if status == 'no_listings_found':
                analyze_no_listings_html(content, card_name)
                
        except Exception as e:
            print(f"⚠️  Error analyzing {filename}: {e}")
    
    # Analyze TXT files
    for filename in txt_files:
        filepath = os.path.join(debug_dir, filename)
        
        parts = filename.replace('.txt', '').split('_')
        if len(parts) >= 3:
            status = parts[-1]
            card_name = '_'.join(parts[1:-1])
        else:
            continue
            
        status_counts[status] += 1
        card_failures[card_name] += 1
    
    # Print analysis results
    print(f"\n📈 STATUS BREAKDOWN:")
    for status, count in status_counts.most_common():
        print(f"   {status}: {count} files")
    
    print(f"\n🎯 MOST PROBLEMATIC CARDS:")
    for card, count in card_failures.most_common(10):
        print(f"   {card}: {count} failures")
    
    if error_patterns:
        print(f"\n⚠️  COMMON ERROR PATTERNS:")
        for error, count in error_patterns.most_common():
            print(f"   {error}: {count} times")
    
    # Analyze debug summary log if it exists
    summary_file = os.path.join(debug_dir, "debug_summary.log")
    if os.path.exists(summary_file):
        analyze_debug_summary(summary_file)


def extract_debug_info(html_content):
    """Extract debug info from HTML comments."""
    debug_info = {}
    
    # Extract debug comments
    comment_pattern = r'<!-- (.*?) -->'
    comments = re.findall(comment_pattern, html_content, re.DOTALL)
    
    for comment in comments:
        if comment.startswith('URL:'):
            debug_info['url'] = comment[4:].strip()
        elif comment.startswith('Status:'):
            debug_info['status'] = comment[7:].strip()
        elif comment.startswith('Error:'):
            debug_info['error'] = comment[6:].strip()
        elif comment.startswith('HTML Length:'):
            debug_info['length'] = comment[12:].strip()
    
    return debug_info


def analyze_no_listings_html(html_content, card_name):
    """Analyze HTML structure for pages where no listings were found."""
    try:
        # Remove debug comments for cleaner analysis
        clean_html = re.sub(r'<!-- DEBUG INFO -->.*?<!-- END DEBUG INFO -->', '', html_content, flags=re.DOTALL)
        soup = BeautifulSoup(clean_html, 'html.parser')
        
        # Look for common indicators
        indicators = {
            'tables': len(soup.find_all('table')),
            'article_rows': len(soup.find_all('div', class_=re.compile(r'article-row'))),
            'price_elements': len(soup.find_all(string=re.compile(r'€\s*\d+[.,]\d+'))),
            'cardmarket_text': 'cardmarket' in html_content.lower(),
            'blocked_indicators': any(word in html_content.lower() for word in ['blocked', 'forbidden', 'captcha', 'bot']),
            'login_required': any(word in html_content.lower() for word in ['login', 'sign in', 'anmelden']),
            'product_not_found': any(phrase in html_content.lower() for phrase in ['not found', '404', 'product not available']),
        }
        
        print(f"\n🔍 ANALYSIS FOR {card_name}:")
        for indicator, value in indicators.items():
            print(f"   {indicator}: {value}")
        
        # Look for specific HTML patterns that might indicate structure changes
        if indicators['tables'] > 0:
            print(f"   📋 Found {indicators['tables']} tables - might need updated selectors")
        
        if not indicators['cardmarket_text']:
            print(f"   ⚠️  Doesn't appear to be Cardmarket content")
        
        if indicators['blocked_indicators']:
            print(f"   🚫 May be blocked by anti-bot measures")
            
        if indicators['login_required']:
            print(f"   🔐 May require login/authentication")
    
    except Exception as e:
        print(f"⚠️  Error analyzing HTML structure: {e}")


def analyze_debug_summary(summary_file):
    """Analyze the debug summary log file."""
    print(f"\n📋 SUMMARY LOG ANALYSIS:")
    print("-" * 30)
    
    try:
        with open(summary_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        print(f"Total debug entries: {len(lines)}")
        
        # Analyze by time patterns
        recent_failures = []
        for line in lines[-10:]:  # Last 10 entries
            if line.strip():
                recent_failures.append(line.strip())
        
        if recent_failures:
            print(f"\n🕒 RECENT FAILURES:")
            for failure in recent_failures:
                print(f"   {failure}")
                
    except Exception as e:
        print(f"⚠️  Error analyzing summary log: {e}")


def suggest_fixes():
    """Suggest potential fixes based on analysis."""
    print(f"\n💡 SUGGESTED FIXES:")
    print("=" * 30)
    print("1. Check if HTML selectors need updating")
    print("2. Verify if Cardmarket changed their page structure")
    print("3. Consider adding delay between requests")
    print("4. Check if proxy rotation is needed")
    print("5. Verify user-agent strings are current")
    print("6. Consider using Selenium for JavaScript-heavy pages")
    print("7. Check if authentication/login is now required")


if __name__ == "__main__":
    analyze_debug_files()
    suggest_fixes()
