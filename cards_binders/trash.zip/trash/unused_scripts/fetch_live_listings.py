#!/usr/bin/env python3
"""
Fetch real-time listing data from Cardmarket.

This script scrapes live listings to get ACTUAL current prices and availability,
solving the AVG7 problem where historical data shows deals that are already gone.
"""

import requests
from bs4 import BeautifulSoup
import time
import json
from typing import List, Dict, Optional
from dataclasses import dataclass
import re


@dataclass
class LiveListing:
    """Represents a live listing from Cardmarket."""
    price: float
    condition: str
    seller: str
    seller_country: str
    seller_rating: Optional[float]
    seller_sales: Optional[int]
    language: str
    quantity: int
    foil: bool = False


class CardmarketScraper:
    """Scraper for live Cardmarket listings."""
    
    def __init__(self, delay: float = 1.0):
        """
        Initialize the scraper.
        
        Args:
            delay: Delay between requests in seconds (be respectful)
        """
        self.delay = delay
        self.session = requests.Session()
        
        # Set a proper user agent
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
    
    def fetch_listings(self, url: str, max_listings: int = 20) -> List[LiveListing]:
        """
        Fetch live listings from a Cardmarket product page.
        
        Args:
            url: The Cardmarket product URL
            max_listings: Maximum number of listings to fetch
            
        Returns:
            List of LiveListing objects
        """
        print(f"🔍 Fetching listings from: {url}")
        
        try:
            # Add delay to be respectful
            time.sleep(self.delay)
            
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Parse the listings table
            listings = self._parse_listings_table(soup, max_listings)
            
            print(f"✅ Found {len(listings)} listings")
            return listings
            
        except requests.RequestException as e:
            print(f"❌ Error fetching {url}: {e}")
            return []
        except Exception as e:
            print(f"❌ Error parsing listings: {e}")
            return []
    
    def _parse_listings_table(self, soup: BeautifulSoup, max_listings: int) -> List[LiveListing]:
        """
        Parse the listings table from Cardmarket HTML.
        
        Note: This is a template - actual HTML structure may vary.
        You'll need to inspect the page source to get the correct selectors.
        """
        listings = []
        
        # Look for the listings table (common patterns)
        table_selectors = [
            'table.table-striped',
            'table[data-table="offers"]',
            '.offers-table',
            'table.offers',
            '#offersTable'
        ]
        
        listings_table = None
        for selector in table_selectors:
            listings_table = soup.select_one(selector)
            if listings_table:
                print(f"📋 Found listings table with selector: {selector}")
                break
        
        if not listings_table:
            print("⚠️  Could not find listings table - HTML structure may have changed")
            print("🔍 Available table elements:")
            tables = soup.find_all('table')
            for i, table in enumerate(tables[:3]):  # Show first 3 tables
                classes = table.get('class', [])
                id_attr = table.get('id', '')
                print(f"  Table {i+1}: classes={classes}, id='{id_attr}'")
            return listings
        
        # Parse table rows
        rows = listings_table.find_all('tr')[1:]  # Skip header row
        
        for i, row in enumerate(rows[:max_listings]):
            try:
                listing = self._parse_listing_row(row)
                if listing:
                    listings.append(listing)
            except Exception as e:
                print(f"⚠️  Error parsing row {i+1}: {e}")
                continue
        
        return listings
    
    def _parse_listing_row(self, row) -> Optional[LiveListing]:
        """
        Parse a single listing row.
        
        Note: This is a template - you'll need to adjust selectors based on actual HTML.
        """
        cells = row.find_all(['td', 'th'])
        
        if len(cells) < 5:  # Minimum expected columns
            return None
        
        try:
            # These selectors are educated guesses - inspect the actual HTML
            # and adjust accordingly
            
            # Price (usually first or second column)
            price_cell = cells[0] if cells else None
            price_text = price_cell.get_text(strip=True) if price_cell else "0"
            price = self._extract_price(price_text)
            
            # Condition (usually has condition indicators)
            condition = "Unknown"
            for cell in cells:
                cell_text = cell.get_text(strip=True).lower()
                if any(cond in cell_text for cond in ['mint', 'nm', 'ex', 'gd', 'lp', 'pl', 'po']):
                    condition = cell.get_text(strip=True)
                    break
            
            # Seller info (usually has seller name/rating)
            seller = "Unknown"
            seller_country = "Unknown"
            seller_rating = None
            seller_sales = None
            
            for cell in cells:
                # Look for seller links or seller info
                seller_link = cell.find('a')
                if seller_link and 'user' in str(seller_link.get('href', '')).lower():
                    seller = seller_link.get_text(strip=True)
                    break
            
            # Language (look for language indicators)
            language = "Unknown"
            for cell in cells:
                cell_text = cell.get_text(strip=True)
                if any(lang in cell_text.lower() for lang in ['english', 'german', 'french', 'italian', 'spanish']):
                    language = cell_text
                    break
            
            # Quantity (look for quantity numbers)
            quantity = 1
            for cell in cells:
                cell_text = cell.get_text(strip=True)
                qty_match = re.search(r'(\d+)x?', cell_text)
                if qty_match:
                    quantity = int(qty_match.group(1))
                    break
            
            # Foil detection
            foil = any('foil' in cell.get_text(strip=True).lower() for cell in cells)
            
            return LiveListing(
                price=price,
                condition=condition,
                seller=seller,
                seller_country=seller_country,
                seller_rating=seller_rating,
                seller_sales=seller_sales,
                language=language,
                quantity=quantity,
                foil=foil
            )
            
        except Exception as e:
            print(f"⚠️  Error parsing listing row: {e}")
            return None
    
    def _extract_price(self, price_text: str) -> float:
        """Extract price from text like '€ 42,59' or '$42.59'."""
        # Remove currency symbols and spaces
        clean_text = re.sub(r'[€$£¥\s]', '', price_text)
        
        # Handle European comma decimal separator
        if ',' in clean_text and '.' not in clean_text:
            clean_text = clean_text.replace(',', '.')
        elif ',' in clean_text and '.' in clean_text:
            # Format like "1.234,56" (European style)
            clean_text = clean_text.replace('.', '').replace(',', '.')
        
        try:
            return float(clean_text)
        except ValueError:
            print(f"⚠️  Could not parse price: '{price_text}'")
            return 0.0


def analyze_listings(listings: List[LiveListing], avg7: float = None, trend: float = None) -> Dict:
    """
    Analyze the fetched listings.
    
    Args:
        listings: List of live listings
        avg7: Recent 7-day average price for comparison
        trend: Trend price for comparison
        
    Returns:
        Analysis summary
    """
    if not listings:
        return {"error": "No listings found"}
    
    # Sort by price
    sorted_listings = sorted(listings, key=lambda x: x.price)
    
    prices = [listing.price for listing in sorted_listings if listing.price > 0]
    
    if not prices:
        return {"error": "No valid prices found"}
    
    analysis = {
        "total_listings": len(listings),
        "cheapest_price": min(prices),
        "most_expensive": max(prices),
        "average_price": sum(prices) / len(prices),
        "median_price": prices[len(prices) // 2],
        "price_range": max(prices) - min(prices),
        "listings": [
            {
                "price": listing.price,
                "condition": listing.condition,
                "seller": listing.seller,
                "quantity": listing.quantity,
                "foil": listing.foil
            }
            for listing in sorted_listings[:10]  # Top 10 cheapest
        ]
    }
    
    # Compare with historical data if provided
    if avg7:
        analysis["vs_avg7"] = {
            "cheapest_vs_avg7": (min(prices) - avg7) / avg7 * 100,
            "average_vs_avg7": (analysis["average_price"] - avg7) / avg7 * 100
        }
    
    if trend:
        analysis["vs_trend"] = {
            "cheapest_vs_trend": (min(prices) - trend) / trend * 100,
            "average_vs_trend": (analysis["average_price"] - trend) / trend * 100
        }
    
    return analysis


def main():
    """Test the scraper with the provided URL."""
    test_url = "https://www.cardmarket.com/en/Magic/Products/Singles/Alpha/Animate-Artifact?sellerCountry=7&language=1&minCondition=3"
    
    print("🃏 Cardmarket Live Listings Scraper")
    print("=" * 50)
    print(f"🎯 Target: {test_url}")
    print()
    
    scraper = CardmarketScraper(delay=1.0)
    listings = scraper.fetch_listings(test_url, max_listings=20)
    
    if listings:
        print("\n📊 LIVE LISTINGS ANALYSIS")
        print("=" * 30)
        
        # Example historical data for comparison
        # (In real usage, you'd get this from your price guide data)
        example_avg7 = 45.0  # €45 recent sales
        example_trend = 82.0  # €82 trend
        
        analysis = analyze_listings(listings, example_avg7, example_trend)
        
        print(f"Total listings found: {analysis.get('total_listings', 0)}")
        print(f"Cheapest current price: €{analysis.get('cheapest_price', 0):.2f}")
        print(f"Average current price: €{analysis.get('average_price', 0):.2f}")
        
        if 'vs_avg7' in analysis:
            cheapest_vs_avg7 = analysis['vs_avg7']['cheapest_vs_avg7']
            print(f"Cheapest vs AVG7: {cheapest_vs_avg7:+.1f}% (€{example_avg7})")
        
        if 'vs_trend' in analysis:
            cheapest_vs_trend = analysis['vs_trend']['cheapest_vs_trend']
            print(f"Cheapest vs TREND: {cheapest_vs_trend:+.1f}% (€{example_trend})")
        
        print("\n🏷️  TOP 5 CHEAPEST LISTINGS:")
        for i, listing in enumerate(analysis['listings'][:5], 1):
            print(f"{i}. €{listing['price']:.2f} - {listing['condition']} - {listing['seller']} (Qty: {listing['quantity']})")
        
        # Save results
        output_file = f"data/live_listings_{int(time.time())}.json"
        try:
            import os
            os.makedirs('data', exist_ok=True)
            with open(output_file, 'w') as f:
                json.dump(analysis, f, indent=2)
            print(f"\n💾 Results saved to: {output_file}")
        except Exception as e:
            print(f"⚠️  Could not save results: {e}")
    
    else:
        print("❌ No listings found. This could be due to:")
        print("1. HTML structure has changed (need to update selectors)")
        print("2. Cardmarket blocking automated requests")
        print("3. Network issues")
        print("4. The specific product page format is different")
        print("\n🔧 Next steps:")
        print("1. Manually inspect the page source")
        print("2. Update the parsing selectors in _parse_listings_table()")
        print("3. Consider using browser automation (Selenium) if needed")


if __name__ == "__main__":
    main()
