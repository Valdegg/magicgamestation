#!/usr/bin/env python3
"""
Fetch real-time listing data from Cardmarket using Selenium (browser automation).

This approach uses a real browser to bypass anti-bot measures and get actual
current prices and availability, solving the AVG7 problem.

Requirements:
    pip install selenium webdriver-manager

Usage:
    python fetch_live_listings_selenium.py [URL]
"""

import time
import json
import re
import sys
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict

try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from webdriver_manager.chrome import ChromeDriverManager
    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False


@dataclass
class LiveListing:
    """Represents a live listing from Cardmarket."""
    price: float
    condition: str
    seller: str
    seller_country: str = "Unknown"
    seller_rating: Optional[float] = None
    seller_sales: Optional[int] = None
    language: str = "Unknown"
    quantity: int = 1
    foil: bool = False
    shipping: Optional[float] = None


class SeleniumCardmarketScraper:
    """Browser-based scraper for Cardmarket using Selenium."""
    
    def __init__(self, headless: bool = True, delay: float = 2.0):
        """
        Initialize the Selenium scraper.
        
        Args:
            headless: Run browser in headless mode
            delay: Delay between actions in seconds
        """
        if not SELENIUM_AVAILABLE:
            raise ImportError("Selenium not available. Install with: pip install selenium webdriver-manager")
        
        self.headless = headless
        self.delay = delay
        self.driver = None
        
    def __enter__(self):
        """Context manager entry."""
        self._setup_driver()
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        if self.driver:
            self.driver.quit()
    
    def _setup_driver(self):
        """Set up the Chrome WebDriver."""
        print("🚀 Setting up Chrome WebDriver...")
        
        chrome_options = Options()
        if self.headless:
            chrome_options.add_argument("--headless")
        
        # Anti-detection measures
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        # Set a realistic user agent
        chrome_options.add_argument("--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        
        try:
            service = Service(ChromeDriverManager().install())
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            
            # Execute script to remove webdriver property
            self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
            
            print("✅ WebDriver setup complete")
            
        except Exception as e:
            print(f"❌ Error setting up WebDriver: {e}")
            print("💡 Make sure Chrome is installed and try: pip install selenium webdriver-manager")
            raise
    
    def fetch_listings(self, url: str, max_listings: int = 20) -> List[LiveListing]:
        """
        Fetch live listings from a Cardmarket product page.
        
        Args:
            url: The Cardmarket product URL
            max_listings: Maximum number of listings to fetch
            
        Returns:
            List of LiveListing objects
        """
        if not self.driver:
            self._setup_driver()
        
        print(f"🔍 Navigating to: {url}")
        
        try:
            # Navigate to the page
            self.driver.get(url)
            time.sleep(self.delay)
            
            # Wait for page to load
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Check if we're blocked or need to accept cookies
            self._handle_page_obstacles()
            
            # Find and parse listings
            listings = self._parse_listings_with_selenium(max_listings)
            
            print(f"✅ Found {len(listings)} listings")
            return listings
            
        except Exception as e:
            print(f"❌ Error fetching listings: {e}")
            
            # Save screenshot for debugging
            try:
                self.driver.save_screenshot("debug_screenshot.png")
                print("📸 Debug screenshot saved as debug_screenshot.png")
            except:
                pass
                
            return []
    
    def _handle_page_obstacles(self):
        """Handle common page obstacles like cookie banners, captchas, etc."""
        try:
            # Accept cookies if present
            cookie_selectors = [
                "button[data-testid='cookie-accept']",
                ".cookie-accept",
                "#cookie-accept",
                "button:contains('Accept')",
                "button:contains('Akzeptieren')"
            ]
            
            for selector in cookie_selectors:
                try:
                    if "contains" in selector:
                        # XPath for text content
                        xpath = f"//button[contains(text(), '{selector.split(':contains(')[1][2:-3]}')]"
                        element = self.driver.find_element(By.XPATH, xpath)
                    else:
                        element = self.driver.find_element(By.CSS_SELECTOR, selector)
                    
                    if element.is_displayed():
                        element.click()
                        print("🍪 Accepted cookies")
                        time.sleep(1)
                        break
                except:
                    continue
            
            # Check for captcha or login requirements
            page_source = self.driver.page_source.lower()
            if "captcha" in page_source:
                print("🤖 CAPTCHA detected - manual intervention may be needed")
            elif "login" in page_source and "required" in page_source:
                print("🔐 Login may be required for full access")
            
        except Exception as e:
            print(f"⚠️  Error handling page obstacles: {e}")
    
    def _parse_listings_with_selenium(self, max_listings: int) -> List[LiveListing]:
        """Parse listings using Selenium WebDriver."""
        listings = []
        
        # Common selectors for Cardmarket listings
        table_selectors = [
            "table.table",
            "table[data-testid='offers-table']",
            ".offers-table",
            "table.offers",
            "#offersTable",
            "tbody tr"  # Direct row selector
        ]
        
        print("🔍 Looking for listings table...")
        
        # Try to find the listings table/rows
        rows = []
        for selector in table_selectors:
            try:
                if selector == "tbody tr":
                    rows = self.driver.find_elements(By.CSS_SELECTOR, selector)
                else:
                    table = self.driver.find_element(By.CSS_SELECTOR, selector)
                    rows = table.find_elements(By.TAG_NAME, "tr")[1:]  # Skip header
                
                if rows:
                    print(f"📋 Found {len(rows)} rows with selector: {selector}")
                    break
            except:
                continue
        
        if not rows:
            print("⚠️  Could not find listings table")
            print("🔍 Page title:", self.driver.title)
            print("🔍 Current URL:", self.driver.current_url)
            
            # Try to find any price elements as fallback
            price_selectors = [
                "[data-testid*='price']",
                ".price",
                "[class*='price']",
                "span:contains('€')",
                "div:contains('€')"
            ]
            
            for selector in price_selectors:
                try:
                    if "contains" in selector:
                        xpath = f"//*[contains(text(), '€')]"
                        elements = self.driver.find_elements(By.XPATH, xpath)
                    else:
                        elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    
                    if elements:
                        print(f"💰 Found {len(elements)} price elements with: {selector}")
                        # Could parse these as a fallback
                        break
                except:
                    continue
            
            return listings
        
        # Parse each row
        for i, row in enumerate(rows[:max_listings]):
            try:
                listing = self._parse_row_with_selenium(row)
                if listing and listing.price > 0:
                    listings.append(listing)
                    print(f"  📄 Listing {i+1}: €{listing.price:.2f} - {listing.condition} - {listing.seller}")
            except Exception as e:
                print(f"⚠️  Error parsing row {i+1}: {e}")
                continue
        
        return listings
    
    def _parse_row_with_selenium(self, row) -> Optional[LiveListing]:
        """Parse a single listing row using Selenium."""
        try:
            cells = row.find_elements(By.TAG_NAME, "td")
            if len(cells) < 3:
                return None
            
            # Extract data from cells
            row_text = row.text
            
            # Price extraction (look for € symbol)
            price = 0.0
            price_match = re.search(r'€\s*(\d+[.,]\d+|\d+)', row_text)
            if price_match:
                price_str = price_match.group(1).replace(',', '.')
                price = float(price_str)
            
            # Condition extraction
            condition = "Unknown"
            condition_patterns = [
                r'\b(Mint|Near Mint|NM|Excellent|EX|Good|GD|Light Played|LP|Played|PL|Poor|PO)\b'
            ]
            for pattern in condition_patterns:
                match = re.search(pattern, row_text, re.IGNORECASE)
                if match:
                    condition = match.group(1)
                    break
            
            # Seller extraction (look for links or seller patterns)
            seller = "Unknown"
            try:
                seller_links = row.find_elements(By.CSS_SELECTOR, "a[href*='user'], a[href*='seller']")
                if seller_links:
                    seller = seller_links[0].text.strip()
            except:
                pass
            
            # Language extraction
            language = "Unknown"
            lang_patterns = [
                r'\b(English|German|French|Italian|Spanish|Japanese)\b'
            ]
            for pattern in lang_patterns:
                match = re.search(pattern, row_text, re.IGNORECASE)
                if match:
                    language = match.group(1)
                    break
            
            # Quantity extraction
            quantity = 1
            qty_match = re.search(r'(\d+)x', row_text)
            if qty_match:
                quantity = int(qty_match.group(1))
            
            # Foil detection
            foil = 'foil' in row_text.lower()
            
            return LiveListing(
                price=price,
                condition=condition,
                seller=seller,
                language=language,
                quantity=quantity,
                foil=foil
            )
            
        except Exception as e:
            print(f"⚠️  Error parsing row: {e}")
            return None


def main():
    """Main function to test the Selenium scraper."""
    if not SELENIUM_AVAILABLE:
        print("❌ Selenium not available!")
        print("📦 Install with: pip install selenium webdriver-manager")
        return
    
    # Get URL from command line or use default
    if len(sys.argv) > 1:
        test_url = sys.argv[1]
    else:
        test_url = "https://www.cardmarket.com/en/Magic/Products/Singles/Alpha/Animate-Artifact?sellerCountry=7&language=1&minCondition=3"
    
    print("🃏 Cardmarket Live Listings Scraper (Selenium)")
    print("=" * 60)
    print(f"🎯 Target: {test_url}")
    print()
    
    try:
        with SeleniumCardmarketScraper(headless=False, delay=2.0) as scraper:
            listings = scraper.fetch_listings(test_url, max_listings=10)
            
            if listings:
                print("\n📊 LIVE LISTINGS FOUND!")
                print("=" * 40)
                
                # Sort by price
                sorted_listings = sorted(listings, key=lambda x: x.price)
                
                for i, listing in enumerate(sorted_listings, 1):
                    foil_indicator = " (Foil)" if listing.foil else ""
                    print(f"{i:2d}. €{listing.price:6.2f} - {listing.condition:12} - {listing.seller}{foil_indicator}")
                    if listing.quantity > 1:
                        print(f"     Quantity: {listing.quantity}")
                
                # Analysis
                prices = [l.price for l in listings if l.price > 0]
                if prices:
                    print(f"\n💰 PRICE ANALYSIS:")
                    print(f"   Cheapest: €{min(prices):.2f}")
                    print(f"   Most expensive: €{max(prices):.2f}")
                    print(f"   Average: €{sum(prices)/len(prices):.2f}")
                
                # Save results
                output_data = {
                    "url": test_url,
                    "timestamp": time.time(),
                    "listings": [asdict(listing) for listing in sorted_listings],
                    "analysis": {
                        "total_listings": len(listings),
                        "cheapest": min(prices) if prices else 0,
                        "most_expensive": max(prices) if prices else 0,
                        "average": sum(prices)/len(prices) if prices else 0
                    }
                }
                
                output_file = f"data/live_listings_selenium_{int(time.time())}.json"
                try:
                    import os
                    os.makedirs('data', exist_ok=True)
                    with open(output_file, 'w') as f:
                        json.dump(output_data, f, indent=2)
                    print(f"\n💾 Results saved to: {output_file}")
                except Exception as e:
                    print(f"⚠️  Could not save results: {e}")
            
            else:
                print("❌ No listings found")
                print("\n🔧 Possible issues:")
                print("1. Page structure changed")
                print("2. Login/authentication required")
                print("3. CAPTCHA blocking")
                print("4. Geographic restrictions")
                print("5. Product not available")
    
    except Exception as e:
        print(f"❌ Scraper error: {e}")


if __name__ == "__main__":
    main()
