#!/usr/bin/env python3
"""
Move unused scripts to trash folder for cleanup.
Keeps useful standalone scripts like filter_deals.py.
"""

import os
import shutil
from pathlib import Path


def move_unused_scripts():
    """Move unused scripts to organized trash folders."""
    
    # Scripts to keep (useful standalone tools)
    keep_scripts = {
        'filter_deals.py',  # Recently created, useful tool
        'analyze_debug_html.py',  # Useful debug tool we just created
        'analyze_unused_scripts.py',  # This script itself
        'move_to_trash.py',  # This script itself
    }
    
    # Define what to move
    moves = {
        'debug': [
            'debug_price_extraction.py',
            'debug_demonic_tutor.py', 
            'debug_howling_mine_text.py',
        ],
        'analysis': [
            'evaluate_real_buyability.py',
            'view_candidates_simple.py',
            'analyze_card_liquidity.py',
            'export_candidates_csv.py',
            'view_results.py',
            'analyze_liquidity.py',
        ],
        'utilities': [
            'load_real_data.py',
            'scale_live_checking.py', 
            'install_selenium.py',
            'lookup_card.py',
            'example.py',
            'create_expansion_mapping.py',
        ]
    }
    
    # Create trash directory structure
    trash_dir = Path('trash')
    trash_dir.mkdir(exist_ok=True)
    
    for category in moves.keys():
        (trash_dir / category).mkdir(exist_ok=True)
    
    print("🗑️  MOVING UNUSED SCRIPTS TO TRASH")
    print("=" * 40)
    
    total_moved = 0
    
    for category, scripts in moves.items():
        if scripts:
            print(f"\n📂 Moving to trash/{category}/:")
            
            for script in scripts:
                if script in keep_scripts:
                    print(f"   ⏭️  SKIPPING {script} (keeping as useful tool)")
                    continue
                    
                if os.path.exists(script):
                    dest = trash_dir / category / script
                    try:
                        shutil.move(script, dest)
                        print(f"   ✅ {script} → trash/{category}/")
                        total_moved += 1
                    except Exception as e:
                        print(f"   ❌ Failed to move {script}: {e}")
                else:
                    print(f"   ⚠️  {script} not found")
    
    print(f"\n📊 CLEANUP SUMMARY:")
    print(f"   Files moved to trash: {total_moved}")
    print(f"   Files kept as useful tools: {len(keep_scripts)}")
    
    # Show what's left in root
    remaining_py = [f for f in os.listdir('.') if f.endswith('.py')]
    print(f"   Python files remaining in root: {len(remaining_py)}")
    
    print(f"\n📁 TRASH DIRECTORY CONTENTS:")
    for category in moves.keys():
        category_dir = trash_dir / category
        if category_dir.exists():
            files = list(category_dir.glob('*.py'))
            print(f"   trash/{category}/: {len(files)} files")
            for file in files:
                print(f"      {file.name}")
    
    print(f"\n✨ CLEANUP COMPLETE!")
    print(f"The root directory is now cleaner with only essential scripts.")


if __name__ == "__main__":
    move_unused_scripts()
