#!/usr/bin/env python3
"""Generate a beautiful HTML website from seller deals JSON."""

import json
import sys
from datetime import datetime


def generate_html(seller_deals_data, output_file='seller_deals.html'):
    """Generate a clean, modern HTML page from seller deals."""
    
    seller_deals = seller_deals_data.get('seller_deals', {})
    threshold = seller_deals_data.get('threshold', 10.0)
    
    # Count total deals
    total_deals = sum(len(data['deals']) for data in seller_deals.values())
    multi_deal_sellers = sum(1 for data in seller_deals.values() if len(data['deals']) >= 2)
    
    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MTG Arbitrage - Seller Deals</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }}
        
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        
        header {{
            background: white;
            border-radius: 16px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }}
        
        h1 {{
            font-size: 2.5em;
            color: #2d3748;
            margin-bottom: 10px;
        }}
        
        .stats {{
            display: flex;
            gap: 30px;
            margin-top: 20px;
            flex-wrap: wrap;
        }}
        
        .stat {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 25px;
            border-radius: 12px;
            font-size: 0.9em;
        }}
        
        .stat-number {{
            font-size: 2em;
            font-weight: bold;
            display: block;
        }}
        
        .seller-card {{
            background: white;
            border-radius: 16px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            transition: transform 0.2s, box-shadow 0.2s;
        }}
        
        .seller-card:hover {{
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
        }}
        
        .seller-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e2e8f0;
        }}
        
        .seller-name {{
            font-size: 1.5em;
            font-weight: bold;
            color: #2d3748;
        }}
        
        .seller-badge {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 600;
        }}
        
        .seller-link {{
            display: inline-block;
            margin-top: 10px;
            color: #667eea;
            text-decoration: none;
            font-size: 0.9em;
        }}
        
        .seller-link:hover {{
            text-decoration: underline;
        }}
        
        .deals {{
            display: grid;
            gap: 15px;
        }}
        
        .deal {{
            background: #f7fafc;
            border-radius: 12px;
            padding: 20px;
            border-left: 4px solid #667eea;
        }}
        
        .deal-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }}
        
        .card-name {{
            font-size: 1.2em;
            font-weight: 600;
            color: #2d3748;
        }}
        
        .discount-badge {{
            background: #48bb78;
            color: white;
            padding: 6px 12px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.9em;
        }}
        
        .deal-info {{
            display: flex;
            gap: 20px;
            margin-bottom: 12px;
            font-size: 0.95em;
            color: #4a5568;
        }}
        
        .deal-links {{
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }}
        
        .btn {{
            display: inline-block;
            padding: 8px 16px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 0.85em;
            font-weight: 600;
            transition: all 0.2s;
        }}
        
        .btn-cardmarket {{
            background: #3182ce;
            color: white;
        }}
        
        .btn-cardmarket:hover {{
            background: #2c5282;
        }}
        
        .btn-mtgstocks {{
            background: #ed8936;
            color: white;
        }}
        
        .btn-mtgstocks:hover {{
            background: #c05621;
        }}
        
        .condition {{
            background: #edf2f7;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.85em;
            font-weight: 600;
            color: #4a5568;
        }}
        
        footer {{
            text-align: center;
            color: white;
            margin-top: 40px;
            padding: 20px;
            font-size: 0.9em;
        }}
        
        @media (max-width: 768px) {{
            h1 {{
                font-size: 1.8em;
            }}
            
            .stats {{
                gap: 15px;
            }}
            
            .deal-header {{
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🎯 MTG Arbitrage - Seller Deals</h1>
            <p style="color: #718096; margin-top: 10px;">
                Showing deals ≥{threshold}% below median of top 3 prices
            </p>
            <div class="stats">
                <div class="stat">
                    <span class="stat-number">{len(seller_deals)}</span>
                    Sellers
                </div>
                <div class="stat">
                    <span class="stat-number">{total_deals}</span>
                    Total Deals
                </div>
                <div class="stat">
                    <span class="stat-number">{multi_deal_sellers}</span>
                    Multi-Deal Sellers
                </div>
            </div>
        </header>
        
        <div class="sellers">
'''
    
    # Add each seller
    for seller_name, seller_data in seller_deals.items():
        deals = seller_data['deals']
        seller_url = seller_data['url']
        
        # Calculate stats
        total_value = sum(deal['price'] for deal in deals)
        avg_discount = sum(deal['discount'] for deal in deals) / len(deals)
        
        html += f'''
            <div class="seller-card">
                <div class="seller-header">
                    <div>
                        <div class="seller-name">{seller_name}</div>
                        <a href="{seller_url}" target="_blank" class="seller-link">
                            👤 View Profile on CardMarket →
                        </a>
                    </div>
                    <div class="seller-badge">
                        {len(deals)} deal{'s' if len(deals) > 1 else ''} • €{total_value:.2f} total • {avg_discount:.1f}% avg discount
                    </div>
                </div>
                
                <div class="deals">
'''
        
        # Add each deal
        for deal in sorted(deals, key=lambda x: x['discount'], reverse=True):
            html += f'''
                    <div class="deal">
                        <div class="deal-header">
                            <div class="card-name">{deal['card']}</div>
                            <div class="discount-badge">-{deal['discount']:.1f}%</div>
                        </div>
                        <div class="deal-info">
                            <div><strong>Price:</strong> €{deal['price']:.2f}</div>
                            <div><strong>Median:</strong> €{deal['median']:.2f}</div>
                            <div class="condition">{deal['condition']}</div>
                        </div>
                        <div class="deal-links">
                            <a href="{deal['card_url']}" target="_blank" class="btn btn-cardmarket">
                                📊 View on CardMarket
                            </a>
                            <a href="{deal['mtgstocks_search']}" target="_blank" class="btn btn-mtgstocks">
                                📈 Price History (MTGStocks)
                            </a>
                        </div>
                    </div>
'''
        
        html += '''
                </div>
            </div>
'''
    
    # Footer
    html += f'''
        </div>
        
        <footer>
            Generated on {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')}
        </footer>
    </div>
</body>
</html>
'''
    
    return html


def main():
    if len(sys.argv) < 2:
        print("Usage: python generate_seller_website.py <seller_deals.json> [output.html]")
        print("\nExample:")
        print("  python generate_seller_website.py results/mtg_arbitrage_20251004_191003_seller_deals.json")
        return 1
    
    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else input_file.replace('.json', '.html')
    
    try:
        with open(input_file, 'r') as f:
            data = json.load(f)
    except Exception as e:
        print(f"❌ Error reading JSON: {e}")
        return 1
    
    html = generate_html(data, output_file)
    
    try:
        with open(output_file, 'w') as f:
            f.write(html)
        print(f"✅ Generated: {output_file}")
        print(f"🌐 Open in browser: file://{output_file}")
    except Exception as e:
        print(f"❌ Error writing HTML: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

