#!/usr/bin/env python3
"""
Proxy configuration helper for Cardmarket scraping.

This script helps you set up and test proxy services for bypassing
Cardmarket's anti-bot measures.
"""

import requests
import json
import time
from typing import Dict, List, Optional


class ProxyTester:
    """Test and validate proxy configurations."""
    
    def __init__(self):
        self.test_urls = [
            'https://httpbin.org/ip',
            'https://ipinfo.io/json',
            'https://api.ipify.org?format=json'
        ]
    
    def test_proxy(self, proxy_config: Dict[str, str], name: str = "Unknown") -> bool:
        """
        Test if a proxy configuration works.
        
        Args:
            proxy_config: Dict with 'http' and 'https' proxy URLs
            name: Name/description of the proxy
            
        Returns:
            True if proxy works, False otherwise
        """
        print(f"🧪 Testing proxy: {name}")
        
        for test_url in self.test_urls:
            try:
                response = requests.get(
                    test_url,
                    proxies=proxy_config,
                    timeout=10,
                    headers={
                        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
                    }
                )
                
                if response.status_code == 200:
                    data = response.json()
                    ip = data.get('ip', data.get('origin', 'Unknown'))
                    print(f"  ✅ Working! IP: {ip}")
                    return True
                    
            except Exception as e:
                print(f"  ❌ Failed with {test_url}: {e}")
                continue
        
        print(f"  ❌ Proxy {name} not working")
        return False
    
    def test_cardmarket_access(self, proxy_config: Dict[str, str], name: str = "Unknown") -> bool:
        """
        Test if proxy can access Cardmarket specifically.
        
        Args:
            proxy_config: Dict with 'http' and 'https' proxy URLs
            name: Name/description of the proxy
            
        Returns:
            True if can access Cardmarket, False otherwise
        """
        print(f"🃏 Testing Cardmarket access with: {name}")
        
        test_url = "https://www.cardmarket.com/en/Magic"
        
        try:
            response = requests.get(
                test_url,
                proxies=proxy_config,
                timeout=15,
                headers={
                    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1'
                }
            )
            
            if response.status_code == 200:
                print(f"  ✅ Cardmarket accessible! (Status: {response.status_code})")
                return True
            elif response.status_code == 403:
                print(f"  ❌ Still blocked by Cardmarket (403 Forbidden)")
                return False
            else:
                print(f"  ⚠️  Unexpected status: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"  ❌ Error accessing Cardmarket: {e}")
            return False


def get_free_proxy_lists() -> List[str]:
    """Get URLs for free proxy lists."""
    return [
        "https://www.proxy-list.download/api/v1/get?type=http",
        "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
        "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt"
    ]


def fetch_free_proxies(max_proxies: int = 10) -> List[Dict[str, str]]:
    """
    Fetch free proxies from public lists.
    
    Args:
        max_proxies: Maximum number of proxies to fetch
        
    Returns:
        List of proxy configurations
    """
    print(f"🔍 Fetching up to {max_proxies} free proxies...")
    
    proxies = []
    proxy_urls = get_free_proxy_lists()
    
    for url in proxy_urls:
        if len(proxies) >= max_proxies:
            break
            
        try:
            print(f"📡 Fetching from: {url}")
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                # Parse proxy list (format varies by source)
                lines = response.text.strip().split('\n')
                
                for line in lines[:max_proxies - len(proxies)]:
                    line = line.strip()
                    if ':' in line and len(line.split(':')) == 2:
                        ip, port = line.split(':')
                        proxy_url = f"http://{ip}:{port}"
                        
                        proxy_config = {
                            'http': proxy_url,
                            'https': proxy_url
                        }
                        
                        proxies.append(proxy_config)
                
                print(f"  ✅ Found {len(proxies)} proxies so far")
            else:
                print(f"  ❌ Failed to fetch from {url}")
                
        except Exception as e:
            print(f"  ❌ Error fetching from {url}: {e}")
            continue
    
    print(f"📦 Total free proxies collected: {len(proxies)}")
    return proxies


def create_proxy_config_template():
    """Create a template configuration file for paid proxies."""
    
    config_template = {
        "proxy_services": {
            "brightdata": {
                "name": "BrightData Residential",
                "http": "http://username:password@brd.superproxy.io:22225",
                "https": "http://username:password@brd.superproxy.io:22225",
                "enabled": False,
                "notes": "Replace username:password with your BrightData credentials"
            },
            "smartproxy": {
                "name": "SmartProxy",
                "http": "http://username:password@gate.smartproxy.com:7000",
                "https": "http://username:password@gate.smartproxy.com:7000",
                "enabled": False,
                "notes": "Replace username:password with your SmartProxy credentials"
            },
            "oxylabs": {
                "name": "Oxylabs",
                "http": "http://username:password@pr.oxylabs.io:7777",
                "https": "http://username:password@pr.oxylabs.io:7777",
                "enabled": False,
                "notes": "Replace username:password with your Oxylabs credentials"
            },
            "luminati": {
                "name": "Luminati/BrightData",
                "http": "http://username-session-rand:password@zproxy.lum-superproxy.io:22225",
                "https": "http://username-session-rand:password@zproxy.lum-superproxy.io:22225",
                "enabled": False,
                "notes": "Luminati format with session randomization"
            }
        },
        "settings": {
            "use_free_proxies": True,
            "max_free_proxies": 10,
            "test_proxies_before_use": True,
            "delay_range": [2.0, 4.0]
        }
    }
    
    config_file = "proxy_config.json"
    
    try:
        with open(config_file, 'w') as f:
            json.dump(config_template, f, indent=2)
        
        print(f"📝 Created proxy configuration template: {config_file}")
        print("\n💡 Next steps:")
        print("1. Edit proxy_config.json with your paid proxy credentials")
        print("2. Set enabled: true for the services you want to use")
        print("3. Run: python proxy_config.py test")
        print("\n🌐 Recommended paid proxy services:")
        print("   - BrightData: https://brightdata.com (best for e-commerce)")
        print("   - SmartProxy: https://smartproxy.com (good value)")
        print("   - Oxylabs: https://oxylabs.io (premium quality)")
        
        return config_file
        
    except Exception as e:
        print(f"❌ Error creating config file: {e}")
        return None


def load_proxy_config(config_file: str = "proxy_config.json") -> Optional[dict]:
    """Load proxy configuration from file."""
    try:
        with open(config_file, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"⚠️  Config file {config_file} not found")
        return None
    except Exception as e:
        print(f"❌ Error loading config: {e}")
        return None


def test_all_proxies():
    """Test all configured proxies."""
    print("🧪 Testing All Configured Proxies")
    print("=" * 40)
    
    # Load configuration
    config = load_proxy_config()
    if not config:
        print("Creating default configuration...")
        create_proxy_config_template()
        return
    
    tester = ProxyTester()
    working_proxies = []
    
    # Test paid proxy services
    for service_id, service_config in config.get("proxy_services", {}).items():
        if not service_config.get("enabled", False):
            print(f"⏭️  Skipping {service_config['name']} (disabled)")
            continue
        
        proxy_config = {
            'http': service_config['http'],
            'https': service_config['https']
        }
        
        # Skip if still has template credentials
        if 'username:password' in proxy_config['http']:
            print(f"⏭️  Skipping {service_config['name']} (template credentials)")
            continue
        
        print(f"\n🧪 Testing {service_config['name']}...")
        
        if tester.test_proxy(proxy_config, service_config['name']):
            if tester.test_cardmarket_access(proxy_config, service_config['name']):
                working_proxies.append({
                    'name': service_config['name'],
                    'config': proxy_config,
                    'type': 'paid'
                })
    
    # Test free proxies if enabled
    if config.get("settings", {}).get("use_free_proxies", True):
        print(f"\n🆓 Testing Free Proxies...")
        max_free = config.get("settings", {}).get("max_free_proxies", 10)
        free_proxies = fetch_free_proxies(max_free)
        
        for i, proxy_config in enumerate(free_proxies[:5]):  # Test first 5
            if tester.test_proxy(proxy_config, f"Free Proxy {i+1}"):
                if tester.test_cardmarket_access(proxy_config, f"Free Proxy {i+1}"):
                    working_proxies.append({
                        'name': f"Free Proxy {i+1}",
                        'config': proxy_config,
                        'type': 'free'
                    })
    
    # Summary
    print(f"\n📊 PROXY TEST RESULTS")
    print("=" * 30)
    
    if working_proxies:
        print(f"✅ Found {len(working_proxies)} working proxies:")
        for proxy in working_proxies:
            print(f"   - {proxy['name']} ({proxy['type']})")
        
        # Save working proxies
        working_config = {
            'working_proxies': working_proxies,
            'last_tested': time.time()
        }
        
        with open('working_proxies.json', 'w') as f:
            json.dump(working_config, f, indent=2)
        
        print(f"\n💾 Saved working proxies to: working_proxies.json")
        print("🚀 You can now use these proxies with fetch_live_listings_proxy.py")
        
    else:
        print("❌ No working proxies found")
        print("\n💡 Suggestions:")
        print("1. Sign up for a paid proxy service")
        print("2. Update proxy_config.json with your credentials")
        print("3. Try different free proxy sources")


def main():
    """Main function."""
    import sys
    
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == "test":
            test_all_proxies()
        elif command == "create":
            create_proxy_config_template()
        elif command == "free":
            proxies = fetch_free_proxies(10)
            print(f"Found {len(proxies)} free proxies")
        else:
            print("Usage: python proxy_config.py [test|create|free]")
    else:
        print("🃏 MTG Arbitrage - Proxy Configuration Helper")
        print("=" * 50)
        print()
        print("Commands:")
        print("  python proxy_config.py create  - Create configuration template")
        print("  python proxy_config.py test    - Test all configured proxies")
        print("  python proxy_config.py free    - Fetch free proxies")
        print()
        
        # Check if config exists
        config = load_proxy_config()
        if config:
            print("📋 Found existing proxy_config.json")
            print("💡 Run 'python proxy_config.py test' to test your proxies")
        else:
            print("📝 No configuration found")
            print("💡 Run 'python proxy_config.py create' to get started")


if __name__ == "__main__":
    main()
