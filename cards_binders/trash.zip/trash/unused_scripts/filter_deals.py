#!/usr/bin/env python3
"""
Filter excellent deals CSV to show cards in specified price range.
Displays: name, current cheapest, trend, avg30, and URL.
"""

import pandas as pd
import sys
import os
import argparse

# Import URL generation function
try:
    from mtg_arbitrage.utils import get_cardmarket_url
    URL_GENERATION_AVAILABLE = True
except ImportError:
    URL_GENERATION_AVAILABLE = False


def filter_deals(csv_file, min_price=30, max_price=200):
    """Filter and display deals in the specified price range."""
    
    if not os.path.exists(csv_file):
        print(f"❌ File not found: {csv_file}")
        return
    
    # Read the CSV
    try:
        df = pd.read_csv(csv_file)
        print(f"📊 Loaded {len(df)} deals from {csv_file}")
    except Exception as e:
        print(f"❌ Error reading CSV: {e}")
        return
    
    # Check column names
    print(f"📋 Columns: {list(df.columns)}")
    
    # Filter for cards in specified price range
    # Convert Current_Cheapest to numeric, handling any currency symbols
    df['Current_Cheapest_Numeric'] = pd.to_numeric(df['Current_Cheapest'], errors='coerce')
    
    # Filter price range
    filtered_df = df[(df['Current_Cheapest_Numeric'] >= min_price) & (df['Current_Cheapest_Numeric'] <= max_price)]
    
    print(f"🎯 Found {len(filtered_df)} cards in ${min_price}-${max_price} range")
    
    if len(filtered_df) == 0:
        print("❌ No cards found in the specified price range")
        return
    
    # Select and rename columns for display (reordered: name, current_cheapest, trend, avg30, urls)
    display_columns = {
        'Card_Name': 'Name',
        'Current_Cheapest': 'Current_Cheapest',
        'Historical_TREND': 'Trend',
        'Historical_AVG30': 'Avg30',
        'Cardmarket_URL': 'URL_All_Sellers'
    }
    
    # Create display dataframe
    display_df = filtered_df[list(display_columns.keys())].copy()
    display_df = display_df.rename(columns=display_columns)
    
    # Generate both filtered and unfiltered URLs
    if URL_GENERATION_AVAILABLE:
        print("🔄 Generating URLs for both German sellers and all sellers...")
        german_urls = []
        all_seller_urls = []
        
        for idx, row in display_df.iterrows():
            card_name = row['Name']
            expansion = filtered_df.loc[idx, 'Expansion'] if 'Expansion' in filtered_df.columns else None
            card_id = filtered_df.loc[idx, 'Card_ID'] if 'Card_ID' in filtered_df.columns else None
            
            if card_id:
                # Generate German seller URL (with filters)
                german_url = get_cardmarket_url(card_id, card_name, expansion, 'direct', include_filters=True)
                german_urls.append(german_url)
                
                # Generate all sellers URL (without filters)
                all_url = get_cardmarket_url(card_id, card_name, expansion, 'direct', include_filters=False)
                all_seller_urls.append(all_url)
            else:
                # Fallback: use original URL and modify for German version
                old_url = row['URL_All_Sellers']
                all_seller_urls.append(old_url)  # Keep original as all sellers
                
                # Create German version by adding parameters
                if '?' in old_url:
                    german_url = old_url.replace('?', '?sellerCountry=7&language=1&')
                else:
                    german_url = f"{old_url}?sellerCountry=7&language=1&minCondition=3"
                german_urls.append(german_url)
        
        display_df['URL_All_Sellers'] = all_seller_urls
        display_df['URL_German_Only'] = german_urls
        print("✅ URLs generated for both German sellers and all sellers")
    else:
        print("⚠️  URL generation not available - using original URLs")
        # Add empty German URL column
        display_df['URL_German_Only'] = display_df['URL_All_Sellers']
    
    # Format numeric columns for better display
    for col in ['Avg30', 'Trend']:
        if col in display_df.columns:
            display_df[col] = display_df[col].round(2)
    
    # Sort by Current_Cheapest for easy browsing
    display_df = display_df.sort_values('Current_Cheapest')
    
    # Display results
    print(f"\n💰 CARDS IN ${min_price}-${max_price} RANGE:")
    print("=" * 80)
    
    # Set pandas display options for better output
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', None)
    pd.set_option('display.max_colwidth', 50)
    
    print(display_df.to_string(index=False))
    
    # Save filtered results
    output_file = csv_file.replace('.csv', f'_filtered_{min_price}_{max_price}.csv')
    display_df.to_csv(output_file, index=False)
    print(f"\n💾 Filtered results saved to: {output_file}")
    
    # Summary statistics
    print(f"\n📈 SUMMARY:")
    print(f"   Price range: ${display_df['Current_Cheapest'].min():.2f} - ${display_df['Current_Cheapest'].max():.2f}")
    print(f"   Average price: ${display_df['Current_Cheapest'].mean():.2f}")
    print(f"   Total cards: {len(display_df)}")
    
    # Show top 5 best deals (lowest current price vs avg30)
    if len(display_df) > 0:
        display_df['Discount_vs_Avg30'] = ((display_df['Avg30'] - display_df['Current_Cheapest']) / display_df['Avg30'] * 100).round(1)
        top_deals = display_df.nlargest(5, 'Discount_vs_Avg30')[['Name', 'Current_Cheapest', 'Avg30', 'Discount_vs_Avg30']]
        
        print(f"\n🎯 TOP 5 DEALS (vs 30-day average):")
        for idx, row in top_deals.iterrows():
            print(f"   {row['Name']}: ${row['Current_Cheapest']:.2f} (was ${row['Avg30']:.2f}, {row['Discount_vs_Avg30']:.1f}% off)")


def main():
    """Main function."""
    parser = argparse.ArgumentParser(description='Filter MTG deals by price range')
    parser.add_argument('csv_file', nargs='?', 
                       default="results/excellent_deals_20250929_213225.csv",
                       help='CSV file to filter (default: latest excellent deals)')
    parser.add_argument('--min-price', type=float, default=30,
                       help='Minimum price in dollars (default: 30)')
    parser.add_argument('--max-price', type=float, default=200,
                       help='Maximum price in dollars (default: 200)')
    
    args = parser.parse_args()
    
    print(f"🔍 Filtering deals from: {args.csv_file}")
    print(f"💰 Price range: ${args.min_price} - ${args.max_price}")
    
    filter_deals(args.csv_file, args.min_price, args.max_price)


if __name__ == "__main__":
    main()
