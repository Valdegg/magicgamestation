#!/usr/bin/env python3
"""
Analyze which Python scripts are used by main.py and which are standalone/unused.
This helps identify scripts that can be moved to trash for cleanup.
"""

import os
import re
from pathlib import Path


def analyze_script_usage():
    """Analyze which scripts are used by the main pipeline."""
    
    # Core files used by main.py (directly or indirectly)
    used_by_main = {
        'main.py',  # The main entry point
        'live_price_check.py',  # Imported by main.py
        'manual_verification.py',  # Imported by main.py
        'wishlist.json',  # Used by wishlist.py
        
        # mtg_arbitrage package (all used)
        'mtg_arbitrage/__init__.py',
        'mtg_arbitrage/data_loader.py',
        'mtg_arbitrage/filter.py', 
        'mtg_arbitrage/utils.py',
        'mtg_arbitrage/wishlist.py',
        'mtg_arbitrage/evaluate.py',
        'mtg_arbitrage/scrape.py',
        'mtg_arbitrage/results_saver.py',
        'mtg_arbitrage/csv_loader.py',
        
        # Scraping modules used by live_price_check.py
        'fetch_live_listings_simple.py',  # Used by live_price_check.py
        'fetch_live_listings_proxy.py',   # Used by live_price_check.py  
        'fetch_live_listings_selenium.py', # Used by live_price_check.py
        'fetch_live_listings.py',        # Used by live_price_check.py
        
        # Configuration
        'proxy_config.py',  # Used by proxy scraper
        
        # Tests
        'tests/test_basic.py',  # Test file
    }
    
    # Get all Python files
    all_py_files = set()
    for root, dirs, files in os.walk('.'):
        for file in files:
            if file.endswith('.py'):
                rel_path = os.path.relpath(os.path.join(root, file), '.')
                all_py_files.add(rel_path)
    
    # Find unused scripts
    unused_scripts = all_py_files - used_by_main
    
    print("🔍 SCRIPT USAGE ANALYSIS")
    print("=" * 50)
    
    print(f"\n✅ USED BY MAIN PIPELINE ({len(used_by_main)} files):")
    for script in sorted(used_by_main):
        if script in all_py_files or script.endswith('.json'):
            print(f"   {script}")
    
    print(f"\n🗑️  UNUSED/STANDALONE SCRIPTS ({len(unused_scripts)} files):")
    for script in sorted(unused_scripts):
        print(f"   {script}")
    
    # Categorize unused scripts
    debug_scripts = [s for s in unused_scripts if 'debug' in s.lower()]
    analysis_scripts = [s for s in unused_scripts if any(word in s.lower() for word in ['analyze', 'view', 'export', 'evaluate'])]
    utility_scripts = [s for s in unused_scripts if any(word in s.lower() for word in ['install', 'create', 'load', 'lookup', 'scale', 'example', 'filter'])]
    
    print(f"\n📊 CATEGORIZATION:")
    print(f"   🐛 Debug scripts: {len(debug_scripts)}")
    for script in debug_scripts:
        print(f"      {script}")
    
    print(f"   📈 Analysis/View scripts: {len(analysis_scripts)}")  
    for script in analysis_scripts:
        print(f"      {script}")
        
    print(f"   🔧 Utility scripts: {len(utility_scripts)}")
    for script in utility_scripts:
        print(f"      {script}")
    
    return unused_scripts


def create_trash_structure():
    """Create trash folder and move unused scripts."""
    unused_scripts = analyze_script_usage()
    
    print(f"\n🗑️  CREATING TRASH STRUCTURE")
    print("=" * 40)
    
    # Create trash directory
    trash_dir = Path('trash')
    trash_dir.mkdir(exist_ok=True)
    
    # Create subdirectories in trash
    (trash_dir / 'debug').mkdir(exist_ok=True)
    (trash_dir / 'analysis').mkdir(exist_ok=True) 
    (trash_dir / 'utilities').mkdir(exist_ok=True)
    (trash_dir / 'misc').mkdir(exist_ok=True)
    
    print("📁 Created trash directory structure:")
    print("   trash/")
    print("   ├── debug/")
    print("   ├── analysis/") 
    print("   ├── utilities/")
    print("   └── misc/")
    
    # Categorize and show what would be moved
    moves = {
        'debug': [],
        'analysis': [],
        'utilities': [],
        'misc': []
    }
    
    for script in unused_scripts:
        script_name = os.path.basename(script).lower()
        
        if 'debug' in script_name:
            moves['debug'].append(script)
        elif any(word in script_name for word in ['analyze', 'view', 'export', 'evaluate']):
            moves['analysis'].append(script)
        elif any(word in script_name for word in ['install', 'create', 'load', 'lookup', 'scale', 'example', 'filter']):
            moves['utilities'].append(script)
        else:
            moves['misc'].append(script)
    
    print(f"\n📋 PROPOSED MOVES:")
    total_moves = 0
    for category, scripts in moves.items():
        if scripts:
            print(f"   📂 trash/{category}/ ({len(scripts)} files)")
            for script in scripts:
                print(f"      {script}")
                total_moves += 1
    
    print(f"\n📊 SUMMARY:")
    print(f"   Total Python files: {len(analyze_script_usage()) + len({f for f in os.listdir('.') if f.endswith('.py')})}")
    print(f"   Used by main pipeline: {len([f for f in os.listdir('.') if f.endswith('.py')]) - len(unused_scripts)}")
    print(f"   Ready to move to trash: {total_moves}")
    
    return moves


if __name__ == "__main__":
    create_trash_structure()
