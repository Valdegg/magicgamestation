#!/usr/bin/env python3
"""
Basic tests and experiments for MTG arbitrage system.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from mtg_arbitrage import data_loader, filter, evaluate, scrape
from mtg_arbitrage.utils import DEFAULT_CONFIG, calculate_min_sell_price

def test_profit_calculations():
    """Test basic profit calculation functions."""
    print("Testing profit calculations...")
    
    # Test minimum sell price calculation
    buy_price = 100.0
    target_margin = 0.12  # 12%
    fee_rate = 0.05       # 5%
    
    min_sell = calculate_min_sell_price(buy_price, target_margin, fee_rate)
    print(f"Buy at €{buy_price}, need to sell at minimum €{min_sell:.2f} for {target_margin*100:.0f}% margin")
    
    # Verify the calculation
    net_profit = min_sell * (1 - fee_rate) - buy_price
    actual_margin = net_profit / buy_price
    print(f"Verification: Net profit €{net_profit:.2f}, actual margin {actual_margin*100:.1f}%")
    
    assert abs(actual_margin - target_margin) < 0.001, "Margin calculation error"
    print("✅ Profit calculations working correctly\n")

def test_data_loading():
    """Test data loading with real Cardmarket data."""
    print("Testing data loading...")
    
    try:
        price_data = data_loader.load_data()
        
        print(f"Price data loaded: {len(price_data)} rows")
        
        if not price_data.empty:
            print(f"Columns: {list(price_data.columns)}")
            print("✅ Data loading working\n")
            return price_data
        else:
            print("❌ No data loaded")
            return None
        
    except Exception as e:
        print(f"❌ Data loading failed: {e}")
        print("Note: This requires access to actual Cardmarket price guide data")
        print("You need to provide a real price guide JSON file or API access\n")
        return None

def test_filtering():
    """Test card filtering logic."""
    print("Testing card filtering...")
    
    price_data = test_data_loading()
    if price_data is None:
        print("❌ Cannot test filtering without data\n")
        return None
    
    try:
        candidates = filter.find_candidates(price_data)
        
        print(f"Found {len(candidates)} candidates")
        
        if not candidates.empty:
            print("Sample candidate:")
            sample = candidates.iloc[0]
            print(f"  Name: {sample.get('Name', 'N/A')}")
            print(f"  LOWEX+: €{sample.get('LOWEX+', 0):.2f}")
            print(f"  TREND: €{sample.get('TREND', 0):.2f}")
            print(f"  Discount: {sample.get('trend_discount', 0)*100:.1f}%")
        
        print("✅ Filtering working\n")
        return candidates
        
    except Exception as e:
        print(f"❌ Filtering failed: {e}\n")
        return None

def test_evaluation():
    """Test card evaluation logic."""
    print("Testing card evaluation...")
    
    candidates = test_filtering()
    if candidates is None or candidates.empty:
        print("❌ Cannot test evaluation without candidates\n")
        return
    
    try:
        # Test single card evaluation
        sample_card = candidates.iloc[0]
        evaluation = evaluate.evaluate_card_profit(sample_card)
        
        print("Sample evaluation:")
        evaluate.print_evaluation_summary(evaluation)
        
        # Test batch evaluation
        buyable = evaluate.batch_evaluate_cards(candidates.head(3))
        print(f"Buyable cards from sample: {len(buyable)}")
        
        print("✅ Evaluation working\n")
        
    except Exception as e:
        print(f"❌ Evaluation failed: {e}\n")

def test_scraping():
    """Test scraping functionality."""
    print("Testing scraping...")
    
    try:
        # Create test card data
        test_card = {
            'idProduct': 1,
            'Name': 'Test Card',
            'LOWEX+': 75.0
        }
        
        scraper = scrape.CardmarketScraper()
        listings = scraper.fetch_top10(test_card)
        
        if listings:
            print(f"Fetched {len(listings)} listings")
            scrape.print_listings_summary(test_card['Name'], listings)
            
            # Test market analysis
            analysis = scrape.analyze_market_depth(listings)
            print(f"Market tightness: {analysis['market_tightness']*100:.1f}%")
            print("✅ Scraping working\n")
        else:
            print("❌ No listings returned")
            print("Note: Cardmarket scraping requires proper authentication and HTML parsing")
            print("This functionality needs to be implemented for production use\n")
        
    except Exception as e:
        print(f"❌ Scraping failed: {e}")
        print("Note: Real scraping requires Cardmarket access and HTML parsing implementation\n")

def run_all_tests():
    """Run all basic tests."""
    print("🧪 Running basic tests for MTG Arbitrage system")
    print("="*50)
    
    test_profit_calculations()
    test_data_loading()
    test_filtering()
    test_evaluation()
    test_scraping()
    
    print("✅ All tests completed!")

if __name__ == "__main__":
    run_all_tests()
