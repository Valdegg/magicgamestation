#!/usr/bin/env python3
"""
Evaluate real buyability using AVG7 (actual recent sales) as buy price.
This shows opportunities where recent sales (AVG7) are below trend prices.
"""

import sys
from mtg_arbitrage import data_loader
from mtg_arbitrage.utils import get_cardmarket_url, format_currency

def evaluate_real_buyability(limit: int = 20, min_discount: float = 0.15):
    """Evaluate buyability using AVG7 as real buy price."""
    
    print("📈 Real Buyability Analysis (AVG7 vs TREND)")
    print("=" * 60)
    
    # Load enriched data
    print("Loading data...")
    data = data_loader.load_data_with_names()
    
    if data.empty:
        print("❌ No data loaded.")
        return
    
    # Filter for analysis
    print("Analyzing real buyability...")
    
    # Filter criteria
    candidates = data[
        # Has expansion name
        (data['expansionName'].notna()) & 
        (data['expansionName'] != 'nan') &
        (data['expansionName'].astype(str) != 'nan') &
        
        # Price range
        (data['AVG7'] >= 50.0) & (data['AVG7'] <= 150.0) &
        
        # Has recent sales (liquidity)
        (data['AVG7'] > 0) &
        
        # Has trend data
        (data['TREND'] > 1.0)
    ].copy()
    
    print(f"Found {len(candidates)} cards with recent sales in €50-150 range")
    
    if candidates.empty:
        print("❌ No candidates found.")
        return
    
    # Calculate real discount (AVG7 vs TREND)
    candidates['real_discount'] = (candidates['TREND'] - candidates['AVG7']) / candidates['TREND']
    
    # Filter by minimum discount
    candidates = candidates[candidates['real_discount'] >= min_discount]
    
    print(f"Found {len(candidates)} cards with ≥{min_discount*100:.0f}% discount (AVG7 < TREND)")
    
    if candidates.empty:
        print(f"❌ No cards found with ≥{min_discount*100:.0f}% discount.")
        return
    
    # Sort by discount (best opportunities first)
    candidates = candidates.sort_values('real_discount', ascending=False)
    
    print(f"\n🎯 Top {min(limit, len(candidates))} Real Buy Opportunities:")
    print("=" * 60)
    
    # Show top opportunities
    for i, (_, card) in enumerate(candidates.head(limit).iterrows(), 1):
        card_id = card.get('idProduct')
        card_name = card.get('name', f"Card ID {card_id}")
        expansion_name = card.get('expansionName', 'Unknown')
        
        # Real prices
        avg7_price = card['AVG7']        # Real recent sales (your buy target)
        trend_price = card['TREND']      # Market trend
        discount = card['real_discount'] * 100
        
        # Calculate potential profit
        potential_profit = trend_price - avg7_price
        
        # Generate URL
        url = get_cardmarket_url(card_id, card_name, expansion_name, 'direct')
        
        print(f"{i:2d}. {card_name}")
        print(f"    Set: {expansion_name}")
        print(f"    Recent sales (AVG7): {format_currency(avg7_price)} ← Your buy target")
        print(f"    Market trend: {format_currency(trend_price)}")
        print(f"    Discount: {discount:.1f}% below trend")
        print(f"    Potential gain: {format_currency(potential_profit)}")
        print(f"    URL: {url}")
        print()
    
    print("=" * 60)
    print("💡 STRATEGY:")
    print("- AVG7 = Recent sales prices (real market data)")
    print("- Look for cards selling near AVG7 prices")
    print("- If TREND > AVG7, card might be undervalued")
    print("- Buy near AVG7, sell when price moves toward TREND")
    print("- Check URLs to see current listings vs AVG7 prices")

def main():
    """Main function with command line arguments."""
    limit = 20
    min_discount = 0.15  # 15% minimum discount
    
    if len(sys.argv) > 1:
        try:
            limit = int(sys.argv[1])
        except ValueError:
            print("Usage: python evaluate_real_buyability.py [number_of_cards] [min_discount]")
            print("Examples:")
            print("  python evaluate_real_buyability.py")
            print("  python evaluate_real_buyability.py 10")
            print("  python evaluate_real_buyability.py 15 0.20")
            return
    
    if len(sys.argv) > 2:
        try:
            min_discount = float(sys.argv[2])
        except ValueError:
            print("Minimum discount must be a decimal (e.g., 0.15 for 15%)")
            return
    
    evaluate_real_buyability(limit, min_discount)

if __name__ == "__main__":
    main()
