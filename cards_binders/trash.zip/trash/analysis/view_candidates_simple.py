#!/usr/bin/env python3
"""
Simple, readable view of MTG arbitrage candidates.
Shows just the essential info: name, set, prices, and URL.
"""

import sys
from mtg_arbitrage import data_loader, filter
from mtg_arbitrage.utils import get_cardmarket_url, format_currency

def get_liquidity_indicator(card_data):
    """Get a simple liquidity indicator."""
    avg1 = card_data.get('AVG1', 0)
    avg7 = card_data.get('AVG7', 0)
    avg30 = card_data.get('AVG30', 0)
    
    if avg1 > 0:
        return "🟢"  # Daily sales - very liquid
    elif avg7 > 0 and avg30 > 0:
        # Check price stability
        variation = abs(avg7 - avg30) / avg30 * 100 if avg30 > 0 else 100
        if variation < 15:
            return "🟡"  # Weekly + stable - good liquidity
        else:
            return "🟠"  # Weekly but volatile - fair liquidity
    elif avg7 > 0:
        return "🟠"  # Only weekly - fair liquidity
    else:
        return "🔴"  # Poor liquidity

def format_simple_candidate_info(card_data: dict, rank: int) -> str:
    """Format a single candidate's info in a simple, readable way."""
    card_id = card_data.get('idProduct')
    card_name = card_data.get('name', f"Card ID {card_id}")
    expansion_name = card_data.get('expansionName', 'Unknown Set')
    
    # Price info
    buy_price = card_data.get('AVG7', 0)
    trend_price = card_data.get('TREND', 0)
    avg30_price = card_data.get('AVG30', 0)
    discount = card_data.get('real_discount', card_data.get('trend_discount', 0)) * 100
    
    # Liquidity indicator
    liquidity = get_liquidity_indicator(card_data)
    
    # Generate URL
    url = get_cardmarket_url(card_id, card_name, expansion_name, 'direct')
    
    # Format the output
    lines = [
        f"{rank:2d}. {card_name} {liquidity}",
        f"    Set: {expansion_name}",
        f"    AVG7: {format_currency(buy_price)} | AVG30: {format_currency(avg30_price)} | Trend: {format_currency(trend_price)} | Discount: {discount:.1f}%",
        f"    URL: {url}",
        ""
    ]
    
    return "\n".join(lines)

def show_simple_candidates(limit: int = 20):
    """Show candidates in a simple, readable format."""
    print("🃏 MTG Arbitrage Candidates - Simple View")
    print("=" * 60)
    
    # Load enriched data with names and expansion info
    print("Loading data...")
    data = data_loader.load_data_with_names()
    
    if data.empty:
        print("❌ No data loaded. Make sure to run the system first.")
        return
    
    # Filter candidates using the same criteria as the main analysis
    print("Finding candidates...")
    candidates = filter.find_candidates(
        data,
        price_min=60.0,
        price_max=200.0,
        trend_discount_threshold=0.05
    )
    
    # Filter out cards with missing or invalid expansion names
    if not candidates.empty:
        initial_count = len(candidates)
        candidates = candidates[
            (candidates['expansionName'].notna()) & 
            (candidates['expansionName'] != 'nan') &
            (candidates['expansionName'].astype(str) != 'nan')
        ]
        filtered_count = len(candidates)
        print(f"Filtered out {initial_count - filtered_count} cards with missing/invalid set names")
    
    if candidates.empty:
        print("❌ No candidates found with current criteria.")
        return
    
    print(f"\n📋 Top {min(limit, len(candidates))} Candidates:")
    print("=" * 60)
    
    # Show top candidates
    for i, (_, card) in enumerate(candidates.head(limit).iterrows(), 1):
        card_info = format_simple_candidate_info(card.to_dict(), i)
        print(card_info)
    
    print("=" * 60)
    print(f"💡 Showing {min(limit, len(candidates))} of {len(candidates)} total candidates")
    print("💡 AVG7 = 7-day average sales price | AVG30 = 30-day average sales price")
    print("💡 Discount = how much AVG7 is below trend (investment opportunity)")
    print("💡 Liquidity: 🟢 Daily sales | 🟡 Weekly+stable | 🟠 Weekly only | 🔴 Poor")

def main():
    """Main function with command line argument support."""
    limit = 100  # Default limit
    
    if len(sys.argv) > 1:
        try:
            limit = int(sys.argv[1])
        except ValueError:
            print("Usage: python view_candidates_simple.py [number_of_cards]")
            print("Example: python view_candidates_simple.py 10")
            return
    
    show_simple_candidates(limit)

if __name__ == "__main__":
    main()
