#!/usr/bin/env python3
"""
Script to view saved analysis results.
"""

import json
import pandas as pd
from pathlib import Path
from mtg_arbitrage.results_saver import get_results_dir, list_saved_results

def view_latest_candidates():
    """View the latest candidate analysis."""
    results_dir = Path(get_results_dir())
    
    # Find latest candidates file
    candidate_files = sorted(results_dir.glob("candidates_*.json"))
    if not candidate_files:
        print("No candidate results found")
        return
    
    latest_file = candidate_files[-1]
    
    with open(latest_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    print(f"📊 Latest Candidates Analysis ({data['timestamp']})")
    print("="*60)
    print(f"Total candidates: {data['total_candidates']}")
    print(f"Price range: €{data['price_range']['min']:.2f} - €{data['price_range']['max']:.2f}")
    print(f"Average price: €{data['price_range']['avg']:.2f}")
    print(f"Discount range: {data['discount_range']['min']*100:.1f}% - {data['discount_range']['max']*100:.1f}%")
    print(f"Average discount: {data['discount_range']['avg']*100:.1f}%")
    
    print(f"\nTop 10 candidates:")
    for i, card in enumerate(data['candidates'][:10], 1):
        discount = card.get('trend_discount', 0) * 100
        print(f"{i:2d}. Card ID {card['idProduct']} - €{card['LOWEX+']:.2f} ({discount:.1f}% discount)")

def view_latest_buyable():
    """View the latest buyable cards analysis."""
    results_dir = Path(get_results_dir())
    
    # Find latest buyable file
    buyable_files = sorted(results_dir.glob("buyable_*.json"))
    if not buyable_files:
        print("No buyable results found")
        return
    
    latest_file = buyable_files[-1]
    
    with open(latest_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    print(f"💰 Latest Buyable Analysis ({data['timestamp']})")
    print("="*60)
    print(f"Total buyable: {data['summary']['total_buyable']}")
    print(f"Total investment: €{data['summary']['total_investment_required']:.2f}")
    print(f"Average margin: {data['summary']['average_margin']*100:.1f}%")
    print(f"Target margin: {data['summary']['target_margin']*100:.1f}%")
    
    print(f"\nTop opportunities:")
    for i, card in enumerate(data['top_opportunities'], 1):
        margin = card.get('best_scenario_margin', 0) * 100
        print(f"{i:2d}. Card ID {card['idProduct']} - Buy €{card['LOWEX+']:.2f}, Margin {margin:.1f}%")

def view_latest_recommendations():
    """View the latest final recommendations."""
    results_dir = Path(get_results_dir())
    
    # Find latest recommendations file
    rec_files = sorted(results_dir.glob("final_recommendations_*.json"))
    if not rec_files:
        print("No final recommendations found")
        return
    
    latest_file = rec_files[-1]
    
    with open(latest_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    print(f"🎯 Latest Final Recommendations ({data['timestamp']})")
    print("="*60)
    print(f"Total recommendations: {data['summary']['total_recommendations']}")
    print(f"Total investment: €{data['summary']['total_investment']:.2f}")
    print(f"Expected profit: €{data['summary']['total_expected_profit']:.2f}")
    print(f"Overall ROI: {data['summary']['overall_roi']*100:.1f}%")
    
    if data['recommendations']:
        print(f"\nRecommendations:")
        for i, rec in enumerate(data['recommendations'], 1):
            print(f"{i}. {rec['card_name']}")
            print(f"   Buy: €{rec['buy_price']:.2f} → List: €{rec['list_price']:.2f}")
            print(f"   Profit: €{rec['net_profit']:.2f} ({rec['margin']*100:.1f}%)")
            print(f"   Target rank: {rec['target_rank']}")
            print()

def view_latest_summary():
    """View the latest analysis summary."""
    results_dir = Path(get_results_dir())
    
    # Find latest summary file
    summary_files = sorted(results_dir.glob("analysis_summary_*.json"))
    if not summary_files:
        print("No analysis summaries found")
        return
    
    latest_file = summary_files[-1]
    
    with open(latest_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    summary = data['analysis_summary']
    rates = summary['success_rate']
    
    print(f"📈 Latest Analysis Summary ({data['timestamp']})")
    print("="*60)
    print(f"Total cards analyzed: {summary['total_cards_analyzed']:,}")
    print(f"Candidates found: {summary['candidates_found']} ({rates['candidate_rate']:.2f}%)")
    print(f"Buyable cards: {summary['buyable_cards']} ({rates['buyable_rate']:.2f}%)")
    print(f"Final recommendations: {summary['final_recommendations']} ({rates['recommendation_rate']:.2f}%)")
    
    print(f"\nConfiguration used:")
    for key, value in data['config'].items():
        if isinstance(value, float):
            if key.endswith('_margin') or key.endswith('_fee') or key.endswith('_threshold'):
                print(f"  {key}: {value*100:.1f}%")
            else:
                print(f"  {key}: €{value:.2f}")
        else:
            print(f"  {key}: {value}")

def main():
    """Main function to view results."""
    print("🔍 MTG Arbitrage Results Viewer")
    print("="*40)
    
    print("\nAvailable options:")
    print("1. List all saved files")
    print("2. View latest candidates")
    print("3. View latest buyable cards")
    print("4. View latest recommendations")
    print("5. View latest analysis summary")
    print("6. View all latest results")
    
    choice = input("\nEnter choice (1-6): ").strip()
    
    if choice == "1":
        list_saved_results()
    elif choice == "2":
        view_latest_candidates()
    elif choice == "3":
        view_latest_buyable()
    elif choice == "4":
        view_latest_recommendations()
    elif choice == "5":
        view_latest_summary()
    elif choice == "6":
        print()
        view_latest_summary()
        print("\n" + "="*60 + "\n")
        view_latest_candidates()
        print("\n" + "="*60 + "\n")
        view_latest_buyable()
        print("\n" + "="*60 + "\n")
        view_latest_recommendations()
    else:
        print("Invalid choice")

if __name__ == "__main__":
    main()
