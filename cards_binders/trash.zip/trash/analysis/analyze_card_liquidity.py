#!/usr/bin/env python3
"""
Analyze card liquidity patterns to understand sales frequency.

This script helps understand how often cards sell and identifies
illiquid cards that should be avoided for arbitrage.
"""

import pandas as pd
from mtg_arbitrage.data_loader import load_data_with_names
from mtg_arbitrage.utils import format_currency


def analyze_liquidity_patterns():
    """Analyze liquidity patterns in the data."""
    print("🔍 CARD LIQUIDITY ANALYSIS")
    print("=" * 50)
    
    # Load data
    data = load_data_with_names()
    if data.empty:
        print("❌ No data available")
        return
    
    # Focus on cards in our price range
    price_range = data[
        (data['AVG7'] >= 60) & 
        (data['AVG7'] <= 200) &
        (data['TREND'] > data['AVG7'])  # Has discount potential
    ]
    
    print(f"📊 Analyzing {len(price_range):,} cards in €60-200 price range with discount potential")
    print()
    
    # Categorize by liquidity
    categories = {
        'Daily Sales (AVG1 > 0)': price_range['AVG1'] > 0,
        'Weekly Sales (AVG7 > 0, AVG1 = 0)': (price_range['AVG7'] > 0) & (price_range['AVG1'] == 0),
        'Monthly Sales Only (AVG30 > 0, AVG7 = 0)': (price_range['AVG30'] > 0) & (price_range['AVG7'] == 0),
        'Quarterly+ Sales (All AVG = 0)': (price_range['AVG1'] == 0) & (price_range['AVG7'] == 0) & (price_range['AVG30'] == 0)
    }
    
    print("📈 LIQUIDITY BREAKDOWN:")
    for category, condition in categories.items():
        count = condition.sum()
        percentage = (count / len(price_range)) * 100
        print(f"   {category}: {count:,} cards ({percentage:.1f}%)")
    
    print()
    
    # Analyze the "Monthly Sales Only" category (potential problem cards)
    monthly_only = price_range[
        (price_range['AVG30'] > 0) & 
        (price_range['AVG7'] == 0)
    ]
    
    if len(monthly_only) > 0:
        print("⚠️  MONTHLY-ONLY SALES ANALYSIS:")
        print(f"   Cards: {len(monthly_only):,}")
        
        # Check price volatility for monthly-only cards
        monthly_only = monthly_only.copy()
        monthly_only['monthly_vs_trend'] = abs(monthly_only['AVG30'] - monthly_only['TREND']) / monthly_only['TREND']
        
        stable_monthly = monthly_only[monthly_only['monthly_vs_trend'] < 0.3]  # Within 30% of trend
        volatile_monthly = monthly_only[monthly_only['monthly_vs_trend'] >= 0.3]  # More than 30% from trend
        
        print(f"   Stable pricing (±30% of trend): {len(stable_monthly):,} cards")
        print(f"   Volatile pricing (>30% from trend): {len(volatile_monthly):,} cards")
        print()
        
        # Show examples of problematic cards
        if len(volatile_monthly) > 0:
            print("🚨 EXAMPLES OF ILLIQUID/VOLATILE CARDS TO AVOID:")
            examples = volatile_monthly.head(5)
            for _, card in examples.iterrows():
                name = card.get('name', f"Card ID {card.get('idProduct')}")
                expansion = card.get('expansionName', 'Unknown')
                avg30 = card.get('AVG30', 0)
                trend = card.get('TREND', 0)
                volatility = card['monthly_vs_trend'] * 100
                
                print(f"   • {name} ({expansion})")
                print(f"     Monthly: {format_currency(avg30)} | Trend: {format_currency(trend)} | Volatility: {volatility:.1f}%")
            print()
    
    # Show examples of good liquidity cards
    good_liquidity = price_range[
        (price_range['AVG7'] > 0) |  # Weekly sales, or
        (
            (price_range['AVG30'] > 0) & 
            (price_range['AVG7'] == 0) &
            (abs(price_range['AVG30'] - price_range['TREND']) / price_range['TREND'] < 0.3)
        )
    ]
    
    print("✅ EXAMPLES OF GOOD LIQUIDITY CARDS:")
    examples = good_liquidity.head(5)
    for _, card in examples.iterrows():
        name = card.get('name', f"Card ID {card.get('idProduct')}")
        expansion = card.get('expansionName', 'Unknown')
        avg1 = card.get('AVG1', 0)
        avg7 = card.get('AVG7', 0)
        avg30 = card.get('AVG30', 0)
        
        liquidity_type = "Daily" if avg1 > 0 else "Weekly" if avg7 > 0 else "Monthly"
        
        print(f"   • {name} ({expansion}) - {liquidity_type} sales")
        print(f"     AVG1: {format_currency(avg1)} | AVG7: {format_currency(avg7)} | AVG30: {format_currency(avg30)}")
    
    print()
    
    # Summary recommendations
    avoid_count = len(price_range) - len(good_liquidity)
    print("💡 LIQUIDITY FILTERING IMPACT:")
    print(f"   Total candidates before filtering: {len(price_range):,}")
    print(f"   Good liquidity candidates: {len(good_liquidity):,}")
    print(f"   Cards to avoid (illiquid): {avoid_count:,}")
    print(f"   Filtering removes: {(avoid_count/len(price_range))*100:.1f}% of candidates")


def show_liquidity_examples():
    """Show specific examples of different liquidity levels."""
    print("\n🔍 LIQUIDITY EXAMPLES")
    print("=" * 30)
    
    data = load_data_with_names()
    if data.empty:
        return
    
    # Filter to our price range
    candidates = data[
        (data['AVG7'] >= 60) & 
        (data['AVG7'] <= 200) &
        (data['expansionName'].notna()) &
        (data['name'].notna())
    ]
    
    print("🟢 EXCELLENT LIQUIDITY (Daily sales):")
    daily_sales = candidates[candidates['AVG1'] > 0].head(3)
    for _, card in daily_sales.iterrows():
        name = card.get('name', 'Unknown')
        print(f"   • {name}: Daily={format_currency(card['AVG1'])}, Weekly={format_currency(card['AVG7'])}")
    
    print("\n🟡 GOOD LIQUIDITY (Weekly sales):")
    weekly_sales = candidates[(candidates['AVG7'] > 0) & (candidates['AVG1'] == 0)].head(3)
    for _, card in weekly_sales.iterrows():
        name = card.get('name', 'Unknown')
        print(f"   • {name}: Weekly={format_currency(card['AVG7'])}, Monthly={format_currency(card['AVG30'])}")
    
    print("\n🔴 POOR LIQUIDITY (Monthly only):")
    monthly_only = candidates[
        (candidates['AVG30'] > 0) & 
        (candidates['AVG7'] == 0) & 
        (candidates['AVG1'] == 0)
    ].head(3)
    for _, card in monthly_only.iterrows():
        name = card.get('name', 'Unknown')
        print(f"   • {name}: Monthly={format_currency(card['AVG30'])}, Trend={format_currency(card['TREND'])}")


def main():
    """Main analysis function."""
    analyze_liquidity_patterns()
    show_liquidity_examples()
    
    print("\n💡 RECOMMENDATIONS:")
    print("   ✅ Prefer cards with daily/weekly sales")
    print("   🟡 Monthly-only cards are risky but may be acceptable if stable")
    print("   ❌ Avoid cards with only quarterly sales or high volatility")
    print("   📊 The new filter removes illiquid cards automatically")


if __name__ == "__main__":
    main()
