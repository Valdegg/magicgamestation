#!/usr/bin/env python3
"""
Export MTG arbitrage candidates to a simple CSV file.
Perfect for opening in Excel or Google Sheets.
"""

import os
import csv
import sys
from datetime import datetime
from mtg_arbitrage import data_loader, filter
from mtg_arbitrage.utils import get_cardmarket_url

def export_candidates_csv(filename: str = None, limit: int = 50):
    """Export candidates to CSV format."""
    
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"mtg_candidates_{timestamp}.csv"
    
    print("🃏 MTG Arbitrage Candidates - CSV Export")
    print("=" * 50)
    
    # Load enriched data with names and expansion info
    print("Loading data...")
    data = data_loader.load_data_with_names()
    
    if data.empty:
        print("❌ No data loaded. Make sure to run the system first.")
        return
    
    # Filter candidates using the same criteria as the main analysis
    print("Finding candidates...")
    candidates = filter.find_candidates(
        data,
        price_min=50.0,
        price_max=150.0,
        trend_discount_threshold=0.15
    )
    
    # Filter out cards with missing or invalid expansion names
    if not candidates.empty:
        initial_count = len(candidates)
        candidates = candidates[
            (candidates['expansionName'].notna()) & 
            (candidates['expansionName'] != 'nan') &
            (candidates['expansionName'].astype(str) != 'nan')
        ]
        filtered_count = len(candidates)
        print(f"Filtered out {initial_count - filtered_count} cards with missing/invalid set names")
    
    if candidates.empty:
        print("❌ No candidates found with current criteria.")
        return
    
    # Prepare CSV data
    csv_data = []
    for i, (_, card) in enumerate(candidates.head(limit).iterrows(), 1):
        card_id = card.get('idProduct')
        card_name = card.get('name', f"Card ID {card_id}")
        expansion_name = card.get('expansionName', 'Unknown')
        
        # Clean up expansion name
        if str(expansion_name) == 'nan':
            expansion_name = 'Unknown'
        
        # Price info
        buy_price = card.get('LOWEX+', 0)
        trend_price = card.get('TREND', 0)
        discount = card.get('trend_discount', 0) * 100
        avg7 = card.get('AVG7', 0)
        
        # Generate URLs
        direct_url = get_cardmarket_url(card_id, card_name, expansion_name, 'direct')
        search_url = get_cardmarket_url(card_id, card_name, expansion_name, 'search_name')
        
        csv_data.append({
            'Rank': i,
            'Card Name': card_name,
            'Set': expansion_name,
            'Buy Price (EUR)': f"{buy_price:.2f}",
            'Trend Price (EUR)': f"{trend_price:.2f}",
            'Discount (%)': f"{discount:.1f}%",
            'Recent Sales (AVG7)': f"{avg7:.2f}",
            'Direct URL': direct_url,
            'Search URL': search_url,
            'Card ID': card_id
        })
    
    # Write CSV file
    fieldnames = [
        'Rank', 'Card Name', 'Set', 'Buy Price (EUR)', 'Trend Price (EUR)', 
        'Discount (%)', 'Recent Sales (AVG7)', 'Direct URL', 'Search URL', 'Card ID'
    ]
    
    with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(csv_data)
    
    print(f"\n✅ Exported {len(csv_data)} candidates to: {filename}")
    print(f"📊 Total candidates found: {len(candidates)}")
    print(f"📁 File size: {os.path.getsize(filename):,} bytes")
    
    print(f"\n💡 Open with:")
    print(f"  Excel: File -> Open -> {filename}")
    print(f"  Google Sheets: File -> Import -> Upload -> {filename}")
    print(f"  Command line: open {filename}")

def main():
    """Main function with command line argument support."""
    filename = None
    limit = 50
    
    if len(sys.argv) > 1:
        if sys.argv[1].endswith('.csv'):
            filename = sys.argv[1]
            if len(sys.argv) > 2:
                try:
                    limit = int(sys.argv[2])
                except ValueError:
                    print("Usage: python export_candidates_csv.py [filename.csv] [number_of_cards]")
                    return
        else:
            try:
                limit = int(sys.argv[1])
            except ValueError:
                print("Usage: python export_candidates_csv.py [filename.csv] [number_of_cards]")
                print("Examples:")
                print("  python export_candidates_csv.py")
                print("  python export_candidates_csv.py 20")
                print("  python export_candidates_csv.py my_cards.csv")
                print("  python export_candidates_csv.py my_cards.csv 30")
                return
    
    export_candidates_csv(filename, limit)

if __name__ == "__main__":
    main()
