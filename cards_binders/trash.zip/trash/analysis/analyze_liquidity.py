#!/usr/bin/env python3
"""
Analyze card liquidity based on sales frequency and price stability.
"""

import sys
from mtg_arbitrage import data_loader
from mtg_arbitrage.utils import get_cardmarket_url, format_currency

def calculate_liquidity_score(card_data):
    """Calculate a liquidity score from 0-100 based on sales frequency and stability."""
    
    avg1 = card_data.get('AVG1', 0)
    avg7 = card_data.get('AVG7', 0)
    avg30 = card_data.get('AVG30', 0)
    
    # Base score from sales frequency
    frequency_score = 0
    if avg1 > 0:
        frequency_score += 40  # Daily sales = very liquid
    if avg7 > 0:
        frequency_score += 35  # Weekly sales = liquid
    if avg30 > 0:
        frequency_score += 25  # Monthly sales = some liquidity
    
    # Price stability bonus (less variation = more liquid)
    stability_bonus = 0
    if avg7 > 0 and avg30 > 0:
        variation = abs(avg7 - avg30) / avg30 * 100 if avg30 > 0 else 100
        if variation < 5:
            stability_bonus = 25    # Very stable
        elif variation < 15:
            stability_bonus = 15    # Stable
        elif variation < 30:
            stability_bonus = 5     # Moderate
        # No bonus for high variation
    
    total_score = min(100, frequency_score + stability_bonus)
    return total_score

def get_liquidity_rating(score):
    """Convert liquidity score to rating."""
    if score >= 85:
        return "🟢 Excellent", "Sells within days"
    elif score >= 70:
        return "🟡 Good", "Sells within 1-2 weeks"
    elif score >= 50:
        return "🟠 Fair", "Sells within 1 month"
    elif score >= 25:
        return "🔴 Poor", "May take months to sell"
    else:
        return "⚫ Very Poor", "Very difficult to sell"

def analyze_liquidity(limit: int = 20):
    """Analyze liquidity of investment candidates."""
    
    print("💧 MTG Card Liquidity Analysis")
    print("=" * 50)
    
    # Load data
    print("Loading data...")
    data = data_loader.load_data_with_names()
    
    if data.empty:
        print("❌ No data loaded.")
        return
    
    # Filter for investment candidates (with recent sales and good discounts)
    candidates = data[
        # Has expansion name
        (data['expansionName'].notna()) & 
        (data['expansionName'] != 'nan') &
        (data['expansionName'].astype(str) != 'nan') &
        
        # Price range
        (data['AVG7'] >= 50.0) & (data['AVG7'] <= 150.0) &
        
        # Has some sales data
        (data['AVG7'] > 0) &
        
        # Has trend data for discount calculation
        (data['TREND'] > 1.0)
    ].copy()
    
    if candidates.empty:
        print("❌ No candidates found.")
        return
    
    # Calculate liquidity scores and discounts
    candidates['liquidity_score'] = candidates.apply(calculate_liquidity_score, axis=1)
    candidates['real_discount'] = (candidates['TREND'] - candidates['AVG7']) / candidates['TREND']
    
    # Filter for decent opportunities (10%+ discount)
    candidates = candidates[candidates['real_discount'] >= 0.10]
    
    # Sort by liquidity score (most liquid first)
    candidates = candidates.sort_values('liquidity_score', ascending=False)
    
    print(f"Found {len(candidates)} liquid investment candidates")
    print(f"\n🏆 Top {min(limit, len(candidates))} Most Liquid Opportunities:")
    print("=" * 70)
    
    for i, (_, card) in enumerate(candidates.head(limit).iterrows(), 1):
        card_id = card.get('idProduct')
        card_name = card.get('name', f"Card ID {card_id}")
        expansion_name = card.get('expansionName', 'Unknown')
        
        # Liquidity metrics
        liquidity_score = card['liquidity_score']
        rating, description = get_liquidity_rating(liquidity_score)
        
        # Price data
        avg1 = card['AVG1']
        avg7 = card['AVG7']
        avg30 = card['AVG30']
        trend = card['TREND']
        discount = card['real_discount'] * 100
        
        # URL
        url = get_cardmarket_url(card_id, card_name, expansion_name, 'direct')
        
        print(f"{i:2d}. {card_name} ({expansion_name})")
        print(f"    Liquidity: {rating} (Score: {liquidity_score}/100)")
        print(f"    {description}")
        print(f"    Recent sales: {format_currency(avg7)} | Trend: {format_currency(trend)} | Discount: {discount:.1f}%")
        
        # Sales frequency details
        sales_detail = []
        if avg1 > 0:
            sales_detail.append(f"Daily: {format_currency(avg1)}")
        if avg7 > 0:
            sales_detail.append(f"Weekly: {format_currency(avg7)}")
        if avg30 > 0:
            sales_detail.append(f"Monthly: {format_currency(avg30)}")
        
        if sales_detail:
            print(f"    Sales: {' | '.join(sales_detail)}")
        
        print(f"    URL: {url}")
        print()
    
    print("=" * 70)
    print("💡 LIQUIDITY GUIDE:")
    print("- Excellent (85+): Cards that sell quickly, easy to exit")
    print("- Good (70-84): Regular sales, reasonable exit timeline")  
    print("- Fair (50-69): Occasional sales, may take time to sell")
    print("- Poor (<50): Infrequent sales, difficult to exit quickly")

def main():
    """Main function with command line arguments."""
    limit = 20
    
    if len(sys.argv) > 1:
        try:
            limit = int(sys.argv[1])
        except ValueError:
            print("Usage: python analyze_liquidity.py [number_of_cards]")
            print("Example: python analyze_liquidity.py 15")
            return
    
    analyze_liquidity(limit)

if __name__ == "__main__":
    main()
