#!/usr/bin/env python3
"""
Quick card lookup script - find card details and URLs by ID.
"""

import sys
from mtg_arbitrage import data_loader
from mtg_arbitrage.utils import get_cardmarket_url, print_card_lookup_info, format_currency

def lookup_card(card_id: int):
    """Look up a card by its idProduct."""
    print(f"🔍 Looking up Card ID {card_id}...")
    
    # Load enriched data to find the card with names
    data = data_loader.load_data_with_names()
    
    # Find the specific card
    card_row = data[data['idProduct'] == card_id]
    
    if card_row.empty:
        print(f"❌ Card ID {card_id} not found in price guide data")
        print(f"💡 You can still try these URLs:")
        print(f"   Direct: {get_cardmarket_url(card_id, None, 'direct')}")
        print(f"   Search: {get_cardmarket_url(card_id, None, 'search')}")
        return
    
    # Get card data
    card_data = card_row.iloc[0].to_dict()
    
    # Print detailed info
    print_card_lookup_info(card_data)
    
    # Additional price details
    print(f"\n📊 Price Details:")
    if 'LOW' in card_data:
        print(f"   LOW (any condition): {format_currency(card_data['LOW'])}")
    if 'AVG' in card_data and card_data['AVG'] > 0:
        print(f"   AVG (average price): {format_currency(card_data['AVG'])}")
    if 'AVG7' in card_data:
        print(f"   AVG7 (7-day average): {format_currency(card_data['AVG7'])}")
    if 'AVG30' in card_data:
        print(f"   AVG30 (30-day average): {format_currency(card_data['AVG30'])}")

def main():
    if len(sys.argv) != 2:
        print("Usage: python lookup_card.py <card_id>")
        print("\nExample: python lookup_card.py 6993")
        print("\nOr try some of our top candidates:")
        print("  python lookup_card.py 6993")
        print("  python lookup_card.py 253844")
        print("  python lookup_card.py 605025")
        return
    
    try:
        card_id = int(sys.argv[1])
        lookup_card(card_id)
    except ValueError:
        print("❌ Card ID must be a number")

if __name__ == "__main__":
    main()
