#!/usr/bin/env python3
"""
Regenerate the combined HTML from the most recent JSON files.
No need to re-run the full pipeline!
"""

import sys
import os
from datetime import datetime
import glob

# Add parent directory to path to import from root
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from analyze_sellers import generate_combined_html

def get_latest(pattern):
    """Get the most recent file matching pattern."""
    files = glob.glob(pattern)
    return max(files, key=os.path.getctime) if files else None

def main():
    print("🔍 Finding most recent JSON files...\n")
    
    json_files = []
    
    # Get latest from each source
    reservedlist = get_latest('results/wishlist_reservedlist_*.json')
    if reservedlist:
        json_files.append(('Reserved List', reservedlist))
        print(f'  ✓ Reserved List: {os.path.basename(reservedlist)}')
    
    wishlist = get_latest('results/wishlist_2*.json')
    if wishlist and 'deck' not in wishlist and 'reservedlist' not in wishlist:
        json_files.append(('Wishlist', wishlist))
        print(f'  ✓ Wishlist: {os.path.basename(wishlist)}')
    
    deck = get_latest('results/wishlist_deck_*.json')
    if deck:
        json_files.append(('Deck Wishlist', deck))
        print(f'  ✓ Deck: {os.path.basename(deck)}')
    
    candidates = get_latest('results/all_candidates_*.json')
    if candidates:
        json_files.append(('Candidates', candidates))
        print(f'  ✓ Candidates: {os.path.basename(candidates)}')
    
    if not json_files:
        print('❌ No JSON files found in results/')
        return 1
    
    # Generate combined HTML
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    combined_html = f'results/combined_{timestamp}.html'
    
    print(f'\n🔄 Generating combined HTML from {len(json_files)} sources...')
    try:
        generate_combined_html(json_files, combined_html)
        print(f'\n✅ Combined HTML: {combined_html}')
        print(f'   📊 Open in browser: file://{os.path.abspath(combined_html)}')
        return 0
    except Exception as e:
        print(f'\n❌ Error generating combined HTML: {e}')
        return 1

if __name__ == "__main__":
    sys.exit(main())

