#!/usr/bin/env python3
"""
Patch old JSON files to add source information based on filename.

Usage:
    python utilities/patch_json_sources.py results/wishlist_reservedlist_20251012_184852.json
"""

import json
import sys
import os

# Add parent directory to path to import from root
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def patch_json_file(json_file):
    """Add source field to existing JSON based on filename."""
    
    # Determine source from filename
    filename = os.path.basename(json_file).lower()
    if 'wishlist_reservedlist' in filename or 'reservedlist' in filename:
        source = 'Reserved List'
    elif 'wishlist_deck' in filename or 'deck' in filename:
        source = 'Deck Wishlist'
    elif 'wishlist' in filename:
        source = 'Wishlist'
    elif 'candidates' in filename:
        source = 'Price Candidates'
    else:
        source = 'Unknown'
    
    print(f"📂 Patching: {json_file}")
    print(f"   Source: {source}")
    
    # Load JSON
    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # Count updates
    updated_count = 0
    
    # Update all categories
    for category in ['excellent_deals', 'good_deals', 'expensive_deals', 'no_data']:
        if category in data:
            for item in data[category]:
                if 'source' not in item or item['source'] == 'Unknown':
                    item['source'] = source
                    updated_count += 1
    
    # Save updated JSON
    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    
    print(f"   ✅ Updated {updated_count} cards")
    return True

def main():
    if len(sys.argv) < 2:
        print("Usage: python patch_json_sources.py <json_file>")
        print("\nExample:")
        print("  python patch_json_sources.py results/wishlist_reservedlist_20251012_184852.json")
        return 1
    
    json_file = sys.argv[1]
    
    if not os.path.exists(json_file):
        print(f"❌ File not found: {json_file}")
        return 1
    
    success = patch_json_file(json_file)
    
    if success:
        print("\n✨ Done! Now regenerate the HTML:")
        print(f"   python utilities/regenerate_html.py {json_file}")
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())

