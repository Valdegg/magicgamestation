#!/usr/bin/env python3
"""
Manual verification helper for MTG arbitrage candidates.

This script opens candidate URLs in your browser so you can manually verify
current prices and availability, solving the AVG7 problem by letting you
check real-time listings yourself.

Usage:
    python utilities/manual_verification.py 5 3.0
"""

import webbrowser
import time
import sys
import os
from typing import List, Dict
import pandas as pd

# Add parent directory to path to import from root
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import our modules
from mtg_arbitrage.data_loader import load_data_with_names
from mtg_arbitrage import filter as mtg_filter
from mtg_arbitrage.utils import get_cardmarket_url, format_currency


def get_top_candidates(limit: int = 10) -> pd.DataFrame:
    """Get top arbitrage candidates."""
    print("📊 Loading candidate data...")
    
    # Load data
    data = load_data_with_names()
    if data.empty:
        print("❌ No data available")
        return pd.DataFrame()
    
    # Find candidates (using config defaults)
    from mtg_arbitrage.utils import DEFAULT_CONFIG
    candidates = mtg_filter.find_candidates(
        data,
        price_min=DEFAULT_CONFIG["price_min"],
        price_max=DEFAULT_CONFIG["price_max"],
        trend_discount_threshold=DEFAULT_CONFIG["trend_discount_threshold"]
    )
    
    # Filter out cards with missing expansion names
    if not candidates.empty:
        initial_count = len(candidates)
        candidates = candidates[
            (candidates['expansionName'].notna()) & 
            (candidates['expansionName'] != 'nan') &
            (candidates['expansionName'].astype(str) != 'nan')
        ]
        filtered_count = len(candidates)
        print(f"Filtered out {initial_count - filtered_count} cards with missing/invalid set names")
    
    return candidates.head(limit)


def format_candidate_info(card_data: dict, rank: int) -> str:
    """Format candidate info for manual verification."""
    card_id = card_data.get('idProduct')
    card_name = card_data.get('name', f"Card ID {card_id}")
    expansion_name = card_data.get('expansionName', 'Unknown Set')
    
    # Price info
    avg7 = card_data.get('AVG7', 0)
    avg30 = card_data.get('AVG30', 0)
    trend = card_data.get('TREND', 0)
    discount = card_data.get('real_discount', 0) * 100
    
    return f"""
{rank:2d}. {card_name}
    Set: {expansion_name}
    Recent sales (AVG7): {format_currency(avg7)}
    30-day average: {format_currency(avg30)}  
    Trend price: {format_currency(trend)}
    Discount: {discount:.1f}% (AVG7 vs TREND)
    
    💡 What to check:
    - Are there listings near €{avg7:.2f}? (recent sales price)
    - Are most listings closer to €{trend:.2f}? (trend price)
    - How many listings are available?
    - What conditions are available at good prices?
"""


def open_candidates_for_verification(candidates: pd.DataFrame, delay: float = 3.0):
    """Open candidate URLs in browser for manual verification."""
    print(f"\n🌐 Opening {len(candidates)} candidates in browser...")
    print(f"⏱️  {delay}s delay between tabs to avoid overwhelming your browser")
    print("\n" + "="*60)
    
    for i, (_, card) in enumerate(candidates.iterrows(), 1):
        # Display card info
        card_info = format_candidate_info(card.to_dict(), i)
        print(card_info)
        
        # Generate URL
        card_id = card.get('idProduct')
        card_name = card.get('name', f"Card ID {card_id}")
        expansion_name = card.get('expansionName')
        
        url = get_cardmarket_url(card_id, card_name, expansion_name, 'direct')
        print(f"    🔗 Opening: {url}")
        
        # Open in browser
        try:
            webbrowser.open(url)
            print(f"    ✅ Opened tab {i}/{len(candidates)}")
        except Exception as e:
            print(f"    ❌ Error opening URL: {e}")
        
        print("    " + "-"*50)
        
        # Delay between opens (except for last one)
        if i < len(candidates):
            print(f"    ⏳ Waiting {delay}s before next tab...")
            time.sleep(delay)
    
    print(f"\n✅ Opened {len(candidates)} tabs for manual verification")
    print("\n💡 VERIFICATION CHECKLIST:")
    print("   ✓ Check current cheapest prices")
    print("   ✓ Compare with AVG7 (recent sales)")
    print("   ✓ Look for quantity available")
    print("   ✓ Check seller ratings")
    print("   ✓ Consider shipping costs")
    print("   ✓ Verify card condition requirements")


def interactive_verification():
    """Interactive verification mode."""
    print("🃏 MTG Arbitrage Manual Verification Tool")
    print("="*50)
    
    try:
        # Get number of candidates to check
        while True:
            try:
                limit = input("\n📊 How many candidates to verify? (default: 5): ").strip()
                limit = int(limit) if limit else 5
                if limit > 0:
                    break
                print("Please enter a positive number")
            except ValueError:
                print("Please enter a valid number")
        
        # Get delay between tabs
        while True:
            try:
                delay = input(f"⏱️  Delay between browser tabs? (default: 3s): ").strip()
                delay = float(delay) if delay else 3.0
                if delay >= 0:
                    break
                print("Please enter a non-negative number")
            except ValueError:
                print("Please enter a valid number")
        
        # Load candidates
        candidates = get_top_candidates(limit)
        
        if candidates.empty:
            print("❌ No candidates found")
            return
        
        print(f"\n📋 Found {len(candidates)} candidates to verify")
        
        # Confirm before opening browsers
        confirm = input(f"\n🌐 Open {len(candidates)} browser tabs? (y/N): ").strip().lower()
        if confirm in ['y', 'yes']:
            open_candidates_for_verification(candidates, delay)
        else:
            print("👍 Verification cancelled")
            
            # Show candidates without opening
            print(f"\n📋 Top {len(candidates)} candidates:")
            for i, (_, card) in enumerate(candidates.iterrows(), 1):
                card_info = format_candidate_info(card.to_dict(), i)
                print(card_info)
                
                # Show URL for manual copy-paste
                card_id = card.get('idProduct')
                card_name = card.get('name', f"Card ID {card_id}")
                expansion_name = card.get('expansionName')
                url = get_cardmarket_url(card_id, card_name, expansion_name, 'direct')
                print(f"    🔗 URL: {url}")
                print("    " + "-"*50)
    
    except KeyboardInterrupt:
        print("\n\n👋 Verification cancelled by user")
    except Exception as e:
        print(f"\n❌ Error: {e}")


def batch_verification(limit: int = 5, delay: float = 3.0):
    """Batch verification mode (non-interactive)."""
    print("🃏 MTG Arbitrage Batch Verification")
    print("="*40)
    
    candidates = get_top_candidates(limit)
    
    if candidates.empty:
        print("❌ No candidates found")
        return
    
    open_candidates_for_verification(candidates, delay)


def main():
    """Main function with command line support."""
    if len(sys.argv) > 1:
        # Command line mode
        try:
            limit = int(sys.argv[1])
            delay = float(sys.argv[2]) if len(sys.argv) > 2 else 3.0
            batch_verification(limit, delay)
        except (ValueError, IndexError):
            print("Usage: python manual_verification.py [limit] [delay]")
            print("Example: python manual_verification.py 5 2.0")
    else:
        # Interactive mode
        interactive_verification()


if __name__ == "__main__":
    main()
