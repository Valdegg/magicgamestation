#!/usr/bin/env python3
"""
Regenerate HTML from existing JSON results without re-running the pipeline.

Usage:
    python utilities/regenerate_html.py results/wishlist_deck_20251012_163427.json
    python utilities/regenerate_html.py results/all_candidates_*.json
"""

import sys
import json
import os
import glob

# Add parent directory to path to import from root
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from analyze_sellers import analyze_deals
from analyze_sellers_combined import generate_html_with_rejected


def regenerate_html(json_file, threshold=7.0):
    """Regenerate HTML from existing JSON results."""
    
    if not os.path.exists(json_file):
        print(f"❌ File not found: {json_file}")
        return False
    
    print(f"📂 Loading: {json_file}")
    
    # Load the JSON data
    with open(json_file, 'r', encoding='utf-8') as f:
        results = json.load(f)
    
    # Analyze deals
    seller_deals = analyze_deals(results, threshold)
    
    if not seller_deals:
        print(f"⚠️  No seller deals found (≥{threshold}% below avg of #2-5)")
        return False
    
    # Sort by number of deals
    sorted_seller_deals = dict(sorted(
        seller_deals.items(),
        key=lambda x: len(x[1]['deals']),
        reverse=True
    ))
    
    # Count deals
    total_deals = sum(len(data['deals']) for data in sorted_seller_deals.values())
    multi_deal_sellers = sum(1 for data in sorted_seller_deals.values() if len(data['deals']) >= 2)
    
    print(f"✅ Found {total_deals} deals from {len(sorted_seller_deals)} sellers")
    print(f"   {multi_deal_sellers} sellers with multiple deals")
    
    # Generate HTML
    base_name = os.path.splitext(json_file)[0]
    html_file = f"{base_name}.html"
    
    generate_html_with_rejected(sorted_seller_deals, results, threshold, html_file)
    
    print(f"🌐 HTML regenerated: {html_file}")
    print(f"   Open in browser: file://{os.path.abspath(html_file)}")
    
    return True


def main():
    if len(sys.argv) < 2:
        print("Usage: python regenerate_html.py <json_file>")
        print("\nExamples:")
        print("  python regenerate_html.py results/wishlist_deck_20251012_163427.json")
        print("  python regenerate_html.py results/all_candidates_*.json")
        print("\nOr regenerate all recent JSON files:")
        print("  python regenerate_html.py --all")
        return 1
    
    if sys.argv[1] == '--all':
        # Regenerate all JSON files in results/
        json_files = glob.glob('results/*.json')
        # Exclude seller_deals JSON files
        json_files = [f for f in json_files if 'seller_deals' not in f and 'combined' not in f.lower()]
        
        if not json_files:
            print("❌ No JSON files found in results/")
            return 1
        
        # Sort by modification time (newest first) and take top 5
        json_files.sort(key=os.path.getmtime, reverse=True)
        json_files = json_files[:5]
        
        print(f"🔄 Regenerating HTML for {len(json_files)} most recent files:\n")
        
        success_count = 0
        for json_file in json_files:
            if regenerate_html(json_file):
                success_count += 1
            print()
        
        print(f"✅ Regenerated {success_count}/{len(json_files)} HTML files")
        return 0
    
    # Single file or glob pattern
    json_pattern = sys.argv[1]
    
    # Handle glob patterns
    if '*' in json_pattern:
        json_files = glob.glob(json_pattern)
        if not json_files:
            print(f"❌ No files matching: {json_pattern}")
            return 1
        
        # Use the most recent file
        json_file = max(json_files, key=os.path.getmtime)
        print(f"📌 Using most recent: {json_file}\n")
    else:
        json_file = json_pattern
    
    # Regenerate HTML
    success = regenerate_html(json_file)
    
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())

