#!/usr/bin/env python3
"""
Script to load real Cardmarket price guide data.

This script helps you load your actual price guide JSON file
and verify it works with the MTG Arbitrage system.
"""

import json
import shutil
from pathlib import Path
from mtg_arbitrage.utils import get_raw_data_dir, ensure_dir_exists
from datetime import datetime

def load_price_guide(source_path: str) -> bool:
    """
    Load a real price guide JSON file into the system.
    
    Args:
        source_path: Path to your price guide JSON file
        
    Returns:
        True if successful, False otherwise
    """
    source_file = Path(source_path)
    
    if not source_file.exists():
        print(f"❌ File not found: {source_path}")
        return False
    
    try:
        # Validate the JSON format
        with open(source_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if 'priceGuides' not in data:
            print("❌ Invalid format: missing 'priceGuides' array")
            return False
        
        print(f"✅ Valid JSON with {len(data['priceGuides'])} price entries")
        
        # Copy to the expected location
        raw_dir = get_raw_data_dir()
        ensure_dir_exists(raw_dir)
        
        today = datetime.now().strftime("%Y%m%d")
        target_path = Path(raw_dir) / f"priceguide_{today}.json"
        
        shutil.copy2(source_file, target_path)
        print(f"✅ Price guide loaded: {target_path}")
        
        return True
        
    except json.JSONDecodeError as e:
        print(f"❌ Invalid JSON format: {e}")
        return False
    except Exception as e:
        print(f"❌ Error loading file: {e}")
        return False

def main():
    """Main function to load real price guide data."""
    print("MTG Arbitrage - Real Data Loader")
    print("=" * 40)
    
    print("This script loads your real Cardmarket price guide JSON file.")
    
    # Get the source file path
    source_path = input("\nEnter path to your price guide JSON file: ").strip()
    
    if load_price_guide(source_path):
        print("\n🎉 Success! Your price guide data is now loaded.")
        print("You can run the MTG arbitrage system:")
        print("  python example.py")
        print("  python tests/test_basic.py")
    else:
        print("\n❌ Failed to load the price guide data.")
        print("Please check the file path and format.")

if __name__ == "__main__":
    main()
