#!/usr/bin/env python3
"""
Example script demonstrating the complete MTG arbitrage workflow.
"""

from mtg_arbitrage import data_loader, filter, evaluate, scrape, results_saver
from mtg_arbitrage.utils import DEFAULT_CONFIG, format_currency

def main():
    """Run the complete arbitrage analysis workflow."""
    print("🃏 MTG Arbitrage Helper - Example Workflow")
    print("="*50)
    
    # Configuration
    config = DEFAULT_CONFIG.copy()
    target_net = config["target_net_margin"]
    price_min = config["price_min"]
    price_max = config["price_max"]
    
    print(f"Configuration:")
    print(f"  Target margin: {target_net*100:.0f}%")
    print(f"  Price range: €{price_min} - €{price_max}")
    print(f"  Cardmarket fee: {config['cardmarket_fee']*100:.0f}%")
    print()
    
    # Step 1: Load daily data
    print("Step 1: Loading Cardmarket data with card names...")
    try:
        price_data = data_loader.load_data_with_names()
        
        if price_data.empty:
            print("❌ Failed to load data")
            print("\n💡 To use this system:")
            print("1. Run: python load_real_data.py")
            print("2. Point it to your actual Cardmarket price guide JSON file")
            print("3. Then run this example again")
            return
        
        print(f"✅ Loaded price data for {len(price_data)} cards")
        
    except Exception as e:
        print(f"❌ Error loading data: {e}")
        print("\n💡 To use this system:")
        print("1. Run: python load_real_data.py")
        print("2. Point it to your actual Cardmarket price guide JSON file")
        print("3. Then run this example again")
        return
    
    # Step 2: Filter to candidate rares
    print(f"\nStep 2: Finding candidate rares in €{price_min}-€{price_max} range...")
    try:
        candidates = filter.find_candidates(
            price_data,
            price_min=price_min, 
            price_max=price_max
        )
        
        if candidates.empty:
            print("❌ No candidates found")
            return
        
        # Add calculated fields for better analysis
        candidates = filter.add_calculated_fields(candidates)
        
        # Print summary
        filter.print_candidate_summary(candidates)
        
        # Save candidates
        results_saver.save_candidates(candidates, config)
        
        # Get top candidates
        top_candidates = filter.get_top_candidates(candidates, limit=10)
        
    except Exception as e:
        print(f"❌ Error filtering candidates: {e}")
        return
    
    # Step 3: Evaluate buyability
    print(f"\nStep 3: Evaluating buyability (target margin: {target_net*100:.0f}%)...")
    try:
        buyable = evaluate.batch_evaluate_cards(top_candidates, target_net=target_net)
        
        if buyable.empty:
            print("❌ No buyable cards found")
            return
        
        print(f"✅ Found {len(buyable)} buyable candidates")
        
        # Save buyable cards
        results_saver.save_buyable_cards(buyable, config)
        
        # Show top 5 buyable cards
        print(f"\nTop 5 buyable cards:")
        for i, (_, card) in enumerate(buyable.head(5).iterrows()):
            card_name = card.get('name') or card.get('Name', f"Card ID {card['idProduct']}")
            print(f"{i+1}. {card_name} - Recent sales: {format_currency(card['AVG7'])}, "
                  f"Trend: {format_currency(card['TREND'])}, "
                  f"Discount: {card.get('real_discount', 0)*100:.1f}%")
        
    except Exception as e:
        print(f"❌ Error evaluating buyability: {e}")
        return
    
    # Step 4: Fetch live top-10 listings and make final decisions
    print(f"\nStep 4: Checking live market data for top candidates...")
    
    scraper = scrape.CardmarketScraper()
    final_recommendations = []
    
    # Check top 3 buyable cards
    for i, (_, card) in enumerate(buyable.head(3).iterrows()):
        card_name = card.get('name') or card.get('Name', f"Card ID {card['idProduct']}")
        print(f"\nAnalyzing: {card_name}")
        
        try:
            # Fetch top-10 listings
            top10 = scraper.fetch_top10(card.to_dict())
            
            if not top10:
                print(f"  ❌ No listings found")
                continue
            
            # Print listings summary
            scrape.print_listings_summary(card_name, top10)
            
            # Check feasibility
            decision = evaluate.check_top10_feasibility(
                card.to_dict(), 
                top10, 
                target_net=target_net
            )
            
            if decision['buy']:
                print(f"  ✅ RECOMMENDED BUY")
                print(f"     Buy at: {format_currency(decision['buy_price'])}")
                print(f"     List at: {format_currency(decision['list_price'])}")
                print(f"     Target rank: {decision['target_rank']}")
                print(f"     Expected margin: {decision['margin']*100:.1f}%")
                print(f"     Net profit: {format_currency(decision['net_profit'])}")
                
                final_recommendations.append(decision)
            else:
                print(f"  ❌ NOT RECOMMENDED: {decision['reason']}")
                
        except Exception as e:
                print(f"  ❌ Error analyzing {card_name}: {e}")
    
    # Save final recommendations
    if final_recommendations:
        results_saver.save_final_recommendations(final_recommendations, config)
    
    # Save analysis summary
    results_saver.save_analysis_summary(
        total_cards=len(price_data),
        candidates_count=len(candidates),
        buyable_count=len(buyable),
        recommendations_count=len(final_recommendations),
        config=config
    )
    
    # Final summary
    print(f"\n" + "="*50)
    print(f"🎯 FINAL RECOMMENDATIONS")
    print(f"="*50)
    
    if final_recommendations:
        print(f"Found {len(final_recommendations)} profitable opportunities:")
        print()
        
        total_investment = 0
        total_expected_profit = 0
        
        for i, rec in enumerate(final_recommendations, 1):
            print(f"{i}. {rec['card_name']}")
            print(f"   💰 Buy: {format_currency(rec['buy_price'])}")
            print(f"   🏷️  List: {format_currency(rec['list_price'])}")
            print(f"   📈 Profit: {format_currency(rec['net_profit'])} ({rec['margin']*100:.1f}%)")
            print(f"   🎯 Target rank: {rec['target_rank']}")
            print()
            
            total_investment += rec['buy_price']
            total_expected_profit += rec['net_profit']
        
        print(f"💼 Total investment: {format_currency(total_investment)}")
        print(f"💎 Expected profit: {format_currency(total_expected_profit)}")
        print(f"📊 Overall ROI: {(total_expected_profit/total_investment)*100:.1f}%")
        
    else:
        print("No profitable opportunities found with current criteria.")
        print("\n💡 Suggestions:")
        print("  - Adjust price range")
        print("  - Lower target margin")
        print("  - Check different rarities")
        print("  - Try different expansions")
    
    print("\n🔄 Analysis complete!")
    print("\n📁 Results saved to data/results/ directory")
    print("💡 Use results_saver.list_saved_results() to see all saved files")

if __name__ == "__main__":
    main()
