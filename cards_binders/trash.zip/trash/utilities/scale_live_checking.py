#!/usr/bin/env python3
"""
Scalable live price checking strategies for large batches.

This script provides different approaches for checking many cards
while minimizing the risk of being blocked.
"""

import time
import random
from typing import List, Dict
from datetime import datetime, timedelta

# Import our modules
from live_price_check import LivePriceChecker
from fetch_live_listings_simple import SimpleBrowserScraper


class ScalablePriceChecker:
    """Scalable price checking with anti-blocking measures."""
    
    def __init__(self):
        self.scraper = None
        self.last_request_time = None
        self.requests_count = 0
        self.session_start = None
    
    def check_cards_batch(self, 
                         candidates_df, 
                         batch_size: int = 50,
                         delay_range: tuple = (3.0, 6.0),
                         break_duration: int = 300) -> List[dict]:
        """
        Check prices in batches with breaks to avoid blocking.
        
        Args:
            candidates_df: DataFrame of candidates to check
            batch_size: Cards per batch before taking a break
            delay_range: Delay between requests (seconds)
            break_duration: Break duration between batches (seconds)
            
        Returns:
            List of results
        """
        total_cards = len(candidates_df)
        all_results = []
        
        print(f"🎯 SCALABLE PRICE CHECKING")
        print(f"   Total cards: {total_cards}")
        print(f"   Batch size: {batch_size}")
        print(f"   Estimated time: {self._estimate_time(total_cards, delay_range, batch_size, break_duration)}")
        print()
        
        # Process in batches
        for batch_num in range(0, total_cards, batch_size):
            batch_end = min(batch_num + batch_size, total_cards)
            batch = candidates_df.iloc[batch_num:batch_end]
            
            print(f"📦 BATCH {batch_num//batch_size + 1}: Cards {batch_num+1}-{batch_end}")
            
            # Initialize fresh scraper for each batch
            self.scraper = SimpleBrowserScraper(delay_range=delay_range)
            self.session_start = datetime.now()
            self.requests_count = 0
            
            # Process batch
            batch_results = self._process_batch(batch)
            all_results.extend(batch_results)
            
            # Take a break between batches (except for last batch)
            if batch_end < total_cards:
                print(f"   ⏸️  Taking {break_duration//60}min break to avoid detection...")
                time.sleep(break_duration)
                print(f"   ▶️  Resuming...")
            
        print(f"\n✅ Completed checking {total_cards} cards")
        return all_results
    
    def _process_batch(self, batch) -> List[dict]:
        """Process a single batch of cards."""
        batch_results = []
        
        for i, (_, card) in enumerate(batch.iterrows(), 1):
            card_name = card.get('name', f"Card ID {card.get('idProduct')}")
            print(f"   {i:2d}/{len(batch)}: {card_name}")
            
            try:
                # Check live prices
                checker = LivePriceChecker(use_simple_scraper=True)
                live_analysis = checker.check_live_prices(card.to_dict())
                
                result = {
                    'card_data': card.to_dict(),
                    'live_analysis': live_analysis,
                    'batch_timestamp': datetime.now().isoformat()
                }
                
                batch_results.append(result)
                self.requests_count += 1
                
                # Show quick result
                if live_analysis and live_analysis.get('cheapest_good_condition'):
                    price = live_analysis['cheapest_good_condition']
                    avg7 = card.get('AVG7', 0)
                    diff_pct = (price - avg7) / avg7 * 100 if avg7 > 0 else 0
                    
                    if diff_pct <= 0:
                        print(f"      🎯 €{price:.2f} ({diff_pct:+.1f}% vs AVG7) - GOOD DEAL!")
                    else:
                        print(f"      ❌ €{price:.2f} ({diff_pct:+.1f}% vs AVG7)")
                else:
                    print(f"      ⚠️  No EX+ data available")
            
            except Exception as e:
                print(f"      ❌ Error: {e}")
                batch_results.append({
                    'card_data': card.to_dict(),
                    'live_analysis': None,
                    'error': str(e)
                })
        
        return batch_results
    
    def _estimate_time(self, total_cards: int, delay_range: tuple, batch_size: int, break_duration: int) -> str:
        """Estimate total time needed."""
        avg_delay = sum(delay_range) / 2
        request_time = 2  # Estimated time per request
        
        time_per_card = request_time + avg_delay
        batches = (total_cards + batch_size - 1) // batch_size
        break_time = (batches - 1) * break_duration
        
        total_seconds = (total_cards * time_per_card) + break_time
        
        hours = int(total_seconds // 3600)
        minutes = int((total_seconds % 3600) // 60)
        
        if hours > 0:
            return f"~{hours}h {minutes}m"
        else:
            return f"~{minutes}m"
    
    def check_top_deals_only(self, candidates_df, max_cards: int = 20) -> List[dict]:
        """
        Conservative approach: Only check the very best candidates.
        
        Args:
            candidates_df: DataFrame of candidates (should be pre-sorted by quality)
            max_cards: Maximum number of cards to check
            
        Returns:
            List of results for top candidates only
        """
        print(f"🎯 CONSERVATIVE APPROACH: Top {max_cards} candidates only")
        
        top_candidates = candidates_df.head(max_cards)
        
        checker = LivePriceChecker(use_simple_scraper=True)
        results = []
        
        for i, (_, card) in enumerate(top_candidates.iterrows(), 1):
            card_name = card.get('name', f"Card ID {card.get('idProduct')}")
            print(f"{i:2d}/{max_cards}: {card_name}")
            
            live_analysis = checker.check_live_prices(card.to_dict())
            
            result = {
                'rank': i,
                'card_data': card.to_dict(),
                'live_analysis': live_analysis
            }
            
            results.append(result)
            
            # Show result
            if live_analysis and live_analysis.get('cheapest_good_condition'):
                price = live_analysis['cheapest_good_condition']
                avg7 = card.get('AVG7', 0)
                diff_pct = (price - avg7) / avg7 * 100 if avg7 > 0 else 0
                
                if diff_pct <= 0:
                    print(f"   🎯 €{price:.2f} ({diff_pct:+.1f}% vs AVG7) - EXCELLENT!")
                else:
                    print(f"   ❌ €{price:.2f} ({diff_pct:+.1f}% vs AVG7) - Above AVG7")
            
            # Small delay
            time.sleep(random.uniform(2, 4))
        
        return results


def main():
    """Demo of scalable approaches."""
    print("🃏 MTG Arbitrage - Scalable Live Price Checking")
    print("=" * 60)
    print()
    print("📊 SCALING STRATEGIES:")
    print()
    print("1. 🎯 CONSERVATIVE (Recommended for 200+ cards):")
    print("   - Only check top 20-50 best candidates")
    print("   - 2-5 minutes total time")
    print("   - Very low blocking risk")
    print()
    print("2. 📦 BATCHED (For determined users):")
    print("   - Check all cards in batches of 25-50")
    print("   - 5-10 minute breaks between batches")
    print("   - 1-3 hours total time for 200 cards")
    print("   - Moderate blocking risk")
    print()
    print("3. ⚡ HYBRID (Best of both):")
    print("   - Check top 50 candidates immediately")
    print("   - Batch process remainder if needed")
    print("   - Prioritize most promising deals")
    print()
    print("💡 RECOMMENDATION:")
    print("   For 200 cards, use Conservative approach first")
    print("   If you find <10 good deals, then consider batching more")


if __name__ == "__main__":
    main()
