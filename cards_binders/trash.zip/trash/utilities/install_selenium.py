#!/usr/bin/env python3
"""
Install Selenium dependencies for live listings scraping.

This script installs the required packages and tests the setup.
"""

import subprocess
import sys
import os

def install_package(package):
    """Install a package using pip."""
    print(f"📦 Installing {package}...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print(f"✅ {package} installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing {package}: {e}")
        return False

def test_selenium():
    """Test if Selenium is working properly."""
    print("\n🧪 Testing Selenium setup...")
    
    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.service import Service
        from selenium.webdriver.chrome.options import Options
        from webdriver_manager.chrome import ChromeDriverManager
        
        print("✅ Selenium imports successful")
        
        # Test WebDriver setup
        print("🚀 Testing Chrome WebDriver setup...")
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=chrome_options)
        
        # Test navigation
        driver.get("https://www.google.com")
        title = driver.title
        driver.quit()
        
        print(f"✅ WebDriver test successful (loaded: {title})")
        return True
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ WebDriver error: {e}")
        print("💡 Make sure Chrome browser is installed")
        return False

def main():
    """Main installation function."""
    print("🃏 MTG Arbitrage - Selenium Setup")
    print("=" * 40)
    
    print("This will install packages needed for live listings scraping:")
    print("- selenium (browser automation)")
    print("- webdriver-manager (Chrome driver management)")
    print()
    
    # Check if already installed
    try:
        import selenium
        import webdriver_manager
        print("📋 Selenium packages already installed")
        
        # Test the setup
        if test_selenium():
            print("\n🎉 Selenium setup is working!")
            print("\n📖 Usage:")
            print("  python fetch_live_listings_selenium.py")
            print("  python fetch_live_listings_selenium.py [URL]")
            return
        else:
            print("\n⚠️  Setup test failed - reinstalling...")
    except ImportError:
        print("📋 Selenium packages not found - installing...")
    
    # Install packages
    packages = [
        "selenium",
        "webdriver-manager"
    ]
    
    success = True
    for package in packages:
        if not install_package(package):
            success = False
    
    if not success:
        print("\n❌ Installation failed")
        print("💡 Try manually: pip install selenium webdriver-manager")
        return
    
    print("\n📦 Installation complete!")
    
    # Test the setup
    if test_selenium():
        print("\n🎉 Selenium setup successful!")
        print("\n📖 Usage:")
        print("  python fetch_live_listings_selenium.py")
        print("  python fetch_live_listings_selenium.py [URL]")
        print("\n💡 For manual verification (no Selenium needed):")
        print("  python manual_verification.py")
    else:
        print("\n⚠️  Setup test failed")
        print("🔧 Troubleshooting:")
        print("1. Make sure Chrome browser is installed")
        print("2. Check your internet connection")
        print("3. Try running: python fetch_live_listings_selenium.py")

if __name__ == "__main__":
    main()
