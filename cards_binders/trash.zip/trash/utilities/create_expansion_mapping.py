#!/usr/bin/env python3
"""
Create expansion mapping from idExpansion to expansion name using non-singles catalog.
Uses Magic Booster products to infer expansion names.
"""

import json
import os
from collections import defaultdict
from mtg_arbitrage.utils import get_raw_data_dir, ensure_dir_exists

def download_nonsingles_catalog():
    """Download the non-singles catalog if not already present."""
    import requests
    
    url = "https://downloads.s3.cardmarket.com/productCatalog/productList/products_nonsingles_1.json"
    raw_dir = get_raw_data_dir()
    ensure_dir_exists(raw_dir)
    
    filepath = os.path.join(raw_dir, "products_nonsingles_1.json")
    
    if os.path.exists(filepath):
        print(f"Using existing file: {filepath}")
        return filepath
    
    print(f"Downloading {url}...")
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        }
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(response.text)
            
        return filepath
        
    except Exception as e:
        print(f"Error downloading: {e}")
        return None

def extract_expansion_mapping(nonsingles_file):
    """Extract expansion mapping from Magic Booster products."""
    
    print(f"Reading non-singles catalog: {nonsingles_file}")
    
    with open(nonsingles_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    products = data.get('products', [])
    print(f"Found {len(products)} non-singles products")
    
    # Filter for Magic Boosters
    boosters = [p for p in products if p.get('categoryName') == 'Magic Booster']
    print(f"Found {len(boosters)} Magic Booster products")
    
    # Extract expansion mappings
    expansion_map = {}
    expansion_counts = defaultdict(int)
    
    for booster in boosters:
        id_expansion = booster.get('idExpansion')
        name = booster.get('name', '')
        
        if id_expansion and name:
            # Clean up booster name to get expansion name
            # Remove common booster suffixes
            clean_name = name
            suffixes_to_remove = [
                ' Booster Pack',
                ' Booster',
                ' Draft Booster',
                ' Set Booster',
                ' Collector Booster',
                ' Theme Booster',
                ' Bundle',
                ' Box',
                ' Display'
            ]
            
            for suffix in suffixes_to_remove:
                if clean_name.endswith(suffix):
                    clean_name = clean_name[:-len(suffix)].strip()
            
            # Track frequency to pick most common name for each expansion
            expansion_counts[(id_expansion, clean_name)] += 1
    
    # Pick most common name for each expansion ID
    expansion_frequency = defaultdict(list)
    for (exp_id, name), count in expansion_counts.items():
        expansion_frequency[exp_id].append((name, count))
    
    for exp_id, name_counts in expansion_frequency.items():
        # Sort by frequency and pick most common
        best_name = max(name_counts, key=lambda x: x[1])[0]
        expansion_map[exp_id] = best_name
    
    return expansion_map

def save_expansion_mapping(expansion_map):
    """Save the expansion mapping to a JSON file."""
    raw_dir = get_raw_data_dir()
    ensure_dir_exists(raw_dir)
    
    output_file = os.path.join(raw_dir, "expansion_mapping.json")
    
    # Convert keys to strings for JSON serialization
    string_key_map = {str(k): v for k, v in expansion_map.items()}
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(string_key_map, f, indent=2, sort_keys=True)
    
    print(f"✅ Saved expansion mapping to: {output_file}")
    print(f"📊 Mapped {len(expansion_map)} expansions")
    
    # Show some examples
    print("\n📋 Sample mappings:")
    for i, (exp_id, name) in enumerate(sorted(expansion_map.items())[:10]):
        print(f"  {exp_id}: {name}")
    if len(expansion_map) > 10:
        print(f"  ... and {len(expansion_map) - 10} more")
    
    return output_file

def main():
    print("🗺️  MTG Expansion Mapping Creator")
    print("="*50)
    
    # Download non-singles catalog
    nonsingles_file = download_nonsingles_catalog()
    if not nonsingles_file:
        print("❌ Failed to download non-singles catalog")
        return
    
    # Extract expansion mapping
    expansion_map = extract_expansion_mapping(nonsingles_file)
    
    if not expansion_map:
        print("❌ No expansion mappings found")
        return
    
    # Save mapping
    output_file = save_expansion_mapping(expansion_map)
    
    print(f"\n💡 Usage:")
    print(f"The mapping is saved as JSON and can be loaded in your scripts:")
    print(f"  import json")
    print(f"  with open('{output_file}', 'r') as f:")
    print(f"      expansion_map = json.load(f)")

if __name__ == "__main__":
    main()
