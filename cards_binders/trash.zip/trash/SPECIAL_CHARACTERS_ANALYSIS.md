# Special Characters in Card Names - Analysis

## Problem Summary

Cards with special characters (accents, apostrophes) fail to scrape because:

1. **URL formatting doesn't match CardMarket's exact format**
   - "Ifh-Bíff Efreet" → We format as "Ifh-Biff-Efreet" (accent removed)
   - "Yawgmoth's Will" → We format as "Yawgmoths-Will" (apostrophe removed)  
   - "Tawnos's Coffin" → We format as "Tawnoss-Coffin" (double 's')
   
2. **CardMarket redirects to expansion list**
   - When URL doesn't match exact format, redirects to `/Expansions/SetName`
   - Our scraper detects this correctly ("multiple versions detected")
   - V-1 retry also fails because base name is still wrong

3. **Search approach works BUT returns wrong conditions**
   - Search finds cards successfully
   - BUT ignores `minCondition=3` filter
   - Returns Poor/Played condition cards instead of EX+

## Test Results

### Ifh-Bíff Efreet (Arabian Nights)
- ❌ Direct URL: Redirects to expansion list
- ❌ V-1 suffix: Still redirects
- ⚠️  Search: Works but returns **PO (Poor)** instead of EX+

### Yawgmoth's Will (Urza's Saga)
- ❌ Direct URL: Redirects to expansion list
- ❌ V-1 suffix: Still redirects  
- ❌ Search: No results found

### Tawnos's Coffin (Antiquities)
- ❌ Direct URL: Redirects to expansion list
- ❌ V-1 suffix: Still redirects
- ⚠️  Search: Works but returns **PL (Played)** instead of EX+

## Root Causes

### 1. Accent Handling
The `format_card_name_for_url()` function doesn't remove accents:
- Input: "Ifh-Bíff Efreet"
- Output: "Ifh-bíff-Efreet" (accent preserved, wrong capitalization)
- Should be: "Ifh-Biff-Efreet" (accent removed, proper capitalization)

### 2. Apostrophe Handling
Function removes apostrophes but creates issues:
- "Tawnos's" → "Tawnoss" (double 's')
- "Yawgmoth's" → "Yawgmoths" (correct)

### 3. Search Condition Filtering
CardMarket's search doesn't respect `minCondition` parameter on search pages.

## Solutions

### Short-term (Quick Fix)
1. Add accent normalization to `format_card_name_for_url()`
2. For cards that fail direct URL, use search as fallback
3. Filter search results by condition in our parser

### Long-term (Best Solution)
1. Use CardMarket's product IDs instead of name-based URLs
2. Build a mapping of problematic cards to their correct URLs/IDs
3. Add fuzzy matching for card names with special characters

## Code Changes Needed

### 1. Fix `format_card_name_for_url()` in `mtg_arbitrage/utils.py`

```python
import unicodedata

def format_card_name_for_url(name: str) -> str:
    """Format a card name for use in Cardmarket URLs (Title Case)."""
    if not name or str(name) == 'nan':
        return ""
    
    name_str = str(name)
    
    # Remove accents first
    nfd = unicodedata.normalize('NFD', name_str)
    name_str = ''.join(char for char in nfd if not unicodedata.combining(char))
    
    # Replace special characters
    formatted = name_str.replace(",", "").replace("'", "").replace(":", "")
    formatted = formatted.replace("(", "").replace(")", "").replace("&", "and")
    formatted = formatted.replace("!", "").replace("?", "").replace("/", "-")
    
    # Clean up extra spaces and convert to title case
    words = formatted.split()
    title_words = [word.capitalize() for word in words if word]
    
    # Join with dashes for URL format
    return "-".join(title_words)
```

### 2. Add Search Fallback in `fetch_live_listings_simple.py`

When direct URL fails with "multiple versions", try search instead of just V-1.

### 3. Filter Search Results by Condition

Ensure parser only returns EX/NM cards from search results.

## Testing

Run: `python test_special_chars.py`

Expected after fixes:
- ✅ All three cards should work
- ✅ All should return EX+ condition only
- ✅ No "multiple versions detected" errors
