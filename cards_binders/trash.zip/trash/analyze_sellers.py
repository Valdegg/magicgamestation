#!/usr/bin/env python3
"""Find sellers with deals ≥7% below average of positions #2-5 (excludes cheapest)."""

import json
import re
import sys
import urllib.parse
from collections import defaultdict
from datetime import datetime


def analyze_deals(results, threshold=7.0):
    """Find deals grouped by seller with profile links."""
    seller_deals = defaultdict(lambda: {'deals': [], 'url': None})
    seen_deals = set()  # Track unique deals to avoid duplicates
    
    # Build category lookup
    card_categories = {}
    for cat_name in ['excellent_deals', 'good_deals', 'expensive_deals', 'no_data']:
        for result in results.get(cat_name, []):
            card_name = result.get('card_name')
            if card_name:
                card_categories[card_name] = cat_name
    
    all_results = results.get('all_results', [])
    if not all_results:
        for cat in ['excellent_deals', 'good_deals', 'expensive_deals', 'no_data']:
            all_results.extend(results.get(cat, []))
    
    for result in all_results:
        live_data = result.get('live_data') or result.get('live_analysis')
        if not live_data:
            continue
        
        # Skip cards with insufficient market data (< 10 listings)
        # With too few listings, discounts are misleading (comparing EX to NM/MT prices)
        total_listings = live_data.get('total_listings', 0)
        if total_listings < 10:
            continue
        
        # Get top 6 sellers (or fall back to top_5/top_3 for old data)
        top_sellers = live_data.get('top_6_sellers', []) or live_data.get('top_5_sellers', []) or live_data.get('top_3_sellers', [])
        if not top_sellers or len(top_sellers) < 2:
            continue
        
        card_name = result.get('card_name') or live_data.get('card_name', 'Unknown')
        card_url = live_data.get('url', '')
        
        # Calculate average using positions 2-5 (exclude cheapest to avoid self-comparison)
        # If we have 6+ sellers, use [1:5] (positions 2-5)
        # If we have fewer, use all except the first
        baseline_sellers = top_sellers[1:5] if len(top_sellers) >= 5 else top_sellers[1:]
        avg_price = sum(s['price'] for s in baseline_sellers) / len(baseline_sellers) if baseline_sellers else 0
        
        # Get category for this card
        category = card_categories.get(card_name, 'unknown')
        
        # Extract set name from CardMarket URL for MTGStocks search
        set_name = ''
        if card_url and '/Singles/' in card_url:
            try:
                set_name = card_url.split('/Singles/')[1].split('/')[0].replace('-', ' ')
            except:
                pass
        
        for s in top_sellers:
            discount = ((avg_price - s['price']) / avg_price * 100) if avg_price > 0 else 0
            if discount >= threshold:
                seller_name = s['seller']
                seller_url = f"https://www.cardmarket.com/en/Magic/Users/{seller_name}"
                
                # Create unique key for deduplication (card + seller + price + condition)
                # Round price to 2 decimal places to handle floating point precision
                deal_key = (card_name, seller_name, round(s['price'], 2), s.get('condition', 'Unknown'))
                if deal_key in seen_deals:
                    continue  # Skip duplicate
                seen_deals.add(deal_key)
                
                # Create Google "I'm Feeling Lucky" URL for MTGStocks (goes directly to first result)
                search_query = f"{card_name} {set_name} site:mtgstocks.com"
                mtgstocks_search = f"https://www.google.com/search?btnI=1&q={urllib.parse.quote(search_query)}"
                
                # Get source from result
                source = result.get('source', 'Unknown')
                
                seller_deals[seller_name]['deals'].append({
                    'card': card_name, 
                    'price': s['price'], 
                    'avg_baseline': avg_price,  # Average of positions 2-5 (excludes cheapest)
                    'discount': discount, 
                    'condition': s.get('condition', 'Unknown'),
                    'seller_country': s.get('seller_country', 'Unknown'),
                    'card_url': card_url,
                    'mtgstocks_search': mtgstocks_search,
                    'category': category,
                    'set': set_name or 'Unknown Set',
                    'source': source
                })
                seller_deals[seller_name]['url'] = seller_url
    
    return {k: v for k, v in seller_deals.items()}


def generate_combined_html(source_files, output_file):
    """Generate combined HTML from multiple source files.
    
    Args:
        source_files: List of tuples (source_name, json_file_path)
        output_file: Path to output HTML file
    """
    import json
    from collections import defaultdict
    
    # Merge all seller deals and rejected cards
    combined_sellers = defaultdict(lambda: {'deals': [], 'url': None})
    combined_rejected = {
        'expensive_deals': [],
        'no_data': []
    }
    all_thresholds = []
    seen_deals = set()  # Track unique deals across all sources
    seen_rejected = set()  # Track unique rejected cards
    
    for source_name, json_file in source_files:
        try:
            with open(json_file, 'r') as f:
                data = json.load(f)
            
            # Get threshold
            threshold = data.get('summary', {}).get('threshold', 7.0)
            all_thresholds.append(threshold)
            
            # Convert to results format for analyze_deals
            results = {
                'excellent_deals': data.get('excellent_deals', []),
                'good_deals': data.get('good_deals', [])
            }
            
            # Run analyze_deals to group by seller
            seller_deals = analyze_deals(results, threshold)
            
            # Merge seller deals, adding source label
            for seller_name, seller_data in seller_deals.items():
                combined_sellers[seller_name]['url'] = seller_data['url']
                for deal in seller_data['deals']:
                    # Create unique key for deduplication
                    # Round price to 2 decimal places to handle floating point precision
                    deal_key = (deal['card'], seller_name, round(deal['price'], 2), deal['condition'])
                    if deal_key in seen_deals:
                        continue  # Skip duplicate across sources
                    seen_deals.add(deal_key)
                    
                    # Add source label to each deal
                    deal_with_source = deal.copy()
                    deal_with_source['source'] = source_name
                    combined_sellers[seller_name]['deals'].append(deal_with_source)
            
            # Collect rejected cards (expensive_deals, no_data)
            for category in ['expensive_deals', 'no_data']:
                if category in data:
                    for item in data[category]:
                        # Create unique key for deduplication
                        card_name = item.get('card_name', 'Unknown')
                        card_id = item.get('card_id', 0)
                        rejected_key = (card_name, card_id)
                        
                        if rejected_key not in seen_rejected:
                            seen_rejected.add(rejected_key)
                            # Add source label
                            item_with_source = item.copy()
                            item_with_source['source'] = source_name
                            combined_rejected[category].append(item_with_source)
        except Exception as e:
            print(f"⚠️  Warning: Could not load {json_file}: {e}")
    
    # Sort sellers by number of deals
    sorted_sellers = dict(sorted(
        combined_sellers.items(),
        key=lambda x: len(x[1]['deals']),
        reverse=True
    ))
    
    # Use minimum threshold for display
    threshold = min(all_thresholds) if all_thresholds else 0
    
    # Use the enhanced HTML generation with filters and sorting
    try:
        from analyze_sellers_combined import generate_html_with_rejected
        # Pass the combined rejected cards to the HTML generator
        generate_html_with_rejected(sorted_sellers, combined_rejected, threshold, output_file)
        return
    except Exception as e:
        print(f"⚠️  Using basic combined HTML (enhanced version failed: {e})")
        import traceback
        traceback.print_exc()
    
    # Fallback: Generate basic HTML with source labels
    seller_deals = sorted_sellers
    total_deals = sum(len(data['deals']) for data in seller_deals.values())
    multi_deal_sellers = sum(1 for data in seller_deals.values() if len(data['deals']) >= 2)
    
    # Count deals by source
    source_counts = defaultdict(int)
    for seller_data in seller_deals.values():
        for deal in seller_data['deals']:
            source_counts[deal.get('source', 'Unknown')] += 1
    
    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MTG Market Scanner - Combined Analysis</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #6B5844 0%, #C5A572 25%, #E8D4A0 50%, #C5A572 75%, #6B5844 100%);
            min-height: 100vh; padding: 20px; color: #333;
        }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        header {{
            background: white; border-radius: 16px; padding: 30px; margin-bottom: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }}
        h1 {{ font-size: 2.5em; color: #2d3748; margin-bottom: 10px; }}
        .subtitle {{ color: #718096; margin-top: 10px; font-size: 1.1em; }}
        .stats {{ display: flex; gap: 20px; margin-top: 20px; flex-wrap: wrap; }}
        .stat {{
            background: linear-gradient(135deg, #6B5844 0%, #C5A572 25%, #E8D4A0 50%, #C5A572 75%, #6B5844 100%);
            color: white; padding: 15px 25px; border-radius: 12px; font-size: 0.9em;
        }}
        .stat-number {{ font-size: 2em; font-weight: bold; display: block; }}
        .source-breakdown {{ margin-top: 20px; padding: 15px; background: #f7fafc; border-radius: 8px; }}
        .source-breakdown h3 {{ font-size: 1em; color: #4a5568; margin-bottom: 10px; }}
        .source-counts {{ display: flex; gap: 15px; flex-wrap: wrap; }}
        .source-count {{ background: white; padding: 8px 15px; border-radius: 8px; font-size: 0.9em; }}
        .seller-card {{
            background: white; border-radius: 16px; padding: 25px; margin-bottom: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            transition: transform 0.2s, box-shadow 0.2s;
        }}
        .seller-card:hover {{ transform: translateY(-2px); box-shadow: 0 8px 30px rgba(0,0,0,0.12); }}
        .seller-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 20px; padding-bottom: 15px; border-bottom: 2px solid #e2e8f0;
        }}
        .seller-name {{ font-size: 1.5em; font-weight: bold; color: #2d3748; }}
        .seller-badge {{
            background: linear-gradient(135deg, #6B5844 0%, #C5A572 25%, #E8D4A0 50%, #C5A572 75%, #6B5844 100%);
            color: white; padding: 8px 16px; border-radius: 20px;
            font-size: 0.9em; font-weight: 600;
        }}
        .seller-link {{
            display: inline-block; margin-top: 10px; color: #8B7355;
            text-decoration: none; font-size: 0.9em;
        }}
        .seller-link:hover {{ text-decoration: underline; }}
        .deals {{ display: grid; gap: 15px; }}
        .deal {{ background: #f7fafc; border-radius: 12px; padding: 20px; border-left: 4px solid #667eea; display: flex; gap: 15px; }}
        .card-image {{ width: 100px; height: auto; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.15); flex-shrink: 0; }}
        .deal-content {{ flex: 1; }}
        .deal-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }}
        .card-name {{ font-size: 1.2em; font-weight: 600; color: #2d3748; }}
        .discount-badge {{
            background: #48bb78; color: white; padding: 6px 12px;
            border-radius: 8px; font-weight: 600; font-size: 0.9em;
        }}
        .deal-info {{ display: flex; gap: 20px; margin-bottom: 12px; font-size: 0.95em; color: #4a5568; flex-wrap: wrap; }}
        .deal-links {{ display: flex; gap: 10px; flex-wrap: wrap; }}
        .btn {{
            display: inline-block; padding: 8px 16px; border-radius: 8px;
            text-decoration: none; font-size: 0.85em; font-weight: 600;
            transition: all 0.2s;
        }}
        .btn-cardmarket {{ background: #3182ce; color: white; }}
        .btn-cardmarket:hover {{ background: #2c5282; }}
        .btn-mtgstocks {{ background: #ed8936; color: white; }}
        .btn-mtgstocks:hover {{ background: #c05621; }}
        .condition {{
            background: #edf2f7; padding: 4px 10px; border-radius: 6px;
            font-size: 0.85em; font-weight: 600; color: #4a5568;
        }}
        .source-badge {{
            padding: 4px 10px; border-radius: 6px;
            font-size: 0.75em; font-weight: 700;
            background: #805ad5; color: white;
        }}
        .category-badge {{
            padding: 4px 10px; border-radius: 6px;
            font-size: 0.75em; font-weight: 700; text-transform: uppercase;
            margin-left: 10px; display: inline-block;
        }}
        .category-excellent {{ background: #48bb78; color: white; }}
        .category-good {{ background: #4299e1; color: white; }}
        .category-expensive {{ background: #fc8181; color: white; }}
        .category-no_data {{ background: #a0aec0; color: white; }}
        footer {{ text-align: center; color: white; margin-top: 40px; padding: 20px; font-size: 0.9em; }}
        @media (max-width: 768px) {{
            h1 {{ font-size: 1.8em; }}
            .stats {{ gap: 15px; }}
            .deal-header {{ flex-direction: column; align-items: flex-start; gap: 10px; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🎯 MTG Market Scanner - Combined Analysis</h1>
            <p class="subtitle">
                All sources: Wishlist • Reserved List • Candidates
            </p>
            
            <div style="background: #f7fafc; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #C5A572;">
                <h3 style="color: #2d3748; margin-bottom: 12px; font-size: 1.1em;">📋 How It Works</h3>
                <div style="color: #4a5568; line-height: 1.8;">
                    <p style="margin-bottom: 10px;"><strong>Candidate Discovery:</strong> Cards are filtered from historical price data based on:</p>
                    <ul style="margin-left: 20px; margin-bottom: 12px;">
                        <li>AVG30 (30-day average sales) is ≥5% below TREND price</li>
                        <li>Card is in a whitelisted MTG set (expansion mapping)</li>
                        <li>Sufficient historical price data available</li>
                    </ul>
                    <p style="margin-bottom: 10px;"><strong>Deal Identification:</strong> Live prices are scraped from CardMarket and flagged as deals when:</p>
                    <ul style="margin-left: 20px;">
                        <li>Price is ≥{threshold:.0f}% below the average of listings ranked #2-5 (excluding the cheapest to avoid self-comparison)</li>
                        <li>Only EX (Excellent) or NM (Near Mint) condition cards are considered</li>
                        <li>Deals are grouped by seller to identify bulk purchase opportunities</li>
                    </ul>
                </div>
            </div>
            
            <div class="stats">
                <div class="stat"><span class="stat-number">{len(seller_deals)}</span>Sellers</div>
                <div class="stat"><span class="stat-number">{total_deals}</span>Total Deals</div>
                <div class="stat"><span class="stat-number">{multi_deal_sellers}</span>Multi-Deal Sellers</div>
            </div>
            <div class="source-breakdown">
                <h3>Deals by Source:</h3>
                <div class="source-counts">
'''
    
    for source, count in sorted(source_counts.items()):
        html += f'<div class="source-count"><strong>{source}:</strong> {count} deals</div>'
    
    html += '''
                </div>
            </div>
        </header>
        <div class="sellers">
'''
    
    for seller_name, seller_data in seller_deals.items():
        deals = seller_data['deals']
        seller_url = seller_data['url']
        total_value = sum(deal['price'] for deal in deals)
        avg_discount = sum(deal['discount'] for deal in deals) / len(deals)
        
        html += f'''
            <div class="seller-card">
                <div class="seller-header">
                    <div>
                        <div class="seller-name">{seller_name}</div>
                        <a href="{seller_url}" target="_blank" class="seller-link">👤 View Profile on CardMarket →</a>
                    </div>
                    <div class="seller-badge">
                        {len(deals)} deal{'s' if len(deals) > 1 else ''} • €{total_value:.2f} total • {avg_discount:.1f}% avg discount
                    </div>
                </div>
                <div class="deals">
'''
        
        for deal in sorted(deals, key=lambda x: x['discount'], reverse=True):
            category = deal.get('category', 'unknown')
            category_label = {
                'excellent_deals': '🔥 Excellent Deal',
                'good_deals': '✓ Good Deal',
                'expensive_deals': '⚠️ Expensive',
                'no_data': 'ℹ️ No Data'
            }.get(category, '')
            category_class = category.replace('_', '-')
            source = deal.get('source', 'Unknown')
            
            # Clean card name for image filename
            card_image_filename = re.sub(r'[<>:"/\\|?*]', '', deal['card']) + '.jpg'
            card_image_path = f"../card_images/{card_image_filename}"
            
            html += f'''
                    <div class="deal">
                        <img src="{card_image_path}" alt="{deal['card']}" class="card-image" onerror="this.style.display='none'">
                        <div class="deal-content">
                            <div class="deal-header">
                                <div>
                                    <span class="card-name">{deal['card']}</span>
                                    {f'<span class="category-badge category-{category_class}">{category_label}</span>' if category_label else ''}
                                </div>
                                <div class="discount-badge">-{deal['discount']:.1f}%</div>
                            </div>
                            <div class="deal-info">
                                <div><strong>Price:</strong> €{deal['price']:.2f}</div>
                                <div><strong>Avg #2-5:</strong> €{deal.get('avg_baseline', deal.get('avg_top5', deal.get('median', 0))):.2f}</div>
                                <div class="condition">{deal['condition']}</div>
                                <div class="source-badge">{source}</div>
                            </div>
                            <div class="deal-links">
                                <a href="{deal['card_url']}" target="_blank" class="btn btn-cardmarket">📊 View on CardMarket</a>
                                <a href="{deal['mtgstocks_search']}" target="_blank" class="btn btn-mtgstocks">📈 Price History (MTGStocks)</a>
                            </div>
                        </div>
                    </div>
'''
        
        html += '''
                </div>
            </div>
'''
    
    html += f'''
        </div>
        <footer>Generated on {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')}</footer>
    </div>
</body>
</html>
'''
    
    with open(output_file, 'w') as f:
        f.write(html)
    return output_file


def generate_html(seller_deals_data, threshold, output_file):
    """Generate a clean HTML website from seller deals."""
    seller_deals = seller_deals_data
    total_deals = sum(len(data['deals']) for data in seller_deals.values())
    multi_deal_sellers = sum(1 for data in seller_deals.values() if len(data['deals']) >= 2)
    
    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MTG Market Scanner - Seller Deals</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #6B5844 0%, #C5A572 25%, #E8D4A0 50%, #C5A572 75%, #6B5844 100%);
            min-height: 100vh; padding: 20px; color: #333;
        }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        header {{
            background: white; border-radius: 16px; padding: 30px; margin-bottom: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }}
        h1 {{ font-size: 2.5em; color: #2d3748; margin-bottom: 10px; }}
        .stats {{ display: flex; gap: 30px; margin-top: 20px; flex-wrap: wrap; }}
        .stat {{
            background: linear-gradient(135deg, #6B5844 0%, #C5A572 25%, #E8D4A0 50%, #C5A572 75%, #6B5844 100%);
            color: white; padding: 15px 25px; border-radius: 12px; font-size: 0.9em;
        }}
        .stat-number {{ font-size: 2em; font-weight: bold; display: block; }}
        .seller-card {{
            background: white; border-radius: 16px; padding: 25px; margin-bottom: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            transition: transform 0.2s, box-shadow 0.2s;
        }}
        .seller-card:hover {{ transform: translateY(-2px); box-shadow: 0 8px 30px rgba(0,0,0,0.12); }}
        .seller-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 20px; padding-bottom: 15px; border-bottom: 2px solid #e2e8f0;
        }}
        .seller-name {{ font-size: 1.5em; font-weight: bold; color: #2d3748; }}
        .seller-badge {{
            background: linear-gradient(135deg, #6B5844 0%, #C5A572 25%, #E8D4A0 50%, #C5A572 75%, #6B5844 100%);
            color: white; padding: 8px 16px; border-radius: 20px;
            font-size: 0.9em; font-weight: 600;
        }}
        .seller-link {{
            display: inline-block; margin-top: 10px; color: #8B7355;
            text-decoration: none; font-size: 0.9em;
        }}
        .seller-link:hover {{ text-decoration: underline; }}
        .deals {{ display: grid; gap: 15px; }}
        .deal {{ background: #f7fafc; border-radius: 12px; padding: 20px; border-left: 4px solid #667eea; display: flex; gap: 15px; }}
        .card-image {{ width: 100px; height: auto; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.15); flex-shrink: 0; }}
        .deal-content {{ flex: 1; }}
        .deal-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }}
        .card-name {{ font-size: 1.2em; font-weight: 600; color: #2d3748; }}
        .discount-badge {{
            background: #48bb78; color: white; padding: 6px 12px;
            border-radius: 8px; font-weight: 600; font-size: 0.9em;
        }}
        .deal-info {{ display: flex; gap: 20px; margin-bottom: 12px; font-size: 0.95em; color: #4a5568; }}
        .deal-links {{ display: flex; gap: 10px; flex-wrap: wrap; }}
        .btn {{
            display: inline-block; padding: 8px 16px; border-radius: 8px;
            text-decoration: none; font-size: 0.85em; font-weight: 600;
            transition: all 0.2s;
        }}
        .btn-cardmarket {{ background: #3182ce; color: white; }}
        .btn-cardmarket:hover {{ background: #2c5282; }}
        .btn-mtgstocks {{ background: #ed8936; color: white; }}
        .btn-mtgstocks:hover {{ background: #c05621; }}
        .condition {{
            background: #edf2f7; padding: 4px 10px; border-radius: 6px;
            font-size: 0.85em; font-weight: 600; color: #4a5568;
        }}
        .category-badge {{
            padding: 4px 10px; border-radius: 6px;
            font-size: 0.75em; font-weight: 700; text-transform: uppercase;
            margin-left: 10px; display: inline-block;
        }}
        .category-excellent {{ background: #48bb78; color: white; }}
        .category-good {{ background: #4299e1; color: white; }}
        .category-expensive {{ background: #fc8181; color: white; }}
        .category-no_data {{ background: #a0aec0; color: white; }}
        footer {{ text-align: center; color: white; margin-top: 40px; padding: 20px; font-size: 0.9em; }}
        @media (max-width: 768px) {{
            h1 {{ font-size: 1.8em; }}
            .stats {{ gap: 15px; }}
            .deal-header {{ flex-direction: column; align-items: flex-start; gap: 10px; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🎯 MTG Market Scanner - Seller Deals</h1>
            <p style="color: #718096; margin-top: 10px;">
                Showing deals ≥{threshold}% below average of top 5 prices
            </p>
            
            <div style="background: #f7fafc; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #C5A572;">
                <h3 style="color: #2d3748; margin-bottom: 12px; font-size: 1.1em;">📋 How It Works</h3>
                <div style="color: #4a5568; line-height: 1.8;">
                    <p style="margin-bottom: 10px;"><strong>Candidate Discovery:</strong> Cards are filtered from historical price data based on:</p>
                    <ul style="margin-left: 20px; margin-bottom: 12px;">
                        <li>AVG30 (30-day average sales) is ≥5% below TREND price</li>
                        <li>Card is in a whitelisted MTG set (expansion mapping)</li>
                        <li>Sufficient historical price data available</li>
                    </ul>
                    <p style="margin-bottom: 10px;"><strong>Deal Identification:</strong> Live prices are scraped from CardMarket and flagged as deals when:</p>
                    <ul style="margin-left: 20px;">
                        <li>Price is ≥{threshold:.0f}% below the average of listings ranked #2-5 (excluding the cheapest to avoid self-comparison)</li>
                        <li>Only EX (Excellent) or NM (Near Mint) condition cards are considered</li>
                        <li>Deals are grouped by seller to identify bulk purchase opportunities</li>
                    </ul>
                </div>
            </div>
            
            <div class="stats">
                <div class="stat"><span class="stat-number">{len(seller_deals)}</span>Sellers</div>
                <div class="stat"><span class="stat-number">{total_deals}</span>Total Deals</div>
                <div class="stat"><span class="stat-number">{multi_deal_sellers}</span>Multi-Deal Sellers</div>
            </div>
        </header>
        <div class="sellers">
'''
    
    for seller_name, seller_data in seller_deals.items():
        deals = seller_data['deals']
        seller_url = seller_data['url']
        total_value = sum(deal['price'] for deal in deals)
        avg_discount = sum(deal['discount'] for deal in deals) / len(deals)
        
        html += f'''
            <div class="seller-card">
                <div class="seller-header">
                    <div>
                        <div class="seller-name">{seller_name}</div>
                        <a href="{seller_url}" target="_blank" class="seller-link">👤 View Profile on CardMarket →</a>
                    </div>
                    <div class="seller-badge">
                        {len(deals)} deal{'s' if len(deals) > 1 else ''} • €{total_value:.2f} total • {avg_discount:.1f}% avg discount
                    </div>
                </div>
                <div class="deals">
'''
        
        for deal in sorted(deals, key=lambda x: x['discount'], reverse=True):
            category = deal.get('category', 'unknown')
            category_label = {
                'excellent_deals': '🔥 Excellent Deal',
                'good_deals': '✓ Good Deal',
                'expensive_deals': '⚠️ Expensive',
                'no_data': 'ℹ️ No Data'
            }.get(category, '')
            category_class = category.replace('_', '-')
            
            # Clean card name for image filename
            card_image_filename = re.sub(r'[<>:"/\\|?*]', '', deal['card']) + '.jpg'
            card_image_path = f"../card_images/{card_image_filename}"
            
            html += f'''
                    <div class="deal">
                        <img src="{card_image_path}" alt="{deal['card']}" class="card-image" onerror="this.style.display='none'">
                        <div class="deal-content">
                            <div class="deal-header">
                                <div>
                                    <span class="card-name">{deal['card']}</span>
                                    {f'<span class="category-badge category-{category_class}">{category_label}</span>' if category_label else ''}
                                </div>
                                <div class="discount-badge">-{deal['discount']:.1f}%</div>
                            </div>
                            <div class="deal-info">
                                <div><strong>Price:</strong> €{deal['price']:.2f}</div>
                                <div><strong>Avg #2-5:</strong> €{deal.get('avg_baseline', deal.get('avg_top5', deal.get('median', 0))):.2f}</div>
                                <div class="condition">{deal['condition']}</div>
                            </div>
                            <div class="deal-links">
                                <a href="{deal['card_url']}" target="_blank" class="btn btn-cardmarket">📊 View on CardMarket</a>
                                <a href="{deal['mtgstocks_search']}" target="_blank" class="btn btn-mtgstocks">📈 Price History (MTGStocks)</a>
                            </div>
                        </div>
                    </div>
'''
        
        html += '''
                </div>
            </div>
'''
    
    html += f'''
        </div>
        <footer>Generated on {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')}</footer>
    </div>
</body>
</html>
'''
    
    with open(output_file, 'w') as f:
        f.write(html)
    return output_file


def print_report(seller_deals, threshold=12.0):
    """Print deals grouped by seller."""
    if not seller_deals:
        print(f"\n⚠️  No deals found (≥{threshold}% below avg, ≥10 listings required)")
        return
    
    sorted_sellers = sorted(seller_deals.items(), key=lambda x: len(x[1]['deals']), reverse=True)
    total_deals = sum(len(d['deals']) for d in seller_deals.values())
    
    print(f"\n🎯 FOUND {total_deals} DEALS (≥{threshold}% below avg, ≥10 listings)")
    print("=" * 80)
    
    multi = [(s, d) for s, d in sorted_sellers if len(d['deals']) >= 2]
    if multi:
        print(f"\n🏆 SELLERS WITH 2+ DEALS:")
        for seller, data in multi:
            deals = data['deals']
            avg_disc = sum(d['discount'] for d in deals) / len(deals)
            total = sum(d['price'] for d in deals)
            print(f"\n{seller} - {len(deals)} deals (avg {avg_disc:.1f}% off, €{total:.0f} total)")
            for d in sorted(deals, key=lambda x: x['discount'], reverse=True):
                print(f"  {d['discount']:4.1f}% | €{d['price']:6.2f} - {d['card']} ({d['condition']})")
    
    single = [(s, d) for s, d in sorted_sellers if len(d['deals']) == 1]
    if single:
        print(f"\n📋 SINGLE DEALS ({len(single)}):")
        for seller, data in single[:10]:
            d = data['deals'][0]
            print(f"  {seller:25s} {d['discount']:4.1f}% | €{d['price']:6.2f} - {d['card']}")
        if len(single) > 10:
            print(f"  ... and {len(single) - 10} more")


def generate_rejected_html(results, threshold, output_file):
    """Generate HTML for cards that didn't make the main seller deals HTML."""
    
    # Categorize rejected cards
    rejected_cards = {
        'expensive': [],
        'no_data': [],
        'below_threshold': []
    }
    
    # Get cards from expensive_deals and no_data categories
    for result in results.get('expensive_deals', []):
        rejected_cards['expensive'].append(result)
    
    for result in results.get('no_data', []):
        rejected_cards['no_data'].append(result)
    
    # Find cards that have data but didn't meet the threshold
    all_results = results.get('all_results', [])
    if not all_results:
        for cat in ['excellent_deals', 'good_deals', 'expensive_deals', 'no_data']:
            all_results.extend(results.get(cat, []))
    
    # Track which cards made it into seller deals
    cards_in_seller_deals = set()
    seller_deals = analyze_deals(results, threshold)
    for seller_data in seller_deals.values():
        for deal in seller_data['deals']:
            cards_in_seller_deals.add(deal['card'])
    
    # Find cards with live data that didn't meet threshold
    for result in results.get('good_deals', []) + results.get('excellent_deals', []):
        card_name = result.get('card_name')
        if card_name and card_name not in cards_in_seller_deals:
            live_data = result.get('live_data') or result.get('live_analysis')
            if live_data:  # Has live data but didn't meet threshold
                rejected_cards['below_threshold'].append(result)
    
    # Count totals
    total_rejected = sum(len(cards) for cards in rejected_cards.values())
    
    if total_rejected == 0:
        print(f"   No rejected cards to report (all cards met criteria)")
        return output_file
    
    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MTG Market Scanner - Rejected Cards</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #4a5568 0%, #718096 50%, #4a5568 100%);
            min-height: 100vh; padding: 20px; color: #333;
        }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        header {{
            background: white; border-radius: 16px; padding: 30px; margin-bottom: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }}
        h1 {{ font-size: 2.5em; color: #2d3748; margin-bottom: 10px; }}
        .subtitle {{ color: #718096; margin-top: 10px; font-size: 1.1em; }}
        .stats {{ display: flex; gap: 20px; margin-top: 20px; flex-wrap: wrap; }}
        .stat {{
            background: linear-gradient(135deg, #4a5568 0%, #718096 50%, #4a5568 100%);
            color: white; padding: 15px 25px; border-radius: 12px; font-size: 0.9em;
        }}
        .stat-number {{ font-size: 2em; font-weight: bold; display: block; }}
        .category-section {{
            background: white; border-radius: 16px; padding: 25px; margin-bottom: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }}
        .category-header {{
            font-size: 1.5em; font-weight: bold; color: #2d3748;
            margin-bottom: 15px; padding-bottom: 15px; border-bottom: 2px solid #e2e8f0;
        }}
        .category-description {{
            background: #f7fafc; padding: 15px; border-radius: 8px;
            margin-bottom: 20px; color: #4a5568; line-height: 1.6;
        }}
        .cards {{ display: grid; gap: 15px; }}
        .card {{ background: #f7fafc; border-radius: 12px; padding: 20px; border-left: 4px solid #cbd5e0; display: flex; gap: 15px; }}
        .card-image {{ width: 100px; height: auto; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.15); flex-shrink: 0; }}
        .card-content {{ flex: 1; }}
        .card-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }}
        .card-name {{ font-size: 1.2em; font-weight: 600; color: #2d3748; }}
        .card-info {{ display: flex; gap: 20px; margin-bottom: 12px; font-size: 0.95em; color: #4a5568; flex-wrap: wrap; }}
        .card-links {{ display: flex; gap: 10px; flex-wrap: wrap; }}
        .btn {{
            display: inline-block; padding: 8px 16px; border-radius: 8px;
            text-decoration: none; font-size: 0.85em; font-weight: 600;
            transition: all 0.2s;
        }}
        .btn-cardmarket {{ background: #3182ce; color: white; }}
        .btn-cardmarket:hover {{ background: #2c5282; }}
        .btn-mtgstocks {{ background: #ed8936; color: white; }}
        .btn-mtgstocks:hover {{ background: #c05621; }}
        .reason-badge {{
            background: #fc8181; color: white; padding: 6px 12px;
            border-radius: 8px; font-weight: 600; font-size: 0.9em;
        }}
        .warning-badge {{
            background: #f6ad55; color: white; padding: 6px 12px;
            border-radius: 8px; font-weight: 600; font-size: 0.9em;
        }}
        .info-badge {{
            background: #a0aec0; color: white; padding: 6px 12px;
            border-radius: 8px; font-weight: 600; font-size: 0.9em;
        }}
        footer {{ text-align: center; color: white; margin-top: 40px; padding: 20px; font-size: 0.9em; }}
        @media (max-width: 768px) {{
            h1 {{ font-size: 1.8em; }}
            .stats {{ gap: 15px; }}
            .card-header {{ flex-direction: column; align-items: flex-start; gap: 10px; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>📋 MTG Market Scanner - Rejected Cards Report</h1>
            <p class="subtitle">
                Cards that didn't meet the criteria for the main deals report
            </p>
            
            <div class="stats">
                <div class="stat"><span class="stat-number">{total_rejected}</span>Total Rejected</div>
                <div class="stat"><span class="stat-number">{len(rejected_cards['expensive'])}</span>Above TREND</div>
                <div class="stat"><span class="stat-number">{len(rejected_cards['below_threshold'])}</span>Below Threshold</div>
                <div class="stat"><span class="stat-number">{len(rejected_cards['no_data'])}</span>No Live Data</div>
            </div>
        </header>
'''
    
    # Section 1: Cards above TREND
    if rejected_cards['expensive']:
        html += '''
        <div class="category-section">
            <div class="category-header">❌ Above TREND Price (Not Profitable)</div>
            <div class="category-description">
                These cards have live prices that are above the market TREND price, making them not profitable to buy.
            </div>
            <div class="cards">
'''
        for result in rejected_cards['expensive']:
            card_name = result.get('card_name', 'Unknown')
            expansion = result.get('expansion', 'Unknown')
            card_id = result.get('card_id', '')
            historical = result.get('historical_data', {})
            live_data = result.get('live_data')
            
            # Clean card name for image
            card_image_filename = re.sub(r'[<>:"/\\|?*]', '', card_name) + '.jpg'
            card_image_path = f"../card_images/{card_image_filename}"
            
            # Build CardMarket URL
            card_url = live_data.get('url', '') if live_data else ''
            
            # Build MTGStocks search
            search_query = f"{card_name} site:mtgstocks.com"
            mtgstocks_search = f"https://www.google.com/search?btnI=1&q={urllib.parse.quote(search_query)}"
            
            trend = historical.get('trend', 0)
            avg30 = historical.get('avg30', 0)
            
            if live_data:
                cheapest = live_data.get('cheapest_good_condition', 0)
                cheapest_details = live_data.get('cheapest_good_condition_details', {})
                condition = cheapest_details.get('condition', 'Unknown') if cheapest_details else 'Unknown'
                seller = cheapest_details.get('seller', 'Unknown') if cheapest_details else 'Unknown'
                
                if trend > 0:
                    vs_trend = ((cheapest - trend) / trend * 100)
                    reason = f"€{cheapest:.2f} is {vs_trend:+.1f}% vs TREND (€{trend:.2f})"
                else:
                    reason = f"€{cheapest:.2f} (no TREND data)"
            else:
                reason = "No live data available"
                cheapest = 0
                condition = "Unknown"
                seller = "Unknown"
            
            html += f'''
                <div class="card">
                    <img src="{card_image_path}" alt="{card_name}" class="card-image" onerror="this.style.display='none'">
                    <div class="card-content">
                        <div class="card-header">
                            <span class="card-name">{card_name} ({expansion})</span>
                            <span class="reason-badge">Above TREND</span>
                        </div>
                        <div class="card-info">
                            <div><strong>Current Price:</strong> €{cheapest:.2f}</div>
                            <div><strong>TREND:</strong> €{trend:.2f}</div>
                            <div><strong>AVG30:</strong> €{avg30:.2f}</div>
                            <div><strong>Condition:</strong> {condition}</div>
                        </div>
                        <div style="margin-bottom: 12px; color: #718096;">
                            <strong>Reason:</strong> {reason}
                        </div>
                        <div class="card-links">
'''
            if card_url:
                html += f'<a href="{card_url}" target="_blank" class="btn btn-cardmarket">📊 View on CardMarket</a>'
            
            html += f'''
                            <a href="{mtgstocks_search}" target="_blank" class="btn btn-mtgstocks">📈 Price History</a>
                        </div>
                    </div>
                </div>
'''
        
        html += '''
            </div>
        </div>
'''
    
    # Section 2: Below threshold
    if rejected_cards['below_threshold']:
        html += f'''
        <div class="category-section">
            <div class="category-header">🟡 Below {threshold}% Discount Threshold</div>
            <div class="category-description">
                These cards have live prices below TREND but didn't meet the {threshold}% discount threshold for seller deals.
            </div>
            <div class="cards">
'''
        for result in rejected_cards['below_threshold']:
            card_name = result.get('card_name', 'Unknown')
            expansion = result.get('expansion', 'Unknown')
            historical = result.get('historical_data', {})
            live_data = result.get('live_data')
            
            # Clean card name for image
            card_image_filename = re.sub(r'[<>:"/\\|?*]', '', card_name) + '.jpg'
            card_image_path = f"../card_images/{card_image_filename}"
            
            card_url = live_data.get('url', '') if live_data else ''
            search_query = f"{card_name} site:mtgstocks.com"
            mtgstocks_search = f"https://www.google.com/search?btnI=1&q={urllib.parse.quote(search_query)}"
            
            trend = historical.get('trend', 0)
            avg30 = historical.get('avg30', 0)
            
            if live_data:
                cheapest = live_data.get('cheapest_good_condition', 0)
                cheapest_details = live_data.get('cheapest_good_condition_details', {})
                condition = cheapest_details.get('condition', 'Unknown') if cheapest_details else 'Unknown'
                
                if trend > 0:
                    vs_trend = ((cheapest - trend) / trend * 100)
                    reason = f"€{cheapest:.2f} is {vs_trend:+.1f}% vs TREND (€{trend:.2f}) - marginal discount"
                else:
                    reason = f"€{cheapest:.2f} - discount too small"
            else:
                reason = "Insufficient discount"
                cheapest = 0
                condition = "Unknown"
            
            html += f'''
                <div class="card">
                    <img src="{card_image_path}" alt="{card_name}" class="card-image" onerror="this.style.display='none'">
                    <div class="card-content">
                        <div class="card-header">
                            <span class="card-name">{card_name} ({expansion})</span>
                            <span class="warning-badge">Small Discount</span>
                        </div>
                        <div class="card-info">
                            <div><strong>Current Price:</strong> €{cheapest:.2f}</div>
                            <div><strong>TREND:</strong> €{trend:.2f}</div>
                            <div><strong>AVG30:</strong> €{avg30:.2f}</div>
                            <div><strong>Condition:</strong> {condition}</div>
                        </div>
                        <div style="margin-bottom: 12px; color: #718096;">
                            <strong>Reason:</strong> {reason}
                        </div>
                        <div class="card-links">
'''
            if card_url:
                html += f'<a href="{card_url}" target="_blank" class="btn btn-cardmarket">📊 View on CardMarket</a>'
            
            html += f'''
                            <a href="{mtgstocks_search}" target="_blank" class="btn btn-mtgstocks">📈 Price History</a>
                        </div>
                    </div>
                </div>
'''
        
        html += '''
            </div>
        </div>
'''
    
    # Section 3: No live data
    if rejected_cards['no_data']:
        html += '''
        <div class="category-section">
            <div class="category-header">⚠️ No Live Data Available</div>
            <div class="category-description">
                These cards could not be scraped from CardMarket (may be temporarily unavailable or have no listings).
            </div>
            <div class="cards">
'''
        for result in rejected_cards['no_data']:
            card_name = result.get('card_name', 'Unknown')
            expansion = result.get('expansion', 'Unknown')
            historical = result.get('historical_data', {})
            
            # Clean card name for image
            card_image_filename = re.sub(r'[<>:"/\\|?*]', '', card_name) + '.jpg'
            card_image_path = f"../card_images/{card_image_filename}"
            
            # Build search URL even without live data
            search_query = f"{card_name} site:mtgstocks.com"
            mtgstocks_search = f"https://www.google.com/search?btnI=1&q={urllib.parse.quote(search_query)}"
            
            trend = historical.get('trend', 0)
            avg30 = historical.get('avg30', 0)
            
            html += f'''
                <div class="card">
                    <img src="{card_image_path}" alt="{card_name}" class="card-image" onerror="this.style.display='none'">
                    <div class="card-content">
                        <div class="card-header">
                            <span class="card-name">{card_name} ({expansion})</span>
                            <span class="info-badge">No Data</span>
                        </div>
                        <div class="card-info">
                            <div><strong>TREND:</strong> €{trend:.2f}</div>
                            <div><strong>AVG30:</strong> €{avg30:.2f}</div>
                        </div>
                        <div style="margin-bottom: 12px; color: #718096;">
                            <strong>Reason:</strong> Could not fetch live prices from CardMarket
                        </div>
                        <div class="card-links">
                            <a href="{mtgstocks_search}" target="_blank" class="btn btn-mtgstocks">📈 Price History</a>
                        </div>
                    </div>
                </div>
'''
        
        html += '''
            </div>
        </div>
'''
    
    html += f'''
        <footer>Generated on {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')}</footer>
    </div>
</body>
</html>
'''
    
    with open(output_file, 'w') as f:
        f.write(html)
    
    return output_file


def main():
    if len(sys.argv) < 2:
        print("Usage: python analyze_sellers.py <results.json> [threshold]")
        print("Finds sellers with prices ≥threshold% below avg of top 5.")
        print("Generates both JSON and HTML website outputs.")
        print("\nExamples:")
        print("  python analyze_sellers.py results/mtg_arbitrage.json      # 12% threshold (default)")
        print("  python analyze_sellers.py results/mtg_arbitrage.json 5    # 5% threshold")
        print("  python analyze_sellers.py results/mtg_arbitrage.json 0    # All sellers (no threshold)")
        return 1
    
    threshold = float(sys.argv[2]) if len(sys.argv) > 2 else 12.0
    
    try:
        with open(sys.argv[1], 'r') as f:
            results = json.load(f)
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1
    
    seller_deals = analyze_deals(results, threshold)
    print_report(seller_deals, threshold)
    
    # Sort by number of deals (descending)
    sorted_seller_deals = dict(sorted(
        seller_deals.items(), 
        key=lambda x: len(x[1]['deals']), 
        reverse=True
    ))
    
    # Save JSON
    json_output = sys.argv[1].replace('.json', '_seller_deals.json')
    try:
        with open(json_output, 'w') as f:
            json.dump({'seller_deals': sorted_seller_deals, 'threshold': threshold}, f, indent=2)
        print(f"\n💾 JSON saved to: {json_output}")
    except Exception as e:
        print(f"❌ Error saving JSON: {e}")
        return 1
    
    # Generate HTML website
    html_output = json_output.replace('.json', '.html')
    try:
        generate_html(sorted_seller_deals, threshold, html_output)
        print(f"🌐 HTML saved to: {html_output}")
        print(f"   Open in browser: file://{html_output}")
    except Exception as e:
        print(f"❌ Error generating HTML: {e}")
        return 1
    
    # Generate rejected cards HTML
    rejected_output = json_output.replace('_seller_deals.json', '_rejected.html')
    try:
        generate_rejected_html(results, threshold, rejected_output)
        print(f"📋 Rejected cards HTML saved to: {rejected_output}")
        print(f"   Open in browser: file://{rejected_output}")
    except Exception as e:
        print(f"⚠️  Warning: Could not generate rejected cards HTML: {e}")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
