"""
Functions to save analysis results to files for later review.
"""

import os
import json
import pandas as pd
import numpy as np
from datetime import datetime
from typing import Dict, List, Any
from .utils import get_data_dir, ensure_dir_exists

def clean_nan_values(obj):
    """Recursively clean NaN values from nested data structures."""
    if isinstance(obj, dict):
        return {k: clean_nan_values(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [clean_nan_values(item) for item in obj]
    elif pd.isna(obj) or (isinstance(obj, float) and np.isnan(obj)):
        return None
    else:
        return obj

def get_results_dir() -> str:
    """Get the results directory path."""
    results_dir = os.path.join(get_data_dir(), "results")
    ensure_dir_exists(results_dir)
    return results_dir

def save_candidates(candidates: pd.DataFrame, config: Dict[str, Any]) -> str:
    """
    Save candidate cards to CSV and JSON files.
    
    Args:
        candidates: DataFrame with candidate cards
        config: Configuration used for the analysis
        
    Returns:
        Path to the saved CSV file
    """
    if candidates.empty:
        print("No candidates to save")
        return ""
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_dir = get_results_dir()
    
    # Save as CSV for easy viewing
    csv_path = os.path.join(results_dir, f"candidates_{timestamp}.csv")
    candidates.to_csv(csv_path, index=False)
    
    # Save as JSON with metadata
    json_path = os.path.join(results_dir, f"candidates_{timestamp}.json")
    results_data = {
        "timestamp": timestamp,
        "config": config,
        "total_candidates": len(candidates),
        "price_range": {
            "min": float(candidates['LOWEX+'].min()) if 'LOWEX+' in candidates.columns else None,
            "max": float(candidates['LOWEX+'].max()) if 'LOWEX+' in candidates.columns else None,
            "avg": float(candidates['LOWEX+'].mean()) if 'LOWEX+' in candidates.columns else None
        },
        "discount_range": {
            "min": float(candidates['trend_discount'].min()) if 'trend_discount' in candidates.columns else None,
            "max": float(candidates['trend_discount'].max()) if 'trend_discount' in candidates.columns else None,
            "avg": float(candidates['trend_discount'].mean()) if 'trend_discount' in candidates.columns else None
        },
        "candidates": candidates.to_dict(orient='records')
    }
    
    # Clean NaN values before saving
    clean_results_data = clean_nan_values(results_data)
    
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(clean_results_data, f, indent=2, default=str)
    
    print(f"✅ Saved {len(candidates)} candidates:")
    print(f"   CSV: {csv_path}")
    print(f"   JSON: {json_path}")
    
    return csv_path

def save_buyable_cards(buyable: pd.DataFrame, config: Dict[str, Any]) -> str:
    """
    Save buyable cards analysis results.
    
    Args:
        buyable: DataFrame with buyable cards and evaluation results
        config: Configuration used for the analysis
        
    Returns:
        Path to the saved CSV file
    """
    if buyable.empty:
        print("No buyable cards to save")
        return ""
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_dir = get_results_dir()
    
    # Save as CSV
    csv_path = os.path.join(results_dir, f"buyable_{timestamp}.csv")
    buyable.to_csv(csv_path, index=False)
    
    # Save as JSON with analysis summary
    json_path = os.path.join(results_dir, f"buyable_{timestamp}.json")
    
    # Calculate summary statistics
    total_investment = float(buyable['LOWEX+'].sum()) if 'LOWEX+' in buyable.columns else 0
    avg_margin = float(buyable['best_scenario_margin'].mean()) if 'best_scenario_margin' in buyable.columns else 0
    
    results_data = {
        "timestamp": timestamp,
        "config": config,
        "summary": {
            "total_buyable": len(buyable),
            "total_investment_required": total_investment,
            "average_margin": avg_margin,
            "target_margin": config.get("target_net_margin", 0)
        },
        "top_opportunities": buyable.head(10).to_dict(orient='records')
    }
    
    # Clean NaN values before saving
    clean_results_data = clean_nan_values(results_data)
    
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(clean_results_data, f, indent=2, default=str)
    
    print(f"✅ Saved {len(buyable)} buyable cards:")
    print(f"   CSV: {csv_path}")
    print(f"   JSON: {json_path}")
    
    return csv_path

def save_final_recommendations(recommendations: List[Dict[str, Any]], config: Dict[str, Any]) -> str:
    """
    Save final buy/sell recommendations.
    
    Args:
        recommendations: List of final recommendation dictionaries
        config: Configuration used for the analysis
        
    Returns:
        Path to the saved JSON file
    """
    if not recommendations:
        print("No final recommendations to save")
        return ""
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_dir = get_results_dir()
    
    # Calculate totals
    total_investment = sum(rec['buy_price'] for rec in recommendations)
    total_expected_profit = sum(rec['net_profit'] for rec in recommendations)
    overall_roi = (total_expected_profit / total_investment) if total_investment > 0 else 0
    
    # Save as JSON
    json_path = os.path.join(results_dir, f"final_recommendations_{timestamp}.json")
    results_data = {
        "timestamp": timestamp,
        "config": config,
        "summary": {
            "total_recommendations": len(recommendations),
            "total_investment": total_investment,
            "total_expected_profit": total_expected_profit,
            "overall_roi": overall_roi
        },
        "recommendations": recommendations
    }
    
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(results_data, f, indent=2, default=str)
    
    print(f"✅ Saved {len(recommendations)} final recommendations:")
    print(f"   JSON: {json_path}")
    print(f"   Total investment: €{total_investment:.2f}")
    print(f"   Expected profit: €{total_expected_profit:.2f}")
    print(f"   Overall ROI: {overall_roi*100:.1f}%")
    
    return json_path

def save_analysis_summary(
    total_cards: int,
    candidates_count: int, 
    buyable_count: int,
    recommendations_count: int,
    config: Dict[str, Any]
) -> str:
    """
    Save a summary of the entire analysis run.
    
    Returns:
        Path to the saved summary file
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_dir = get_results_dir()
    
    summary_data = {
        "timestamp": timestamp,
        "config": config,
        "analysis_summary": {
            "total_cards_analyzed": total_cards,
            "candidates_found": candidates_count,
            "buyable_cards": buyable_count,
            "final_recommendations": recommendations_count,
            "success_rate": {
                "candidate_rate": (candidates_count / total_cards * 100) if total_cards > 0 else 0,
                "buyable_rate": (buyable_count / candidates_count * 100) if candidates_count > 0 else 0,
                "recommendation_rate": (recommendations_count / buyable_count * 100) if buyable_count > 0 else 0
            }
        }
    }
    
    json_path = os.path.join(results_dir, f"analysis_summary_{timestamp}.json")
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(summary_data, f, indent=2, default=str)
    
    print(f"✅ Saved analysis summary: {json_path}")
    return json_path

def list_saved_results() -> None:
    """List all saved result files."""
    results_dir = get_results_dir()
    
    if not os.path.exists(results_dir):
        print("No saved results found")
        return
    
    files = sorted([f for f in os.listdir(results_dir) if f.endswith(('.json', '.csv'))])
    
    if not files:
        print("No saved results found")
        return
    
    print(f"\n📁 Saved results in {results_dir}:")
    print("="*50)
    
    for file in files:
        filepath = os.path.join(results_dir, file)
        size = os.path.getsize(filepath)
        mtime = datetime.fromtimestamp(os.path.getmtime(filepath))
        
        print(f"{file:<40} {size:>8} bytes {mtime.strftime('%Y-%m-%d %H:%M')}")
    
    print("="*50)
