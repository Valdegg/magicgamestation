"""
Buy/sell evaluation algorithm and profit calculations.
"""

import pandas as pd
from typing import Dict, Any, List, Optional
from .utils import DEFAULT_CONFIG, calculate_min_sell_price, is_profitable, format_currency

def is_buyable(
    card_data: Dict[str, Any], 
    target_net: float = None,
    fee_rate: float = None
) -> bool:
    """
    Evaluate if a card is buyable based on profit potential.
    
    Args:
        card_data: Dictionary or Series with card data including AVG7, TREND
        target_net: Target net margin (default from config)
        fee_rate: Fee rate (default from config)
        
    Returns:
        True if the card appears buyable
    """
    if target_net is None:
        target_net = DEFAULT_CONFIG["target_net_margin"]
    if fee_rate is None:
        fee_rate = DEFAULT_CONFIG["cardmarket_fee"]
    
    # Convert Series to dict if needed
    if hasattr(card_data, 'to_dict'):
        card_data = card_data.to_dict()
    
    # Get buy price (AVG7 is our real buy target - recent sales price)
    buy_price = card_data.get('AVG30', 0)
    if buy_price <= 0:
        return False
    
    # Estimate sell price using trend and recent averages
    trend_price = card_data.get('TREND', 0)
    avg7_price = card_data.get('AVG7', 0)
    avg1_price = card_data.get('AVG1', 0)
    
    # Use the most conservative estimate for sell price
    potential_sell_prices = [p for p in [trend_price, avg7_price, avg1_price] if p > 0]
    if not potential_sell_prices:
        return False
    
    estimated_sell_price = min(potential_sell_prices)
    
    # Calculate minimum required sell price for target margin
    min_sell_price = calculate_min_sell_price(buy_price, target_net, fee_rate)
    
    # Check if estimated sell price meets our requirements
    return estimated_sell_price >= min_sell_price

def evaluate_card_profit(
    card_data: Dict[str, Any],
    target_net: float = None,
    fee_rate: float = None
) -> Dict[str, Any]:
    """
    Detailed profit evaluation for a card.
    
    Returns:
        Dictionary with evaluation results
    """
    if target_net is None:
        target_net = DEFAULT_CONFIG["target_net_margin"]
    if fee_rate is None:
        fee_rate = DEFAULT_CONFIG["cardmarket_fee"]
    
    # Convert Series to dict if needed
    if hasattr(card_data, 'to_dict'):
        card_data = card_data.to_dict()
    
    buy_price = card_data.get('AVG30', 0)
    trend_price = card_data.get('TREND', 0)
    avg7_price = card_data.get('AVG7', 0)
    avg1_price = card_data.get('AVG1', 0)
    
    min_sell_price = calculate_min_sell_price(buy_price, target_net, fee_rate)
    
    # Evaluate different sell price scenarios
    scenarios = {}
    
    for price_type, price in [('TREND', trend_price), ('AVG7', avg7_price), ('AVG1', avg1_price)]:
        if price > 0:
            net_profit = price * (1 - fee_rate) - buy_price
            margin = net_profit / buy_price if buy_price > 0 else 0
            scenarios[price_type] = {
                'sell_price': price,
                'net_profit': net_profit,
                'margin': margin,
                'meets_target': margin >= target_net
            }
    
    return {
        'card_name': card_data.get('Name', f"Card ID {card_data.get('idProduct', 'Unknown')}"),
        'buy_price': buy_price,
        'min_sell_price': min_sell_price,
        'scenarios': scenarios,
        'is_buyable': any(s['meets_target'] for s in scenarios.values()),
        'best_scenario': max(scenarios.items(), key=lambda x: x[1]['margin']) if scenarios else None
    }

def check_top10_feasibility(
    card_data: Dict[str, Any], 
    top10_listings: List[Dict[str, Any]],
    target_net: float = None,
    fee_rate: float = None,
    rank_target: int = None,
    undercut_buffer: float = None
) -> Dict[str, Any]:
    """
    Check if a card can be profitably sold in the top-10 listings.
    
    Args:
        card_data: Card information
        top10_listings: List of top-10 listing dictionaries with 'price' key
        target_net: Target net margin
        fee_rate: Fee rate  
        rank_target: Target rank position (1-10)
        undercut_buffer: Amount to undercut by
        
    Returns:
        Dictionary with buy/sell decision and recommended prices
    """
    if target_net is None:
        target_net = DEFAULT_CONFIG["target_net_margin"]
    if fee_rate is None:
        fee_rate = DEFAULT_CONFIG["cardmarket_fee"]
    if rank_target is None:
        rank_target = DEFAULT_CONFIG["rank_target"]
    if undercut_buffer is None:
        undercut_buffer = DEFAULT_CONFIG["undercut_buffer"]
    
    # Convert Series to dict if needed
    if hasattr(card_data, 'to_dict'):
        card_data = card_data.to_dict()
    
    buy_price = card_data.get('AVG30', 0)
    card_name = card_data.get('Name', f"Card ID {card_data.get('idProduct', 'Unknown')}")
    
    if buy_price <= 0 or not top10_listings:
        return {
            'buy': False,
            'reason': 'Invalid buy price or no listings',
            'card_name': card_name
        }
    
    # Calculate minimum sell price needed
    min_sell_price = calculate_min_sell_price(buy_price, target_net, fee_rate)
    
    # Sort listings by price (ascending)
    sorted_listings = sorted(top10_listings, key=lambda x: x.get('price', float('inf')))
    
    # Find target position (convert to 0-based index)
    target_index = min(rank_target - 1, len(sorted_listings) - 1)
    
    if target_index < 0:
        return {
            'buy': False,
            'reason': 'No listings available',
            'card_name': card_name
        }
    
    # Get the price at our target rank
    target_rank_price = sorted_listings[target_index]['price']
    
    # Our listing price would be slightly below target rank price
    our_list_price = max(target_rank_price - undercut_buffer, min_sell_price)
    
    # Check if we can be profitable at this price
    if our_list_price < min_sell_price:
        return {
            'buy': False,
            'reason': f'Cannot achieve target margin. Need €{min_sell_price:.2f}, can only get €{our_list_price:.2f}',
            'card_name': card_name,
            'min_sell_price': min_sell_price,
            'market_price': target_rank_price
        }
    
    # Calculate actual profit at our list price
    net_profit = our_list_price * (1 - fee_rate) - buy_price
    actual_margin = net_profit / buy_price
    
    return {
        'buy': True,
        'card_name': card_name,
        'buy_price': buy_price,
        'list_price': our_list_price,
        'target_rank': rank_target,
        'net_profit': net_profit,
        'margin': actual_margin,
        'reason': f'Profitable at rank {rank_target}',
        'top10_analysis': {
            'lowest_price': sorted_listings[0]['price'] if sorted_listings else 0,
            'highest_price': sorted_listings[-1]['price'] if sorted_listings else 0,
            'target_rank_price': target_rank_price,
            'our_competitive_position': rank_target
        }
    }

def batch_evaluate_cards(
    cards_df: pd.DataFrame,
    target_net: float = None,
    fee_rate: float = None
) -> pd.DataFrame:
    """
    Evaluate buyability for a batch of cards.
    
    Returns:
        DataFrame with evaluation results added
    """
    if cards_df.empty:
        return cards_df
    
    if target_net is None:
        target_net = DEFAULT_CONFIG["target_net_margin"]
    if fee_rate is None:
        fee_rate = DEFAULT_CONFIG["cardmarket_fee"]
    
    results = []
    
    for _, card in cards_df.iterrows():
        evaluation = evaluate_card_profit(card, target_net, fee_rate)
        
        # Add evaluation results to card data
        card_dict = card.to_dict()
        card_dict.update({
            'is_buyable': evaluation['is_buyable'],
            'min_sell_price': evaluation['min_sell_price'],
            'best_scenario_type': evaluation['best_scenario'][0] if evaluation['best_scenario'] else None,
            'best_scenario_margin': evaluation['best_scenario'][1]['margin'] if evaluation['best_scenario'] else 0
        })
        
        results.append(card_dict)
    
    result_df = pd.DataFrame(results)
    
    # Filter to only buyable cards
    buyable_df = result_df[result_df['is_buyable'] == True]
    
    print(f"Evaluated {len(cards_df)} cards, {len(buyable_df)} are buyable")
    
    return buyable_df

def print_evaluation_summary(evaluation: Dict[str, Any]) -> None:
    """Print a formatted summary of card evaluation."""
    print(f"\n=== {evaluation['card_name']} ===")
    print(f"Buy at: {format_currency(evaluation['buy_price'])}")
    print(f"Min sell: {format_currency(evaluation['min_sell_price'])}")
    
    if evaluation['is_buyable']:
        print("✅ BUYABLE")
        if evaluation['best_scenario']:
            scenario_type, scenario = evaluation['best_scenario']
            print(f"Best scenario ({scenario_type}): {format_currency(scenario['sell_price'])} → {scenario['margin']*100:.1f}% margin")
    else:
        print("❌ NOT BUYABLE")
    
    print("Scenarios:")
    for scenario_type, scenario in evaluation['scenarios'].items():
        status = "✅" if scenario['meets_target'] else "❌"
        print(f"  {status} {scenario_type}: {format_currency(scenario['sell_price'])} → {scenario['margin']*100:.1f}% margin")
    
    print("="*40)
