"""
Functions to download and parse Cardmarket data (CSV and JSON).
"""

import os
import requests
import pandas as pd
import json
from datetime import datetime
from typing import Tuple, Optional
from .utils import get_raw_data_dir, ensure_dir_exists

# Cardmarket data URLs (these may need to be updated based on actual Cardmarket API)
CARDMARKET_URLS = {
    "products": "https://www.cardmarket.com/en/Magic/Products/Singles",
    "priceguide": "https://www.cardmarket.com/en/Magic/Products/PriceGuide"
}

def download_data_file(url: str, filename: str, force_download: bool = False) -> str:
    """
    Download a data file from Cardmarket.
    
    Args:
        url: URL to download from
        filename: Local filename to save as
        force_download: Whether to force download even if file exists today
        
    Returns:
        Path to the downloaded file
    """
    raw_dir = get_raw_data_dir()
    ensure_dir_exists(raw_dir)
    
    # Add date to filename
    today = datetime.now().strftime("%Y%m%d")
    base_name, ext = os.path.splitext(filename)
    dated_filename = f"{base_name}_{today}{ext}"
    filepath = os.path.join(raw_dir, dated_filename)
    
    # Check if file already exists and is from today
    if os.path.exists(filepath) and not force_download:
        print(f"Using existing file: {filepath}")
        return filepath
    
    print(f"Downloading {url} to {filepath}")
    
    # Note: This is a placeholder implementation
    # Real implementation would need proper Cardmarket API access or scraping
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        }
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(response.text)
            
        return filepath
        
    except requests.RequestException as e:
        print(f"Error downloading {url}: {e}")
        # For development, create a mock file
        return create_mock_data(filepath, filename)

def create_mock_data(filepath: str, filename: str) -> str:
    """Create mock data for development purposes."""
    print(f"Creating mock data for {filename}")
    
    if "product" in filename.lower():
        # Mock products CSV
        mock_data = {
            'idProduct': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            'Name': ['Lightning Bolt', 'Black Lotus', 'Mox Ruby', 'Ancestral Recall', 'Time Walk', 
                    'Force of Will', 'Tarmogoyf', 'Snapcaster Mage', 'Jace, the Mind Sculptor', 'Liliana of the Veil'],
            'Category': ['Magic Single'] * 10,
            'categoryID': [1] * 10,
            'idExpansion': [1, 2, 2, 2, 2, 3, 4, 5, 6, 7],
            'Expansion': ['Lightning Bolt Reprint', 'Alpha', 'Alpha', 'Alpha', 'Alpha', 
                         'Alliances', 'Future Sight', 'Innistrad', 'Worldwake', 'Innistrad'],
            'Rarity': ['Common', 'Rare', 'Rare', 'Rare', 'Rare', 'Rare', 'Rare', 'Rare', 'Rare', 'Rare'],
            'Number': ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
        }
        df = pd.DataFrame(mock_data)
        df.to_csv(filepath, index=False)
        return filepath
    else:
        # Mock price guide JSON (based on the format you showed)
        mock_data = {
            "version": 1,
            "createdAt": "2025-09-29T02:45:51+0200",
            "priceGuides": [
                {"idProduct": 1, "idCategory": 1, "avg": 0.04, "low": 0.02, "trend": 0.11, "avg1": 0.39, "avg7": 0.11, "avg30": 0.07, "avg-foil": 0.64, "low-foil": 0.04, "trend-foil": 0.38, "avg1-foil": 0.89, "avg7-foil": 0.39, "avg30-foil": 0.33},
                {"idProduct": 2, "idCategory": 1, "avg": 8000.0, "low": 6000.0, "trend": 8500.0, "avg1": 8200.0, "avg7": 7800.0, "avg30": 8200.0, "avg-foil": 0.0, "low-foil": 0.0, "trend-foil": 0.0, "avg1-foil": 0.0, "avg7-foil": 0.0, "avg30-foil": 0.0},
                {"idProduct": 3, "idCategory": 1, "avg": 2800.0, "low": 2200.0, "trend": 3200.0, "avg1": 3000.0, "avg7": 2900.0, "avg30": 3100.0, "avg-foil": 0.0, "low-foil": 0.0, "trend-foil": 0.0, "avg1-foil": 0.0, "avg7-foil": 0.0, "avg30-foil": 0.0},
                {"idProduct": 4, "idCategory": 1, "avg": 2300.0, "low": 1800.0, "trend": 2700.0, "avg1": 2500.0, "avg7": 2400.0, "avg30": 2600.0, "avg-foil": 0.0, "low-foil": 0.0, "trend-foil": 0.0, "avg1-foil": 0.0, "avg7-foil": 0.0, "avg30-foil": 0.0},
                {"idProduct": 5, "idCategory": 1, "avg": 1800.0, "low": 1500.0, "trend": 2200.0, "avg1": 2000.0, "avg7": 1950.0, "avg30": 2100.0, "avg-foil": 0.0, "low-foil": 0.0, "trend-foil": 0.0, "avg1-foil": 0.0, "avg7-foil": 0.0, "avg30-foil": 0.0},
                {"idProduct": 6, "idCategory": 1, "avg": 85.0, "low": 70.0, "trend": 95.0, "avg1": 88.0, "avg7": 82.0, "avg30": 87.0, "avg-foil": 0.0, "low-foil": 0.0, "trend-foil": 0.0, "avg1-foil": 0.0, "avg7-foil": 0.0, "avg30-foil": 0.0},
                {"idProduct": 7, "idCategory": 1, "avg": 75.0, "low": 60.0, "trend": 85.0, "avg1": 78.0, "avg7": 72.0, "avg30": 77.0, "avg-foil": 0.0, "low-foil": 0.0, "trend-foil": 0.0, "avg1-foil": 0.0, "avg7-foil": 0.0, "avg30-foil": 0.0},
                {"idProduct": 8, "idCategory": 1, "avg": 65.0, "low": 55.0, "trend": 75.0, "avg1": 68.0, "avg7": 62.0, "avg30": 67.0, "avg-foil": 0.0, "low-foil": 0.0, "trend-foil": 0.0, "avg1-foil": 0.0, "avg7-foil": 0.0, "avg30-foil": 0.0},
                {"idProduct": 9, "idCategory": 1, "avg": 95.0, "low": 80.0, "trend": 110.0, "avg1": 98.0, "avg7": 92.0, "avg30": 97.0, "avg-foil": 0.0, "low-foil": 0.0, "trend-foil": 0.0, "avg1-foil": 0.0, "avg7-foil": 0.0, "avg30-foil": 0.0},
                {"idProduct": 10, "idCategory": 1, "avg": 105.0, "low": 90.0, "trend": 120.0, "avg1": 108.0, "avg7": 102.0, "avg30": 107.0, "avg-foil": 0.0, "low-foil": 0.0, "trend-foil": 0.0, "avg1-foil": 0.0, "avg7-foil": 0.0, "avg30-foil": 0.0}
            ]
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(mock_data, f, indent=2)
        return filepath

def load_products_csv(force_download: bool = False) -> pd.DataFrame:
    """Load the products CSV from Cardmarket."""
    filepath = download_data_file(
        CARDMARKET_URLS["products"], 
        "products.csv", 
        force_download
    )
    
    try:
        df = pd.read_csv(filepath)
        print(f"Loaded {len(df)} products")
        return df
    except Exception as e:
        print(f"Error loading products CSV: {e}")
        return pd.DataFrame()

def load_priceguide_json(force_download: bool = False) -> pd.DataFrame:
    """Load the price guide JSON from Cardmarket."""
    filepath = download_data_file(
        CARDMARKET_URLS["priceguide"], 
        "priceguide.json", 
        force_download
    )
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Extract price guides from JSON structure
        price_guides = data.get('priceGuides', [])
        
        # Convert to DataFrame and rename columns to match expected format
        df = pd.DataFrame(price_guides)
        
        # Rename columns to match the expected format from your original code
        column_mapping = {
            'avg': 'AVG',
            'low': 'LOW', 
            'trend': 'TREND',
            'avg1': 'AVG1',
            'avg7': 'AVG7', 
            'avg30': 'AVG30',
            'low-foil': 'LOWFOIL',
            'avg-foil': 'AVGFOIL'
        }
        
        # Rename columns that exist
        for old_col, new_col in column_mapping.items():
            if old_col in df.columns:
                df = df.rename(columns={old_col: new_col})
        
        # Add LOWEX+ column (use LOW as approximation, or could be calculated differently)
        if 'LOW' in df.columns:
            df['LOWEX+'] = df['LOW'] * 1.1  # Assume EX+ is ~10% higher than LOW
        
        print(f"Loaded price data for {len(df)} products")
        return df
    except Exception as e:
        print(f"Error loading price guide JSON: {e}")
        return pd.DataFrame()

def load_csvs(force_download: bool = False) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Load both products (CSV) and price guide (JSON) data.
    
    Returns:
        Tuple of (products_df, priceguide_df)
    """
    products = load_products_csv(force_download)
    priceguide = load_priceguide_json(force_download)
    
    return products, priceguide

def merge_product_data(products: pd.DataFrame, priceguide: pd.DataFrame) -> pd.DataFrame:
    """
    Merge products and price guide data on idProduct.
    
    Returns:
        Merged DataFrame with product info and pricing data
    """
    if products.empty or priceguide.empty:
        return pd.DataFrame()
    
    merged = pd.merge(products, priceguide, on='idProduct', how='inner')
    print(f"Merged data for {len(merged)} products")
    
    return merged
