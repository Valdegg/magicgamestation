"""
Scraping functions to fetch top-10 NM EN listings from Cardmarket.
"""

import requests
import time
import random
from bs4 import BeautifulSoup
from .utils import get_cardmarket_url
from .config import get_config
from typing import List, Dict, Any, Optional
from urllib.parse import urljoin, quote

class CardmarketScraper:
    """Scraper for Cardmarket listings with rate limiting and error handling."""
    
    def __init__(self, delay_range: tuple = (1, 3)):
        """
        Initialize scraper.
        
        Args:
            delay_range: Tuple of (min_delay, max_delay) in seconds between requests
        """
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })
        self.delay_range = delay_range
        self.last_request_time = 0
    
    def _rate_limit(self):
        """Apply rate limiting between requests."""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        min_delay = random.uniform(*self.delay_range)
        if time_since_last < min_delay:
            sleep_time = min_delay - time_since_last
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
    
    def fetch_top10(self, card_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Fetch top-10 NM EN listings for a card.
        
        Args:
            card_data: Dictionary with card information including idProduct and Name
            
        Returns:
            List of listing dictionaries with price, condition, language, seller info
        """
        card_id = card_data.get('idProduct')
        card_name = card_data.get('Name', f"Card ID {card_data.get('idProduct', 'Unknown')}")
        
        if not card_id:
            print(f"No product ID for {card_name}")
            return []
        
        # Attempt to scrape actual Cardmarket listings
        return self._scrape_cardmarket_listings(card_data)
    
    
    def _scrape_cardmarket_listings(self, card_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Scrape actual Cardmarket listings using proper URLs.
        
        Real implementation would need to:
        1. Build the correct Cardmarket URL for the card
        2. Handle authentication/sessions if required
        3. Parse the HTML to extract listing data
        4. Handle pagination if needed
        5. Respect rate limits and ToS
        """
        self._rate_limit()
        
        # Get card info
        card_id = card_data.get('idProduct')
        card_name = card_data.get('name', f"Card ID {card_id}")
        expansion_name = card_data.get('expansionName')
        
        # Build proper URL using expansion and card name
        config = get_config()
        use_german_only = config.get('USE_GERMAN_SELLERS_ONLY', False)
        url = get_cardmarket_url(card_id, card_name, expansion_name, 'direct', include_filters=use_german_only)
        
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Parse the actual HTML structure
            listings = self._parse_listings_html(soup)
            
            return listings[:10]  # Return top 10
            
        except requests.RequestException as e:
            print(f"Error scraping {url}: {e}")
            print("Note: Cardmarket scraping requires proper authentication and may be restricted")
            return []
    
    def _parse_listings_html(self, soup: BeautifulSoup) -> List[Dict[str, Any]]:
        """
        Parse Cardmarket listings HTML.
        
        This needs to be implemented based on the actual HTML structure
        of Cardmarket's listing pages. The exact selectors would need to be
        determined by inspecting the live Cardmarket pages.
        """
        listings = []
        
        # TODO: Implement actual parsing based on Cardmarket's HTML structure
        # This would require:
        # 1. Inspecting the actual Cardmarket listing pages
        # 2. Finding the correct CSS selectors for price, condition, seller, etc.
        # 3. Handling different page layouts and edge cases
        
        print("Warning: Cardmarket HTML parsing not yet implemented")
        print("This requires analysis of actual Cardmarket page structure")
        
        return listings

def fetch_top10(card_data: Dict[str, Any], scraper: Optional[CardmarketScraper] = None) -> List[Dict[str, Any]]:
    """
    Convenience function to fetch top-10 listings for a card.
    
    Args:
        card_data: Card information dictionary
        scraper: Optional scraper instance (creates new one if None)
        
    Returns:
        List of top-10 listings
    """
    if scraper is None:
        scraper = CardmarketScraper()
    
    return scraper.fetch_top10(card_data)

def analyze_market_depth(listings: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Analyze market depth from listings data.
    
    Returns:
        Dictionary with market analysis
    """
    if not listings:
        return {'error': 'No listings to analyze'}
    
    prices = [listing['price'] for listing in listings]
    
    analysis = {
        'total_listings': len(listings),
        'price_range': {
            'min': min(prices),
            'max': max(prices),
            'spread': max(prices) - min(prices)
        },
        'price_distribution': {
            'median': sorted(prices)[len(prices)//2],
            'avg': sum(prices) / len(prices)
        },
        'market_tightness': (max(prices) - min(prices)) / min(prices) if min(prices) > 0 else 0,
        'top_5_avg': sum(prices[:5]) / 5 if len(prices) >= 5 else sum(prices) / len(prices),
        'bottom_5_avg': sum(prices[-5:]) / 5 if len(prices) >= 5 else sum(prices) / len(prices)
    }
    
    return analysis

def print_listings_summary(card_name: str, listings: List[Dict[str, Any]]) -> None:
    """Print a formatted summary of listings."""
    print(f"\n=== Top-10 Listings for {card_name} ===")
    
    if not listings:
        print("No listings found")
        return
    
    print(f"{'Rank':<4} {'Price':<8} {'Condition':<6} {'Seller':<12} {'Qty':<3}")
    print("-" * 40)
    
    for listing in listings:
        print(f"{listing['rank']:<4} €{listing['price']:<7.2f} {listing['condition']:<6} "
              f"{listing['seller']:<12} {listing['quantity']:<3}")
    
    # Print analysis
    analysis = analyze_market_depth(listings)
    print(f"\nMarket Analysis:")
    print(f"Price range: €{analysis['price_range']['min']:.2f} - €{analysis['price_range']['max']:.2f}")
    print(f"Top-5 avg: €{analysis['top_5_avg']:.2f}")
    print(f"Market tightness: {analysis['market_tightness']*100:.1f}%")
    print("="*50)
