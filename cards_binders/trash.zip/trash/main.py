#!/usr/bin/env python3
"""
MTG Arbitrage - Complete Pipeline

This is the main entry point for the MTG arbitrage system.
It runs the complete pipeline:
1. Download today's price guide
2. Find profitable candidates 
3. Fetch live prices for verification
4. Show actionable results

Usage:
    python main.py                    # Run with defaults (5 candidates)
    python main.py 10                 # Check 10 candidates
    python main.py 3 --no-live       # Just show candidates, no live prices
    python main.py 5 --manual        # Open candidates in browser manually
"""

import sys
import argparse
import time
import random
import json
import os
import webbrowser
from datetime import datetime
from typing import List, Dict
import pandas as pd

# Import our modules
from mtg_arbitrage.data_loader import load_data_with_names
from mtg_arbitrage import filter as mtg_filter
from mtg_arbitrage.utils import format_currency
from mtg_arbitrage.wishlist import create_wishlist_candidates, print_wishlist_summary

# Import live price checking
try:
    from live_price_check import LivePriceChecker
    LIVE_CHECKING_AVAILABLE = True
except ImportError:
    LIVE_CHECKING_AVAILABLE = False

# Import manual verification
try:
    from manual_verification import open_candidates_for_verification
    MANUAL_VERIFICATION_AVAILABLE = True
except ImportError:
    MANUAL_VERIFICATION_AVAILABLE = False

# Import seller analysis
try:
    from analyze_sellers import analyze_deals, generate_html as generate_seller_html, generate_rejected_html
    SELLER_ANALYSIS_AVAILABLE = True
except ImportError:
    SELLER_ANALYSIS_AVAILABLE = False


class MTGArbitragePipeline:
    """Complete MTG arbitrage analysis pipeline."""
    
    def __init__(self):
        """Initialize the pipeline."""
        self.data = None
        self.candidates = None
        self.results = None
        
    def step1_load_data(self, force_download: bool = False) -> bool:
        """
        Step 1: Load today's price guide data.
        
        Args:
            force_download: Force download of fresh data
            
        Returns:
            True if successful, False otherwise
        """
        print("🔄 STEP 1: Loading Price Guide Data")
        print("=" * 50)
        
        try:
            self.data = load_data_with_names(force_download=force_download)
            
            if self.data.empty:
                print("❌ No data loaded")
                return False
            
            print(f"✅ Loaded {len(self.data):,} products with pricing data")
            return True
            
        except Exception as e:
            print(f"❌ Error loading data: {e}")
            return False
    
    def step2_find_candidates(self, 
                            price_min: float = None, 
                            price_max: float = None,
                            discount_threshold: float = None,
                            limit: int = 20,
                            use_wishlist: bool = False,
                            use_both: bool = False,
                            wishlist_file: str = 'wishlist.json') -> bool:
        """
        Step 2: Find profitable candidates.
        
        Args:
            price_min: Minimum AVG7 price
            price_max: Maximum AVG7 price  
            discount_threshold: Minimum discount (AVG7 vs TREND)
            limit: Maximum candidates to return
            
        Returns:
            True if candidates found, False otherwise
        """
        print(f"\n🔍 STEP 2: Finding Candidates")
        print("=" * 50)
        
        if self.data is None or self.data.empty:
            print("❌ No data available. Run step1_load_data() first.")
            return False
        
        # Load from config if not provided
        from mtg_arbitrage.utils import DEFAULT_CONFIG
        if price_min is None:
            price_min = DEFAULT_CONFIG["price_min"]
        if price_max is None:
            price_max = DEFAULT_CONFIG["price_max"]
        if discount_threshold is None:
            discount_threshold = DEFAULT_CONFIG["trend_discount_threshold"]
        
        try:
            if use_both:
                print("🎯🔍 Using BOTH wishlist and general candidates")
                
                # Get wishlist candidates
                wishlist_candidates = create_wishlist_candidates(self.data, wishlist_file)
                
                # Get general candidates
                general_candidates = mtg_filter.find_candidates(
                    self.data,
                    price_min=price_min,
                    price_max=price_max,
                    trend_discount_threshold=discount_threshold
                )
                
                # Combine and deduplicate by card ID
                all_candidates = pd.DataFrame()
                
                if not wishlist_candidates.empty:
                    all_candidates = pd.concat([all_candidates, wishlist_candidates], ignore_index=True)
                    print(f"📋 Found {len(wishlist_candidates)} wishlist candidates")
                
                if not general_candidates.empty:
                    # Remove duplicates (cards that are in both wishlist and general)
                    if not all_candidates.empty:
                        general_unique = general_candidates[~general_candidates['idProduct'].isin(all_candidates['idProduct'])]
                        all_candidates = pd.concat([all_candidates, general_unique], ignore_index=True)
                        print(f"📊 Found {len(general_unique)} additional general candidates")
                    else:
                        all_candidates = general_candidates
                        print(f"📊 Found {len(general_candidates)} general candidates")
                
                if all_candidates.empty:
                    print("❌ No candidates found from either wishlist or general filtering")
                    return False
                
                # Sort by discount percentage (highest first)
                all_candidates = all_candidates.sort_values('real_discount', ascending=False)
                
                # Take the top candidates (or all if no limit)
                if limit:
                    self.candidates = all_candidates.head(limit)
                    print(f"✅ Combined total: {len(self.candidates)} candidates for analysis (limited to {limit})")
                else:
                    self.candidates = all_candidates
                    print(f"✅ Combined total: {len(self.candidates)} candidates for analysis (ALL)")
                
                # Show combined preview
                print(f"\n📋 Top 3 Combined Candidates Preview:")
                for i, (_, card) in enumerate(self.candidates.head(3).iterrows(), 1):
                    name = card.get('name', f"Card ID {card.get('idProduct')}")
                    expansion = card.get('expansionName', 'Unknown')
                    avg30 = card.get('AVG30', 0)
                    trend = card.get('TREND', 0)
                    discount = card.get('real_discount', 0) * 100
                    source = "🎯 Wishlist" if 'wishlist_item' in card and pd.notna(card['wishlist_item']) else "📊 General"
                    
                    print(f"  {i}. {name} ({expansion}) - {source}")
                    print(f"     AVG30: {format_currency(avg30)} | TREND: {format_currency(trend)} | Discount: {discount:.1f}%")
                
            elif use_wishlist:
                print("🎯 Using wishlist-based candidate selection")
                
                # Use wishlist candidates
                all_candidates = create_wishlist_candidates(self.data, wishlist_file)
                
                if all_candidates.empty:
                    print("❌ No wishlist candidates found")
                    print("💡 Try updating your wishlist.json or check if cards are in the price guide")
                    return False
                
                # Take the top candidates (wishlist is already sorted by discount) or all if no limit
                if limit:
                    self.candidates = all_candidates.head(limit)
                    print(f"✅ Found {len(self.candidates)} wishlist candidates for analysis (limited to {limit})")
                else:
                    self.candidates = all_candidates
                    print(f"✅ Found {len(self.candidates)} wishlist candidates for analysis (ALL)")
                
                # Show wishlist summary instead of regular preview
                print_wishlist_summary(self.candidates)
                
            else:
                print("📊 Using general filtering")
                
                # Find candidates
                all_candidates = mtg_filter.find_candidates(
                    self.data,
                    price_min=price_min,
                    price_max=price_max,
                    trend_discount_threshold=discount_threshold
                )
                
                if all_candidates.empty:
                    print("❌ No candidates found with current criteria")
                    return False
                
                # Filter out cards with missing expansion names
                initial_count = len(all_candidates)
                filtered_candidates = all_candidates[
                    (all_candidates['expansionName'].notna()) & 
                    (all_candidates['expansionName'] != 'nan') &
                    (all_candidates['expansionName'].astype(str) != 'nan')
                ]
                
                # Take top candidates or all if no limit
                if limit:
                    self.candidates = filtered_candidates.head(limit)
                else:
                    self.candidates = filtered_candidates
                
                filtered_out = initial_count - len(filtered_candidates)
                if filtered_out > 0:
                    print(f"📋 Filtered out {filtered_out} cards with missing set names")
                
                if limit:
                    print(f"✅ Found {len(self.candidates)} candidates for analysis (limited to {limit})")
                else:
                    print(f"✅ Found {len(self.candidates)} candidates for analysis (ALL)")
                
                # Show top 3 candidates preview for general filtering
                print(f"\n📋 Top 3 Candidates Preview:")
                for i, (_, card) in enumerate(self.candidates.head(3).iterrows(), 1):
                    name = card.get('name', f"Card ID {card.get('idProduct')}")
                    expansion = card.get('expansionName', 'Unknown')
                    avg7 = card.get('AVG7', 0)
                    avg30 = card.get('AVG30', 0)
                    trend = card.get('TREND', 0)
                    discount = card.get('real_discount', 0) * 100
                    
                    print(f"  {i}. {name} ({expansion})")
                    print(f"     AVG30: {format_currency(avg30)} | TREND: {format_currency(trend)} | Discount: {discount:.1f}%")
            
            return True
            
        except Exception as e:
            print(f"❌ Error finding candidates: {e}")
            return False
    
    def step3_check_live_prices(self, max_candidates: int = 10) -> bool:
        """
        Step 3: Check live prices for candidates.
        
        Args:
            max_candidates: Maximum number of candidates to check live prices for
            
        Returns:
            True if successful, False otherwise
        """
        print(f"\n💰 STEP 3: Checking Live Prices")
        print("=" * 50)
        
        if self.candidates is None or self.candidates.empty:
            print("❌ No candidates available. Run step2_find_candidates() first.")
            return False
        
        if not LIVE_CHECKING_AVAILABLE:
            print("❌ Live price checking not available")
            return False
        
        try:
            # Initialize live price checker with exponential backoff (30s, 60s, 120s, 240s)
            checker = LivePriceChecker(use_simple_scraper=True, use_proxies=False, max_retries=3)
            
            if not checker.scraper:
                print("❌ No scraper available for live price checking")
                return False
            
            print(f"✅ Using {checker.scraper_type} scraper (with exponential backoff: 30s/60s/120s)")
            
            # Check live prices for top candidates
            candidates_to_check = self.candidates.head(max_candidates)
            self.results = []
            
            for i, (_, card) in enumerate(candidates_to_check.iterrows(), 1):
                card_name = card.get('name', f"Card ID {card.get('idProduct')}")
                print(f"\n📋 Checking {i}/{len(candidates_to_check)}: {card_name}")
                
                # Check live prices
                live_analysis = checker.check_live_prices(card.to_dict())
                
                result = {
                    'rank': i,
                    'card_data': card.to_dict(),
                    'live_analysis': live_analysis
                }
                
                if live_analysis:
                    cheapest_good = live_analysis.get('cheapest_good_condition')
                    if cheapest_good:
                        good_details = live_analysis['cheapest_good_condition_details']
                        print(f"   🎯 Best EX+: €{cheapest_good:.2f} ({good_details['condition']}) - {good_details['seller']}")
                        
                        # Show comparison with market indicators
                        avg7 = card.get('AVG7', 0)
                        avg30 = card.get('AVG30', 0)
                        trend = card.get('TREND', 0)
                        
                        # Primary comparison: live price vs TREND (market expectation)
                        if trend > 0:
                            trend_diff_pct = (cheapest_good - trend) / trend * 100
                            if trend_diff_pct <= -5:
                                print(f"   ✅ EXCELLENT: {trend_diff_pct:+.1f}% vs TREND")
                            elif trend_diff_pct <= 0:
                                print(f"   🟡 Good: {trend_diff_pct:+.1f}% vs TREND")
                            else:
                                print(f"   ❌ Expensive: {trend_diff_pct:+.1f}% vs TREND")
                        
                        # Secondary info: show AVG30 as primary comparison  
                        if avg30 > 0:
                            avg30_diff_pct = (cheapest_good - avg30) / avg30 * 100
                            print(f"       (vs AVG30: {avg30_diff_pct:+.1f}%)")
                    else:
                        print(f"   ⚠️  No EX+ listings found")
                else:
                    print(f"   ❌ Could not fetch live prices")
                
                self.results.append(result)
                
                # Longer delay between cards to avoid rate limiting
                if i < len(candidates_to_check):
                    delay = random.uniform(10, 15)  # 10-15 seconds between cards
                    print(f"   ⏳ Waiting {delay:.1f}s before next card...")
                    time.sleep(delay)
            
            print(f"\n✅ Checked live prices for {len(self.results)} candidates")
            return True
            
        except Exception as e:
            # Re-raise rate limit exceptions to stop the script
            if "RATE LIMITED" in str(e):
                raise
            print(f"❌ Error checking live prices: {e}")
            return False
    
    def step4_show_results(self, save_results: bool = True, run_type: str = 'candidates', 
                           run_param: int = 0, wishlist_file: str = '') -> None:
        """Step 4: Show final results and summary."""
        print(f"\n📊 STEP 4: Final Results")
        print("=" * 50)
        
        if not self.results:
            print("❌ No results available")
            return
        
        # Analyze results
        excellent_deals = []
        good_deals = []
        expensive_deals = []
        no_data = []
        
        for result in self.results:
            live_analysis = result.get('live_analysis')
            
            if not live_analysis:
                no_data.append(result)
                continue
            
            cheapest_good = live_analysis.get('cheapest_good_condition')
            if not cheapest_good:
                no_data.append(result)
                continue
            
            # Check if it's a good deal - accept deals below TREND price
            # Note: TREND includes all conditions, so we add a condition premium
            # to account for EX+/NM cards naturally costing more than damaged/played
            trend = result['card_data'].get('TREND', 0)
            avg30 = result['card_data'].get('AVG30', 0)
            
            # Condition premium: EX+ cards can be up to X% above TREND and still be "good"
            # This accounts for TREND including lower-condition sales
            # Configurable in config.env via CONDITION_PREMIUM (default: 0.15 = 15%)
            from mtg_arbitrage.config import get_config
            config = get_config()
            CONDITION_PREMIUM = config.get('CONDITION_PREMIUM', 0.15)
            
            if trend > 0:
                # Adjust TREND upward to account for condition premium
                adjusted_trend = trend * (1 + CONDITION_PREMIUM)
                trend_diff_pct = (cheapest_good - adjusted_trend) / adjusted_trend * 100
                
                if trend_diff_pct <= -5:  # At least 5% below adjusted TREND
                    excellent_deals.append(result)
                elif trend_diff_pct <= 0:  # Below adjusted TREND but within 5%
                    good_deals.append(result)
                else:
                    expensive_deals.append(result)  # Above adjusted TREND = not interested
        
        # Show results by category
        if excellent_deals:
            print(f"\n🎉 EXCELLENT DEALS (≥5% below adjusted TREND+20%): {len(excellent_deals)}")
            for result in excellent_deals:
                self._print_deal_summary(result, "🎯")
        
        if good_deals:
            print(f"\n🟡 GOOD DEALS (below adjusted TREND+20%): {len(good_deals)}")
            for result in good_deals:
                self._print_deal_summary(result, "🟡")
        
        if expensive_deals:
            print(f"\n❌ EXPENSIVE (above adjusted TREND+20%): {len(expensive_deals)}")
            for result in expensive_deals:
                self._print_deal_summary(result, "❌")
        
        if no_data:
            print(f"\n⚠️  NO LIVE DATA: {len(no_data)}")
            for result in no_data:
                card_name = result['card_data'].get('name', 'Unknown')
                print(f"   • {card_name}")
        
        # Final summary
        print(f"\n🎯 PIPELINE SUMMARY:")
        print(f"   Total candidates analyzed: {len(self.results)}")
        print(f"   Excellent deals (≥5% below TREND+20%): {len(excellent_deals)}")
        print(f"   Good deals (below TREND+20%): {len(good_deals)}")
        print(f"   Expensive (above TREND+20%): {len(expensive_deals)}")
        print(f"   Ready to buy: {len(excellent_deals + good_deals)}")
        
        if excellent_deals or good_deals:
            print(f"\n💡 RECOMMENDED ACTION:")
            if excellent_deals:
                print(f"   🎯 Priority: Buy {len(excellent_deals)} excellent deals (≥5% below adjusted TREND)")
            if good_deals:
                print(f"   🟡 Consider: {len(good_deals)} good deals (below adjusted TREND)")
            print(f"   Prices account for 20% EX+/NM condition premium over all-condition TREND")
        else:
            print(f"\n💡 RECOMMENDED ACTION:")
            print(f"   No good EX+/NM deals found right now")
            print(f"   All current EX+ prices are above adjusted market trend")
            print(f"   Try again later when prices drop")
        
        # Save results to files
        if save_results:
            json_file = self._save_results_to_files(excellent_deals, good_deals, expensive_deals, no_data,
                                                     run_type=run_type, run_param=run_param, wishlist_file=wishlist_file)
            
            # Run seller analysis if available
            if json_file and SELLER_ANALYSIS_AVAILABLE:
                self._run_seller_analysis(json_file)
    
    def _run_seller_analysis(self, json_file: str, threshold: float = 7.0) -> None:
        """Run seller analysis on the results and generate website."""
        try:
            print(f"\n🏪 STEP 5: Seller Analysis")
            print("=" * 50)
            
            # Load the JSON data
            with open(json_file, 'r') as f:
                results = json.load(f)
            
            # Analyze deals
            seller_deals = analyze_deals(results, threshold)
            
            if not seller_deals:
                print(f"⚠️  No seller deals found (≥{threshold}% below avg of #2-5)")
                return
            
            # Sort by number of deals
            sorted_seller_deals = dict(sorted(
                seller_deals.items(),
                key=lambda x: len(x[1]['deals']),
                reverse=True
            ))
            
            # Count deals
            total_deals = sum(len(data['deals']) for data in sorted_seller_deals.values())
            multi_deal_sellers = sum(1 for data in sorted_seller_deals.values() if len(data['deals']) >= 2)
            
            print(f"✅ Found {total_deals} deals from {len(sorted_seller_deals)} sellers")
            print(f"   {multi_deal_sellers} sellers with multiple deals")
            
            # Generate HTML website with both good deals and rejected cards
            base_name = os.path.splitext(json_file)[0]
            seller_html = f"{base_name}.html"
            
            # Generate combined HTML with tabs for good deals and rejected cards
            try:
                from analyze_sellers_combined import generate_html_with_rejected
                generate_html_with_rejected(sorted_seller_deals, results, threshold, seller_html)
                print(f"🌐 Website: {seller_html}")
                print(f"   📊 Includes both good deals and rejected cards in tabs")
            except Exception as e:
                # Fallback to original if new function fails
                print(f"⚠️  Using fallback HTML (combined view failed: {e})")
                generate_seller_html(sorted_seller_deals, threshold, seller_html)
                print(f"🌐 Website: {seller_html}")
            
            print(f"   Open in browser: file://{os.path.abspath(seller_html)}")
            webbrowser.open(f"file://{os.path.abspath(seller_html)}")
            
        except Exception as e:
            print(f"⚠️  Error in seller analysis: {e}")
    
    def _print_deal_summary(self, result: Dict, emoji: str) -> None:
        """Print a summary of a single deal."""
        card_data = result['card_data']
        live_analysis = result['live_analysis']
        
        card_name = card_data.get('name', 'Unknown')
        expansion = card_data.get('expansionName', 'Unknown')
        avg30 = card_data.get('AVG30', 0)
        
        cheapest_good = live_analysis['cheapest_good_condition']
        good_details = live_analysis['cheapest_good_condition_details']
        
        diff_pct = (cheapest_good - avg30) / avg30 * 100 if avg30 > 0 else 0
        
        print(f"   {emoji} {card_name} ({expansion})")
        print(f"      EX+ Price: €{cheapest_good:.2f} ({good_details['condition']}) - {good_details['seller']}")
        print(f"      vs AVG30: {diff_pct:+.1f}% (€{avg30:.2f})")
    
    def _save_results_to_files(self, excellent_deals: List, good_deals: List, expensive_deals: List, no_data: List, 
                               run_type: str = 'candidates', run_param: int = 0, wishlist_file: str = '') -> str:
        """Save results to various file formats.
        
        Returns:
            Path to the main JSON file for seller analysis
        """
        try:
            # Create results directory
            os.makedirs('results', exist_ok=True)
            
            # Generate timestamp for filenames
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            # Generate descriptive base filename
            if run_type == 'wishlist_reservedlist':
                base_name = f"wishlist_reservedlist_{timestamp}"
            elif run_type == 'wishlist':
                # Extract filename without extension
                wishlist_name = os.path.splitext(os.path.basename(wishlist_file))[0] if wishlist_file else 'wishlist'
                base_name = f"{wishlist_name}_{timestamp}"
            elif run_type == 'both':
                base_name = f"combined_wishlist_candidates_{timestamp}"
            else:  # candidates
                if run_param is None or run_param == 0:
                    base_name = f"all_candidates_{timestamp}"
                else:
                    base_name = f"top{run_param}_candidates_{timestamp}"
            
            # Prepare data for different formats
            all_deals = excellent_deals + good_deals + expensive_deals
            
            # 1. Save detailed JSON results
            json_data = {
                'timestamp': timestamp,
                'run_type': run_type,
                'run_param': run_param,
                'summary': {
                    'total_analyzed': len(self.results),
                    'excellent_deals': len(excellent_deals),
                    'good_deals': len(good_deals),
                    'expensive_deals': len(expensive_deals),
                    'no_data': len(no_data)
                },
                'excellent_deals': [self._format_deal_for_json(result) for result in excellent_deals],
                'good_deals': [self._format_deal_for_json(result) for result in good_deals],
                'expensive_deals': [self._format_deal_for_json(result) for result in expensive_deals],
                'no_data': [self._format_deal_for_json(result) for result in no_data],
                'all_results': [self._format_deal_for_json(result) for result in self.results]
            }
            
            json_file = f"results/{base_name}.json"
            with open(json_file, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=2, ensure_ascii=False)
            print(f"\n💾 Data saved to: {json_file}")
            
            return json_file
            
        except Exception as e:
            print(f"⚠️  Error saving results: {e}")
            return None
    
    def _format_deal_for_json(self, result: Dict) -> Dict:
        """Format a deal result for JSON export."""
        card_data = result['card_data']
        live_analysis = result.get('live_analysis')
        
        formatted = {
            'rank': result['rank'],
            'card_name': card_data.get('name', 'Unknown'),
            'expansion': card_data.get('expansionName', 'Unknown'),
            'card_id': card_data.get('idProduct'),
            'source': getattr(self, 'source_label', 'Unknown'),
            'historical_data': {
                'avg7': card_data.get('AVG7', 0),
                'avg30': card_data.get('AVG30', 0),
                'trend': card_data.get('TREND', 0),
                'real_discount': card_data.get('real_discount', 0)
            }
        }
        
        if live_analysis:
            formatted['live_data'] = {
                'total_listings': live_analysis.get('total_listings', 0),
                'available_items_total': live_analysis.get('available_items_total'),  # Liquidity indicator
                'cheapest_current': live_analysis.get('cheapest_current', 0),
                'average_current': live_analysis.get('average_current', 0),
                'cheapest_good_condition': live_analysis.get('cheapest_good_condition'),
                'cheapest_good_condition_details': live_analysis.get('cheapest_good_condition_details'),
                'top_6_sellers': live_analysis.get('top_6_sellers', []),
                'good_condition_vs_avg7_pct': live_analysis.get('good_condition_vs_avg7_pct'),
                'good_condition_vs_trend_pct': live_analysis.get('good_condition_vs_trend_pct'),
                'url': live_analysis.get('url')
            }
        else:
            formatted['live_data'] = None
        
        return formatted
    
    def _create_deals_dataframe(self, deals: List, deal_type: str) -> pd.DataFrame:
        """Create a DataFrame from deals for CSV export."""
        rows = []
        
        for result in deals:
            card_data = result['card_data']
            live_analysis = result.get('live_analysis')
            
            row = {
                'Rank': result['rank'],
                'Card_Name': card_data.get('name', 'Unknown'),
                'Expansion': card_data.get('expansionName', 'Unknown'),
                'Card_ID': card_data.get('idProduct'),
                'Historical_AVG7': card_data.get('AVG7', 0),
                'Historical_AVG30': card_data.get('AVG30', 0),
                'Historical_TREND': card_data.get('TREND', 0),
                'Historical_Discount_Pct': card_data.get('real_discount', 0) * 100
            }
            
            if live_analysis:
                good_details = live_analysis.get('cheapest_good_condition_details')
                row.update({
                    'Current_Cheapest': live_analysis.get('cheapest_current', 0),
                    'Current_Average': live_analysis.get('average_current', 0),
                    'EX_Plus_Price': live_analysis.get('cheapest_good_condition', 0),
                    'EX_Plus_Condition': good_details['condition'] if good_details else '',
                    'EX_Plus_Seller': good_details['seller'] if good_details else '',
                    'EX_Plus_Quantity': good_details['quantity'] if good_details else 1,
                    'EX_Plus_vs_AVG7_Pct': live_analysis.get('good_condition_vs_avg7_pct', 0),
                    'EX_Plus_vs_TREND_Pct': live_analysis.get('good_condition_vs_trend_pct', 0),
                    'Total_Listings': live_analysis.get('total_listings', 0),
                    'Available_Items_Total': live_analysis.get('available_items_total'),  # Liquidity
                    'Cardmarket_URL': live_analysis.get('url', '')
                })
            else:
                row.update({
                    'Current_Cheapest': 0,
                    'Current_Average': 0,
                    'EX_Plus_Price': 0,
                    'EX_Plus_Condition': '',
                    'EX_Plus_Seller': '',
                    'EX_Plus_Quantity': 0,
                    'EX_Plus_vs_AVG7_Pct': 0,
                    'EX_Plus_vs_TREND_Pct': 0,
                    'Total_Listings': 0,
                    'Available_Items_Total': None,  # Liquidity
                    'Cardmarket_URL': ''
                })
            
            rows.append(row)
        
        return pd.DataFrame(rows)
    
    def _save_text_summary(self, filename: str, excellent_deals: List, good_deals: List, expensive_deals: List, no_data: List) -> None:
        """Save a human-readable text summary."""
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("🃏 MTG ARBITRAGE RESULTS SUMMARY\n")
            f.write("=" * 50 + "\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            f.write(f"📊 OVERVIEW:\n")
            f.write(f"   Total candidates analyzed: {len(self.results)}\n")
            f.write(f"   Excellent deals found: {len(excellent_deals)}\n")
            f.write(f"   Fair deals found: {len(good_deals)}\n")
            f.write(f"   Expensive deals: {len(expensive_deals)}\n")
            f.write(f"   No live data: {len(no_data)}\n\n")
            
            if excellent_deals:
                f.write("🎉 EXCELLENT DEALS (≤15% vs AVG30):\n")
                f.write("-" * 40 + "\n")
                for result in excellent_deals:
                    card_data = result['card_data']
                    live_analysis = result['live_analysis']
                    
                    card_name = card_data.get('name', 'Unknown')
                    expansion = card_data.get('expansionName', 'Unknown')
                    avg30 = card_data.get('AVG30', 0)
                    
                    cheapest_good = live_analysis['cheapest_good_condition']
                    good_details = live_analysis['cheapest_good_condition_details']
                    diff_pct = (cheapest_good - avg30) / avg30 * 100 if avg30 > 0 else 0
                    
                    f.write(f"\n• {card_name} ({expansion})\n")
                    f.write(f"  EX+ Price: €{cheapest_good:.2f} ({good_details['condition']}) - {good_details['seller']}\n")
                    f.write(f"  vs AVG30: {diff_pct:+.1f}% (€{avg30:.2f})\n")
                    # Handle dynamic URL labels based on configuration
                    primary_url = live_analysis.get('url', '')
                    alt_url = live_analysis.get('url_german', '') or live_analysis.get('url_all_sellers', '')
                    
                    f.write(f"  Primary URL: {primary_url}\n")
                    if alt_url:
                        alt_label = "German Only" if 'url_german' in live_analysis else "All Sellers"
                        f.write(f"  Alternative URL ({alt_label}): {alt_url}\n")
                
                f.write("\n")
            
            if good_deals:
                f.write("🟡 FAIR DEALS (15-30% vs AVG30):\n")
                f.write("-" * 40 + "\n")
                for result in good_deals:
                    card_data = result['card_data']
                    live_analysis = result['live_analysis']
                    
                    card_name = card_data.get('name', 'Unknown')
                    expansion = card_data.get('expansionName', 'Unknown')
                    avg30 = card_data.get('AVG30', 0)
                    
                    cheapest_good = live_analysis['cheapest_good_condition']
                    good_details = live_analysis['cheapest_good_condition_details']
                    diff_pct = (cheapest_good - avg30) / avg30 * 100 if avg30 > 0 else 0
                    
                    f.write(f"\n• {card_name} ({expansion})\n")
                    f.write(f"  EX+ Price: €{cheapest_good:.2f} ({good_details['condition']}) - {good_details['seller']}\n")
                    f.write(f"  vs AVG30: {diff_pct:+.1f}% (€{avg30:.2f})\n")
                    # Handle dynamic URL labels based on configuration
                    primary_url = live_analysis.get('url', '')
                    alt_url = live_analysis.get('url_german', '') or live_analysis.get('url_all_sellers', '')
                    
                    f.write(f"  Primary URL: {primary_url}\n")
                    if alt_url:
                        alt_label = "German Only" if 'url_german' in live_analysis else "All Sellers"
                        f.write(f"  Alternative URL ({alt_label}): {alt_url}\n")
                
                f.write("\n")
            
            f.write("💡 USAGE NOTES:\n")
            f.write("- Excellent deals are ready to buy at near-historical prices\n")
            f.write("- Fair deals may be worth considering depending on your strategy\n")
            f.write("- Check URLs for current availability and shipping costs\n")
            f.write("- Prices may change quickly - verify before purchasing\n")
    
    def run_complete_pipeline(self, 
                            candidates_limit: int = 10,
                            live_check_limit: int = 5,
                            force_download: bool = False,
                            use_wishlist: bool = False,
                            use_both: bool = False,
                            wishlist_file: str = 'wishlist.json') -> bool:
        """
        Run the complete pipeline.
        
        Args:
            candidates_limit: Maximum candidates to find
            live_check_limit: Maximum candidates to check live prices for
            force_download: Force download fresh data
            use_wishlist: Use wishlist mode
            use_both: Use both wishlist and candidates
            wishlist_file: Path to wishlist file
            
        Returns:
            True if successful, False otherwise
        """
        print("🃏 MTG ARBITRAGE - COMPLETE PIPELINE")
        print("=" * 60)
        print(f"⏰ Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print()
        
        # Determine run type for filename and source label
        if 'wishlist_reservedlist' in wishlist_file:
            run_type = 'wishlist_reservedlist'
            source_label = 'Reserved List'
        elif 'wishlist_deck' in wishlist_file:
            run_type = 'wishlist_deck'
            source_label = 'Deck Wishlist'
        elif use_both:
            run_type = 'both'
            source_label = 'Wishlist + Candidates'
        elif use_wishlist:
            run_type = 'wishlist'
            source_label = 'Wishlist'
        else:
            run_type = 'candidates'
            source_label = 'Price Candidates'
        
        # Store source for results
        self.source_label = source_label
        
        # Step 1: Load data
        if not self.step1_load_data(force_download=force_download):
            return False
        
        # Step 2: Find candidates
        if not self.step2_find_candidates(
            limit=candidates_limit, 
            use_wishlist=use_wishlist,
            use_both=use_both,
            wishlist_file=wishlist_file
        ):
            return False
        
        # Step 3: Check live prices
        if not self.step3_check_live_prices(max_candidates=live_check_limit):
            print("⚠️  Live price checking failed, showing candidates only")
        
        # Step 4: Show results (includes seller analysis)
        self.step4_show_results(
            run_type=run_type, 
            run_param=candidates_limit,
            wishlist_file=wishlist_file
        )
        
        print(f"\n⏰ Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        return True


def main():
    """Main function with command line interface."""
    parser = argparse.ArgumentParser(
        description="MTG Arbitrage - Find profitable Magic cards",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py                    # Default: Run all 4 analyses (wishlist, reserved, deck, candidates)
  python main.py --wishlist-only    # Only check wishlist.json
  python main.py --reservedlist-only # Only check wishlist_reservedlist.json
  python main.py --deck-only        # Only check wishlist_deck.json
  python main.py --candidates-only  # Only check general candidates
  python main.py --no-candidates    # Run all wishlists but skip candidates
  python main.py --refresh          # Force download fresh data
  python main.py --web-ui           # Start web UI binder interface instead of HTML
  python web_ui.py                  # Start web UI standalone (view existing results)
        """
    )
    
    parser.add_argument(
        '--no-live', 
        action='store_true',
        help='Skip live price checking, show candidates only'
    )
    
    parser.add_argument(
        '--refresh', 
        action='store_true',
        help='Force download fresh price guide data'
    )
    
    parser.add_argument(
        '--wishlist-only',
        action='store_true',
        help='Only analyze wishlist.json'
    )
    
    parser.add_argument(
        '--wishlist-file',
        type=str,
        default='wishlist.json',
        help='Path to wishlist JSON file (default: wishlist.json)'
    )
    
    parser.add_argument(
        '--reservedlist-only',
        action='store_true',
        help='Only analyze wishlist_reservedlist.json'
    )
    
    parser.add_argument(
        '--deck-only',
        action='store_true',
        help='Only analyze wishlist_deck.json'
    )
    
    parser.add_argument(
        '--candidates-only',
        action='store_true',
        help='Only analyze general candidates (no wishlist)'
    )
    
    parser.add_argument(
        '--no-candidates',
        action='store_true',
        help='Run all wishlists (wishlist, reserved, deck) but skip candidates'
    )
    
    parser.add_argument(
        '--candidates-limit',
        type=int,
        default=None,
        help='Limit number of candidates to analyze (default: all)'
    )
    
    parser.add_argument(
        '--web-ui',
        action='store_true',
        help='Start web UI instead of generating HTML files'
    )
    
    args = parser.parse_args()
    
    # Determine what to run
    run_all = not (args.wishlist_only or args.reservedlist_only or args.deck_only or args.candidates_only or args.no_candidates)
    
    if run_all:
        # Default: Run all 4 analyses
        print("🎯 Running complete analysis suite: Wishlist → Reserved List → Deck → Candidates")
        print("=" * 80)
    elif args.no_candidates:
        # Run wishlists only (no candidates)
        print("🎯 Running wishlist analyses: Wishlist → Reserved List → Deck (skipping candidates)")
        print("=" * 80)
    
    if run_all or args.no_candidates:
        
        # Clear cache if refreshing data
        if args.refresh:
            try:
                from mtg_arbitrage.price_cache import clear_global_cache
                clear_global_cache()
                print("🗑️  Cleared price cache (fresh data requested)")
            except Exception:
                pass
        
        success_count = 0
        json_files = []
        
        # 1. Wishlist
        if os.path.exists('wishlist.json'):
            print("\n" + "=" * 80)
            print("🎯 ANALYSIS 1/4: WISHLIST")
            print("=" * 80)
            pipeline1 = MTGArbitragePipeline()
            if pipeline1.run_complete_pipeline(
                candidates_limit=None,  # All cards
                live_check_limit=0 if args.no_live else 999999,
                force_download=args.refresh,
                use_wishlist=True,
                use_both=False,
                wishlist_file='wishlist.json'
            ):
                success_count += 1
                # Find the generated JSON (exclude reservedlist files)
                import glob
                wishlist_files = [f for f in glob.glob('results/wishlist_*.json') if 'reservedlist' not in f and 'deck' not in f]
                latest_wishlist = max(wishlist_files, key=os.path.getctime, default=None) if wishlist_files else None
                if latest_wishlist:
                    json_files.append(('Wishlist', latest_wishlist))
        else:
            print("\n⚠️  wishlist.json not found, skipping")
        
        # 2. Reserved List Wishlist
        if os.path.exists('wishlist_reservedlist.json'):
            print("\n" + "=" * 80)
            print("🎯 ANALYSIS 2/4: RESERVED LIST WISHLIST")
            print("=" * 80)
            pipeline2 = MTGArbitragePipeline()
            if pipeline2.run_complete_pipeline(
                candidates_limit=None,  # All cards
                live_check_limit=0 if args.no_live else 999999,
                force_download=False,  # Don't re-download
                use_wishlist=True,
                use_both=False,
                wishlist_file='wishlist_reservedlist.json'
            ):
                success_count += 1
                import glob
                latest_reserved = max(glob.glob('results/wishlist_reservedlist_*.json'), key=os.path.getctime, default=None)
                if latest_reserved:
                    json_files.append(('Reserved List', latest_reserved))
        else:
            print("\n⚠️  wishlist_reservedlist.json not found, skipping")
        
        # 3. Deck Wishlist
        if os.path.exists('wishlist_deck.json'):
            print("\n" + "=" * 80)
            print("🎯 ANALYSIS 3/4: DECK WISHLIST")
            print("=" * 80)
            pipeline3 = MTGArbitragePipeline()
            if pipeline3.run_complete_pipeline(
                candidates_limit=None,  # All cards
                live_check_limit=0 if args.no_live else 999999,
                force_download=False,  # Don't re-download
                use_wishlist=True,
                use_both=False,
                wishlist_file='wishlist_deck.json'
            ):
                success_count += 1
                import glob
                latest_deck = max(glob.glob('results/wishlist_deck_*.json'), key=os.path.getctime, default=None)
                if latest_deck:
                    json_files.append(('Deck', latest_deck))
        else:
            print("\n⚠️  wishlist_deck.json not found, skipping")
        
        # 4. General Candidates (only if run_all, not if --no-candidates)
        if run_all:
            print("\n" + "=" * 80)
            print("🎯 ANALYSIS 4/4: GENERAL CANDIDATES")
            print("=" * 80)
            pipeline4 = MTGArbitragePipeline()
            if pipeline4.run_complete_pipeline(
                candidates_limit=args.candidates_limit,
                live_check_limit=0 if args.no_live else (args.candidates_limit or 999999),
                force_download=False,  # Don't re-download
                use_wishlist=False,
                use_both=False,
                wishlist_file=''
            ):
                success_count += 1
                import glob
                candidates_files = glob.glob('results/*_candidates_*.json')
                latest_candidates = max(candidates_files, key=os.path.getctime, default=None) if candidates_files else None
                if latest_candidates:
                    json_files.append(('Candidates', latest_candidates))
        
        print("\n" + "=" * 80)
        total_analyses = 4 if run_all else 3
        print(f"✅ Completed {success_count}/{total_analyses} analyses")
        
        # Print cache statistics
        try:
            from mtg_arbitrage.price_cache import get_global_cache
            cache = get_global_cache()
            cache.print_stats()
        except Exception as e:
            pass  # Silently fail if cache not available
        
        # Generate combined website from all sources or start web UI
        if args.web_ui:
            print("\n🌐 Starting Web UI (FastAPI)...")
            try:
                import uvicorn
                from web_ui import DEFAULT_PORT
                print(f"   📊 Open http://localhost:{DEFAULT_PORT} in your browser")
                print("   Press Ctrl+C to stop the server")
                uvicorn.run("web_ui:app", host="0.0.0.0", port=DEFAULT_PORT, log_level="info", reload=True)
            except Exception as e:
                print(f"⚠️  Could not start web UI: {e}")
                print("   Falling back to HTML generation...")
                args.web_ui = False  # Fallback to HTML
        
        if not args.web_ui and json_files and SELLER_ANALYSIS_AVAILABLE:
            print("\n🌐 Generating combined website...")
            try:
                from analyze_sellers import generate_combined_html
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                combined_html = f"results/combined_{timestamp}.html"
                generate_combined_html(json_files, combined_html)
                print(f"✅ Combined HTML: {combined_html}")
                print(f"   📊 View all deals: file://{os.path.abspath(combined_html)}")
                webbrowser.open(f"file://{os.path.abspath(combined_html)}")
            except Exception as e:
                print(f"⚠️  Could not generate combined website: {e}")
        
        print("=" * 80)
        return 0 if success_count > 0 else 1
    
    else:
        # Run single analysis
        pipeline = MTGArbitragePipeline()
        
        if args.wishlist_only:
            use_wishlist = True
            wishlist_file = args.wishlist_file
        elif args.reservedlist_only:
            use_wishlist = True
            wishlist_file = 'wishlist_reservedlist.json'
        elif args.deck_only:
            use_wishlist = True
            wishlist_file = 'wishlist_deck.json'
        else:  # candidates_only
            use_wishlist = False
            wishlist_file = ''
        
        success = pipeline.run_complete_pipeline(
            candidates_limit=args.candidates_limit,
            live_check_limit=0 if args.no_live else (args.candidates_limit or 999999),
            force_download=args.refresh,
            use_wishlist=use_wishlist,
            use_both=False,
            wishlist_file=wishlist_file
        )
        
        # Start web UI if requested
        if args.web_ui:
            print("\n🌐 Starting Web UI (FastAPI)...")
            try:
                import uvicorn
                from web_ui import DEFAULT_PORT
                print(f"   📊 Open http://localhost:{DEFAULT_PORT} in your browser")
                print("   Press Ctrl+C to stop the server")
                uvicorn.run("web_ui:app", host="0.0.0.0", port=DEFAULT_PORT, log_level="info", reload=True)
            except Exception as e:
                print(f"⚠️  Could not start web UI: {e}")
        
        return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
