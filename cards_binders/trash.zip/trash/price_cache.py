"""
Global price cache to avoid re-scraping the same cards across multiple pipelines.
"""

import json
import os
from datetime import datetime
from typing import Optional, Dict, Any


class PriceCache:
    """Thread-safe price cache for avoiding duplicate scraping."""
    
    def __init__(self, cache_file: str = None):
        """
        Initialize price cache.
        
        Args:
            cache_file: Optional path to cache file (auto-generated if None)
        """
        if cache_file is None:
            cache_file = f"data/.price_cache_{datetime.now().strftime('%Y%m%d')}.json"
        
        self.cache_file = cache_file
        self.cache = {}
        self.hits = 0
        self.misses = 0
        
        # Try to load existing cache
        self._load_cache()
    
    def _load_cache(self):
        """Load cache from file if it exists."""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    data = json.load(f)
                    self.cache = data.get('cache', {})
                    print(f"📦 Loaded price cache with {len(self.cache)} entries")
            except Exception as e:
                print(f"⚠️  Could not load price cache: {e}")
                self.cache = {}
    
    def _save_cache(self):
        """Save cache to file."""
        try:
            os.makedirs(os.path.dirname(self.cache_file) or '.', exist_ok=True)
            with open(self.cache_file, 'w') as f:
                json.dump({
                    'cache': self.cache,
                    'timestamp': datetime.now().isoformat(),
                    'stats': {
                        'hits': self.hits,
                        'misses': self.misses,
                        'total_entries': len(self.cache)
                    }
                }, f, indent=2)
        except Exception as e:
            print(f"⚠️  Could not save price cache: {e}")
    
    def _make_key(self, card_id: int, expansion_name: str = None) -> str:
        """
        Create cache key from card ID and expansion.
        
        Args:
            card_id: Card product ID
            expansion_name: Expansion/set name (optional)
        
        Returns:
            Cache key string
        """
        if expansion_name and str(expansion_name) != 'nan':
            return f"{card_id}_{expansion_name}"
        return str(card_id)
    
    def get(self, card_id: int, expansion_name: str = None) -> Optional[Dict[str, Any]]:
        """
        Get cached price data for a card.
        
        Args:
            card_id: Card product ID
            expansion_name: Expansion/set name (optional)
        
        Returns:
            Cached live analysis dict or None if not found
        """
        key = self._make_key(card_id, expansion_name)
        
        if key in self.cache:
            self.hits += 1
            return self.cache[key]
        
        self.misses += 1
        return None
    
    def set(self, card_id: int, live_analysis: Dict[str, Any], expansion_name: str = None):
        """
        Store price data in cache.
        
        Args:
            card_id: Card product ID
            live_analysis: Live analysis data to cache
            expansion_name: Expansion/set name (optional)
        """
        key = self._make_key(card_id, expansion_name)
        self.cache[key] = live_analysis
        
        # Auto-save after every update (ensures persistence)
        self._save_cache()
    
    def has(self, card_id: int, expansion_name: str = None) -> bool:
        """
        Check if card is in cache.
        
        Args:
            card_id: Card product ID
            expansion_name: Expansion/set name (optional)
        
        Returns:
            True if card is cached
        """
        key = self._make_key(card_id, expansion_name)
        return key in self.cache
    
    def clear(self):
        """Clear all cached data."""
        self.cache = {}
        self.hits = 0
        self.misses = 0
        self._save_cache()
    
    def stats(self) -> Dict[str, int]:
        """
        Get cache statistics.
        
        Returns:
            Dict with hits, misses, and total entries
        """
        return {
            'hits': self.hits,
            'misses': self.misses,
            'total_entries': len(self.cache),
            'hit_rate': self.hits / (self.hits + self.misses) * 100 if (self.hits + self.misses) > 0 else 0
        }
    
    def print_stats(self):
        """Print cache statistics."""
        stats = self.stats()
        print(f"\n📊 Price Cache Statistics:")
        print(f"   Cache hits: {stats['hits']}")
        print(f"   Cache misses: {stats['misses']}")
        print(f"   Hit rate: {stats['hit_rate']:.1f}%")
        print(f"   Total cached: {stats['total_entries']} cards")


# Global cache instance
_global_cache = None


def get_global_cache() -> PriceCache:
    """Get or create the global price cache instance."""
    global _global_cache
    if _global_cache is None:
        _global_cache = PriceCache()
    return _global_cache


def clear_global_cache():
    """Clear the global price cache."""
    global _global_cache
    if _global_cache is not None:
        _global_cache.clear()
        _global_cache = None

