#!/usr/bin/env python3
"""Test script to debug cards with special characters (accents, apostrophes)."""

import sys
import unicodedata
from fetch_live_listings_simple import SimpleBrowserScraper

def normalize_text(text):
    """Remove accents from text."""
    # Normalize to NFD (decomposed form) then remove combining characters
    nfd = unicodedata.normalize('NFD', text)
    ascii_text = ''.join(char for char in nfd if not unicodedata.combining(char))
    return ascii_text

def test_card(card_name, expansion, test_urls):
    """Test different URL formats for Ifh-Bíff Efreet."""
    
    card_name = "Ifh-Bíff Efreet"
    expansion = "Arabian Nights"
    
    print(f"🎯 Testing: {card_name} from {expansion}")
    print(f"   Original name: {repr(card_name)}")
    print(f"   Normalized (no accents): {repr(normalize_text(card_name))}\n")
    
    # Test different URL formats
    test_urls = [
        # Original with accents
        "https://www.cardmarket.com/en/Magic/Products/Singles/Arabian-Nights/Ifh-Bíff-Efreet?language=1&minCondition=3",
        
        # Without accents
        "https://www.cardmarket.com/en/Magic/Products/Singles/Arabian-Nights/Ifh-Biff-Efreet?language=1&minCondition=3",
        
        # All lowercase without accents
        "https://www.cardmarket.com/en/Magic/Products/Singles/Arabian-Nights/ifh-biff-efreet?language=1&minCondition=3",
        
        # With V-1 suffix (no accents)
        "https://www.cardmarket.com/en/Magic/Products/Singles/Arabian-Nights/Ifh-Biff-Efreet-V-1?language=1&minCondition=3",
        
        # Search by name
        "https://www.cardmarket.com/en/Magic/Products/Search?searchString=Ifh-Biff+Efreet&language=1&minCondition=3",
    ]
    
    scraper = SimpleBrowserScraper(delay_range=(2.0, 3.0), max_retries=1)
    
    for i, url in enumerate(test_urls, 1):
        print(f"\n{'='*70}")
        print(f"Test {i}/{len(test_urls)}: {url.split('/Singles/')[-1].split('?')[0] if '/Singles/' in url else 'Search'}")
        print(f"{'='*70}")
        
        listings = scraper.fetch_listings(url, max_listings=5)
        
        if listings:
            print(f"✅ SUCCESS! Found {len(listings)} listings")
            for j, listing in enumerate(listings[:3], 1):
                print(f"   {j}. €{listing.price:.2f} - {listing.condition} - {listing.seller}")
            return url  # Return successful URL
        else:
            print(f"❌ Failed")
    
    print(f"\n{'='*70}")
    print("❌ All URL formats failed")
    print("💡 The card might need manual verification on CardMarket")
    return None

if __name__ == "__main__":
    successful_url = test_ifh_biff()
    if successful_url:
        print(f"\n✅ Working URL: {successful_url}")
