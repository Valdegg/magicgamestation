#!/usr/bin/env python3
"""
Debug script to see exactly what HTML text is being extracted and parsed.
"""

import requests
import re
from bs4 import BeautifulSoup
from mtg_arbitrage.utils import get_cardmarket_url


def debug_html_extraction():
    """Debug the exact HTML content and text extraction."""
    print("🔍 DEBUGGING HTML PRICE EXTRACTION")
    print("=" * 60)
    
    # Get the URL
    url = get_cardmarket_url(12345, "Demonic Tutor", "Alpha", 'direct')
    print(f"URL: {url}")
    
    # Make request with same headers as scraper
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=30)
        if response.status_code != 200:
            print(f"❌ Request failed: {response.status_code}")
            return
        
        print(f"✅ Got response: {len(response.text)} characters")
        
        # Parse HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Look for article rows (same as scraper)
        article_rows = soup.find_all('article', class_='row')
        print(f"\n📋 Found {len(article_rows)} article rows")
        
        # Debug first few rows
        for i, row in enumerate(article_rows[:5]):
            print(f"\n🔍 ROW {i+1} ANALYSIS:")
            print("-" * 30)
            
            # Get full row text
            row_text = row.get_text(' ', strip=True)
            print(f"Full text: {row_text[:200]}...")
            
            # Look for price patterns
            price_patterns = [
                r'€\s*(\d{1,3}(?:\.\d{3})*,\d{2})',          # €1.234,56
                r'(\d{1,3}(?:\.\d{3})*,\d{2})\s*€',          # 1.234,56 €
                r'€\s*(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)',     # €1.234 or €1.234,56
                r'(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*€',     # 1.234 € or 1.234,56 €
                r'€\s*(\d+[.,]\d+)',
                r'(\d+[.,]\d+)\s*€'
            ]
            
            found_prices = []
            for j, pattern in enumerate(price_patterns):
                matches = re.findall(pattern, row_text)
                if matches:
                    for match in matches:
                        # Convert to float
                        price_str = match
                        if '.' in price_str and ',' in price_str:
                            # European format
                            converted = price_str.replace('.', '').replace(',', '.')
                        elif ',' in price_str:
                            converted = price_str.replace(',', '.')
                        else:
                            converted = price_str
                        
                        try:
                            price_float = float(converted)
                            found_prices.append((f"Pattern {j+1}", match, price_float))
                        except:
                            pass
            
            if found_prices:
                print("Found prices:")
                for pattern_name, original, converted in found_prices:
                    print(f"  {pattern_name}: '{original}' → €{converted:.2f}")
                
                # Show which one would be selected (first match)
                selected = found_prices[0]
                print(f"  → SELECTED: €{selected[2]:.2f}")
            else:
                print("❌ No prices found")
            
            # Look for specific price elements
            price_elements = row.find_all(text=re.compile(r'\d+[.,]\d+'))
            if price_elements:
                print("Price-like text elements:")
                for elem in price_elements[:3]:  # Show first 3
                    print(f"  '{elem.strip()}'")
                    
        print(f"\n💡 ANALYSIS:")
        print("If the scraper is finding €200 instead of €1200,")
        print("it might be picking up a different price element")
        print("or the HTML structure changed.")
            
    except Exception as e:
        print(f"❌ Error: {e}")


if __name__ == "__main__":
    debug_html_extraction()
