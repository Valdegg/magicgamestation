#!/usr/bin/env python3
"""
Debug script to investigate where the suspicious €200 Demonic Tutor price came from.
Uses the same scraping code as the main pipeline.
"""

from fetch_live_listings_simple import SimpleBrowserScraper
from mtg_arbitrage.utils import get_cardmarket_url
import time
import json


def debug_demonic_tutor_parsing():
    """Debug the exact parsing of Demonic Tutor to find the €200 price source."""
    print("🔍 DEBUGGING DEMONIC TUTOR PRICE PARSING")
    print("=" * 60)
    
    scraper = SimpleBrowserScraper()
    
    # Test both Alpha and Beta versions
    test_cards = [
        ("Demonic Tutor", "Alpha"),
        ("Demonic Tutor", "Beta")
    ]
    
    for name, expansion in test_cards:
        print(f"\n🧪 TESTING: {name} ({expansion})")
        print("-" * 40)
        
        # Generate URL
        url = get_cardmarket_url(12345, name, expansion, 'direct')
        print(f"URL: {url}")
        
        # Fetch with detailed logging
        print("\n📡 Making request...")
        
        # Temporarily disable price validation to see ALL prices
        original_method = scraper._is_price_reasonable
        scraper._is_price_reasonable = lambda listing, url: True
        
        try:
            listings = scraper.fetch_listings(url, max_listings=20)
            
            print(f"\n📋 FOUND {len(listings)} TOTAL LISTINGS:")
            print("=" * 50)
            
            for i, listing in enumerate(listings, 1):
                price_flag = ""
                if listing.price < 150:  # Flag suspiciously low prices
                    price_flag = " ⚠️  SUSPICIOUS"
                elif listing.price < 300:
                    price_flag = " 🟡 LOW"
                
                print(f"{i:2d}. €{listing.price:>8.2f} - {listing.condition:>2s} - {listing.seller:<20s}{price_flag}")
            
            # Analyze price distribution
            if listings:
                prices = [l.price for l in listings]
                print(f"\n📊 PRICE ANALYSIS:")
                print(f"   Lowest:  €{min(prices):.2f}")
                print(f"   Highest: €{max(prices):.2f}")
                print(f"   Average: €{sum(prices)/len(prices):.2f}")
                
                # Find EX+ listings
                ex_plus = [l for l in listings if l.condition in ['EX', 'NM', 'MT']]
                if ex_plus:
                    ex_prices = [l.price for l in ex_plus]
                    cheapest_ex = min(ex_plus, key=lambda x: x.price)
                    print(f"   Cheapest EX+: €{cheapest_ex.price:.2f} ({cheapest_ex.condition}) - {cheapest_ex.seller}")
                    
                    # This is what would be reported in main pipeline
                    print(f"\n🎯 MAIN PIPELINE WOULD REPORT:")
                    print(f"   Best EX+: €{cheapest_ex.price:.2f} ({cheapest_ex.condition}) - {cheapest_ex.seller}")
                    
                    if cheapest_ex.price < 150:
                        print(f"   🚨 THIS IS THE SUSPICIOUS PRICE!")
                        
                        # Try to understand why this price exists
                        print(f"\n🔍 INVESTIGATING SUSPICIOUS LISTING:")
                        print(f"   Seller: {cheapest_ex.seller}")
                        print(f"   Condition: {cheapest_ex.condition}")
                        print(f"   Price: €{cheapest_ex.price:.2f}")
                        
                        # Check if it might be a different card variant
                        if cheapest_ex.price < 50:
                            print(f"   💡 Possible causes:")
                            print(f"      - Wrong card variant (Revised/4th Edition instead of Alpha/Beta)")
                            print(f"      - Damaged/Poor condition not filtered by minCondition=3")
                            print(f"      - Parsing error (grabbed wrong price element)")
                            print(f"      - Fake/error listing on Cardmarket")
            else:
                print("❌ No listings found")
                
        except Exception as e:
            print(f"❌ Error: {e}")
        finally:
            # Restore original validation method
            scraper._is_price_reasonable = original_method
        
        print("\n" + "=" * 60)
        time.sleep(2)  # Delay between requests


def save_raw_html_for_analysis():
    """Save the raw HTML for manual inspection."""
    print("\n💾 SAVING RAW HTML FOR MANUAL ANALYSIS")
    print("=" * 50)
    
    scraper = SimpleBrowserScraper()
    url = get_cardmarket_url(12345, "Demonic Tutor", "Alpha", 'direct')
    
    try:
        # Get raw response
        import requests
        from requests.adapters import HTTPAdapter
        from urllib3.util.retry import Retry
        
        session = requests.Session()
        retry_strategy = Retry(total=3, backoff_factor=1)
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        
        print(f"Fetching: {url}")
        response = session.get(url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            # Save raw HTML
            with open('debug_demonic_tutor_raw.html', 'w', encoding='utf-8') as f:
                f.write(response.text)
            print("✅ Raw HTML saved to: debug_demonic_tutor_raw.html")
            print("💡 You can manually search for price patterns in this file")
        else:
            print(f"❌ Failed to fetch: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Error saving HTML: {e}")


if __name__ == "__main__":
    debug_demonic_tutor_parsing()
    save_raw_html_for_analysis()
    
    print("\n🎯 SUMMARY:")
    print("This script shows exactly what prices are being parsed and where")
    print("suspicious low prices come from. Check the output above for details.")
