#!/usr/bin/env python3
"""Test script to scrape card image from CardMarket."""

import os
import sys
import requests
from bs4 import BeautifulSoup
from fetch_live_listings_simple import SimpleBrowserScraper

def scrape_card_image(url: str, save_dir: str = "card_images"):
    """
    Scrape card image from a CardMarket product page.
    
    Args:
        url: CardMarket product URL
        save_dir: Directory to save images
        
    Returns:
        Path to saved image or None
    """
    print(f"🎯 Scraping card image from: {url}\n")
    
    # Create save directory
    os.makedirs(save_dir, exist_ok=True)
    
    # Use the existing scraper to fetch the page
    scraper = SimpleBrowserScraper(delay_range=(3.0, 5.0), max_retries=1)
    response = scraper._make_realistic_request(url)
    
    if not response:
        print("❌ Failed to get response")
        return None
    
    html_content = response.text
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # Look for the card image
    # Primary: <img> with alt attribute containing card name and class="is-front"
    # Also check data-echo attribute for lazy-loaded images
    
    image_urls = []
    
    # Method 1: Find img with class="is-front" (main product image)
    main_images = soup.find_all('img', class_='is-front')
    print(f"🔍 Found {len(main_images)} images with class='is-front'")
    
    for img in main_images:
        # Check both src and data-echo
        img_url = img.get('src') or img.get('data-echo')
        alt_text = img.get('alt', '')
        
        if img_url and 'product-images.s3.cardmarket.com' in img_url:
            print(f"   ✅ Found card image: {alt_text}")
            print(f"      URL: {img_url}")
            image_urls.append((img_url, alt_text))
    
    if not image_urls:
        print("❌ No card images found")
        return None
    
    # Use the first product image found
    img_url, alt_text = image_urls[0]
    
    # Extract card name from URL for filename
    card_name = alt_text if alt_text else url.split('/')[-1].split('?')[0]
    
    # Download the image with proper headers
    print(f"\n📥 Downloading image...")
    try:
        # Use browser headers to avoid 403 Forbidden
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Referer': 'https://www.cardmarket.com/',
            'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        }
        img_response = requests.get(img_url, headers=headers, timeout=10)
        img_response.raise_for_status()
        
        # Determine file extension
        ext = img_url.split('.')[-1].split('?')[0]
        if ext not in ['jpg', 'jpeg', 'png', 'gif']:
            ext = 'jpg'
        
        # Save the image
        filename = f"{card_name}.{ext}"
        filepath = os.path.join(save_dir, filename)
        
        with open(filepath, 'wb') as f:
            f.write(img_response.content)
        
        print(f"✅ Saved image: {filepath}")
        print(f"   Size: {len(img_response.content)} bytes")
        
        return filepath
        
    except Exception as e:
        print(f"❌ Error downloading image: {e}")
        return None

if __name__ == "__main__":
    # Test URL
    test_url = "https://www.cardmarket.com/en/Magic/Products/Singles/Legends/Planar-Gate?language=1&minCondition=3"
    
    if len(sys.argv) > 1:
        test_url = sys.argv[1]
    
    result = scrape_card_image(test_url)
    
    if result:
        print(f"\n🎉 Success! Image saved to: {result}")
    else:
        print(f"\n❌ Failed to scrape image")
