#!/usr/bin/env python3
"""
Test fetching a specific card to debug scraping issues.
"""

import sys
from fetch_live_listings_simple import SimpleBrowserScraper


def test_fetch(url, save_images=False):
    """Test fetching a single card."""
    print(f"🎯 Testing: {url}\n")
    
    scraper = SimpleBrowserScraper(delay_range=(3.0, 5.0), max_retries=2, save_images=save_images)
    listings = scraper.fetch_listings(url, max_listings=10)
    
    if listings:
        print(f"\n✅ SUCCESS! Found {len(listings)} listings\n")
        print("Top listings:")
        for i, listing in enumerate(sorted(listings, key=lambda x: x.price)[:5], 1):
            print(f"  {i}. €{listing.price:6.2f} - {listing.condition:2s} - {listing.seller}")
    else:
        print("\n❌ FAILED - No listings found")
        print("\nCheck debug_html/ directory for saved HTML")


if __name__ == "__main__":
    save_images = "--save-images" in sys.argv or "-i" in sys.argv
    
    # Remove flags from argv
    args = [arg for arg in sys.argv[1:] if not arg.startswith('-')]
    
    if args:
        url = args[0]
    else:
        # Default: the card that failed
        url = "https://www.cardmarket.com/en/Magic/Products/Singles/Tempest/Humility?language=1&minCondition=3"
    
    test_fetch(url, save_images=save_images)

