#!/usr/bin/env python3
"""Debug Tolarian Academy fetching."""

import sys
from fetch_live_listings_simple import SimpleBrowserScraper

def test_fetch(url, save_images=False):
    """Test fetching a specific URL."""
    print(f"🧪 Testing URL: {url}\n")
    
    scraper = SimpleBrowserScraper(delay_range=(1.0, 2.0), max_retries=1, save_images=save_images)
    
    listings = scraper.fetch_listings(url, max_listings=10)
    
    if listings:
        print(f"\n✅ Successfully fetched {len(listings)} listings:")
        for i, listing in enumerate(listings[:5], 1):
            print(f"  {i}. €{listing.price} - {listing.condition} - {listing.seller}")
    else:
        print("\n❌ Failed to fetch listings")
    
    return listings

if __name__ == "__main__":
    print("=" * 80)
    print("TOLARIAN ACADEMY DEBUG TEST")
    print("=" * 80)
    
    # Test different URL formats
    urls_to_test = [
        # Direct URL (likely redirects to multi-version page)
        ("Direct URL", "https://www.cardmarket.com/en/Magic/Products/Singles/Urzas-Saga/Tolarian-Academy?language=1&minCondition=3"),
        
        # Try V-1
        ("V-1", "https://www.cardmarket.com/en/Magic/Products/Singles/Urzas-Saga/Tolarian-Academy-V-1?language=1&minCondition=3"),
        
        # Try V-2
        ("V-2", "https://www.cardmarket.com/en/Magic/Products/Singles/Urzas-Saga/Tolarian-Academy-V-2?language=1&minCondition=3"),
        
        # Try without filters (might show different page structure)
        ("No filters", "https://www.cardmarket.com/en/Magic/Products/Singles/Urzas-Saga/Tolarian-Academy"),
    ]
    
    for name, url in urls_to_test:
        print(f"\n{'='*80}")
        print(f"Testing: {name}")
        print(f"{'='*80}")
        test_fetch(url, save_images=False)
        print("\n")
