#!/usr/bin/env python3
"""
Debug Howling Mine text extraction to see the exact HTML content being parsed.
"""

import re
from fetch_live_listings_simple import SimpleBrowserScraper
from mtg_arbitrage.utils import get_cardmarket_url


def debug_text_extraction():
    """Debug the exact text being extracted from HTML."""
    print("🔍 DEBUGGING HOWLING MINE TEXT EXTRACTION")
    print("=" * 60)
    
    # Create a custom scraper that shows us the raw text
    class DebugScraper(SimpleBrowserScraper):
        def _parse_modern_listing_row(self, row):
            """Override to show debug info."""
            try:
                cells = row.find_all(['td', 'div'])
                row_text = row.get_text(' ', strip=True)
                
                print(f"\n🔍 RAW ROW TEXT:")
                print(f"'{row_text}'")
                
                # Test all our price patterns
                price_patterns = [
                    (r'€\s*(\d{1,3}(?:\.\d{3})*,\d{2})', "European full format"),
                    (r'(\d{1,3}(?:\.\d{3})*,\d{2})\s*€', "European full format (€ after)"),
                    (r'€\s*(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)', "European flexible"),
                    (r'(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*€', "European flexible (€ after)"),
                    (r'€\s*(\d+[.,]\d+)', "Simple format"),
                    (r'(\d+[.,]\d+)\s*€', "Simple format (€ after)")
                ]
                
                found_any = False
                for pattern, description in price_patterns:
                    matches = re.findall(pattern, row_text)
                    if matches:
                        found_any = True
                        print(f"✅ {description}: {matches}")
                        
                        for match in matches:
                            # Show conversion process
                            original = match
                            if '.' in match and ',' in match:
                                converted = match.replace('.', '').replace(',', '.')
                                print(f"   '{original}' → '{converted}' → €{float(converted):.2f}")
                            elif ',' in match:
                                converted = match.replace(',', '.')
                                print(f"   '{original}' → '{converted}' → €{float(converted):.2f}")
                            else:
                                print(f"   '{original}' → €{float(original):.2f}")
                
                if not found_any:
                    print("❌ No price patterns matched")
                
                # Look for any number sequences that might be prices
                all_numbers = re.findall(r'\d+[.,]\d+', row_text)
                if all_numbers:
                    print(f"🔢 All number sequences found: {all_numbers}")
                
                # Call original method to get the actual result
                return super()._parse_modern_listing_row(row)
                
            except Exception as e:
                print(f"❌ Error in debug: {e}")
                return None
    
    # Use debug scraper
    scraper = DebugScraper()
    url = get_cardmarket_url(12345, 'Howling Mine', 'Alpha', 'direct')
    
    print(f"URL: {url}")
    print("\n" + "="*60)
    
    try:
        listings = scraper.fetch_listings(url, max_listings=3)  # Just first 3 for debug
        
        if listings:
            print(f"\n📊 FINAL RESULTS:")
            for i, listing in enumerate(listings, 1):
                print(f"{i}. €{listing.price:.2f} - {listing.condition} - {listing.seller}")
        
    except Exception as e:
        print(f"❌ Error: {e}")


if __name__ == "__main__":
    debug_text_extraction()
