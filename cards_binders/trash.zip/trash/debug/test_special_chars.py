#!/usr/bin/env python3
"""Test script to debug cards with special characters (accents, apostrophes)."""

import sys
import unicodedata
from fetch_live_listings_simple import SimpleBrowserScraper

def normalize_text(text):
    """Remove accents from text."""
    nfd = unicodedata.normalize('NFD', text)
    ascii_text = ''.join(char for char in nfd if not unicodedata.combining(char))
    return ascii_text

def test_card(card_name, expansion):
    """Test different URL formats for a card."""
    
    print(f"\n{'='*80}")
    print(f"🎯 Testing: {card_name} from {expansion}")
    print(f"{'='*80}")
    print(f"   Original name: {repr(card_name)}")
    print(f"   No accents: {repr(normalize_text(card_name))}")
    
    # Build normalized versions
    normalized = normalize_text(card_name).replace("'", "")
    exp_normalized = normalize_text(expansion).replace("'", "")
    
    # Test different URL formats
    test_urls = [
        # Original format (CardMarket usually uses Title-Case)
        f"https://www.cardmarket.com/en/Magic/Products/Singles/{exp_normalized.replace(' ', '-')}/{normalized.replace(' ', '-')}?language=1&minCondition=3",
        
        # With V-1 suffix
        f"https://www.cardmarket.com/en/Magic/Products/Singles/{exp_normalized.replace(' ', '-')}/{normalized.replace(' ', '-')}-V-1?language=1&minCondition=3",
        
        # Search approach
        f"https://www.cardmarket.com/en/Magic/Products/Search?searchString={normalized.replace(' ', '+')}&language=1&minCondition=3",
    ]
    
    scraper = SimpleBrowserScraper(delay_range=(2.0, 3.0), max_retries=1)
    
    for i, url in enumerate(test_urls, 1):
        print(f"\n--- Test {i}/{len(test_urls)} ---")
        print(f"URL: ...{url[50:]}")
        
        listings = scraper.fetch_listings(url, max_listings=5)
        
        if listings:
            print(f"✅ SUCCESS! Found {len(listings)} listings")
            for j, listing in enumerate(listings[:3], 1):
                print(f"   {j}. €{listing.price:.2f} - {listing.condition} - {listing.seller}")
            return url
        else:
            print(f"❌ Failed")
    
    print(f"\n❌ All URL formats failed for {card_name}")
    return None

def main():
    """Test multiple problematic cards."""
    
    test_cards = [
        ("Ifh-Bíff Efreet", "Arabian Nights"),
        ("Yawgmoth's Will", "Urza's Saga"),
        ("Tawnos's Coffin", "Antiquities"),
    ]
    
    results = {}
    
    for card_name, expansion in test_cards:
        successful_url = test_card(card_name, expansion)
        results[card_name] = successful_url
        
        # Add delay between cards to avoid rate limiting
        if test_cards.index((card_name, expansion)) < len(test_cards) - 1:
            import time
            print(f"\n⏱️  Waiting 5s before next card...")
            time.sleep(5)
    
    print(f"\n{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}")
    for card_name, url in results.items():
        if url:
            print(f"✅ {card_name:20} - Working")
        else:
            print(f"❌ {card_name:20} - Failed")

if __name__ == "__main__":
    main()
