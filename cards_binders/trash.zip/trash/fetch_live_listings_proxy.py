#!/usr/bin/env python3
"""
Fetch real-time listing data from Cardmarket using proxy rotation.

This approach uses rotating proxies and realistic headers to bypass blocking,
providing a faster alternative to Selenium for live listings scraping.
"""

import requests
from bs4 import BeautifulSoup
import time
import json
import random
import sys
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, asdict
import re


@dataclass
class FetchResult:
    """Result from fetching Cardmarket listings."""
    listings: List['LiveListing']
    available_items_total: Optional[int] = None  # Total available on Cardmarket (liquidity indicator)


@dataclass
class LiveListing:
    """Represents a live listing from Cardmarket."""
    price: float
    condition: str
    seller: str
    seller_country: str = "Unknown"
    seller_rating: Optional[float] = None
    seller_sales: Optional[int] = None
    language: str = "Unknown"
    quantity: int = 1
    foil: bool = False
    shipping: Optional[float] = None


class ProxyCardmarketScraper:
    """Cardmarket scraper using proxy rotation and realistic headers."""
    
    def __init__(self, delay_range: tuple = (1.0, 3.0)):
        """
        Initialize the proxy scraper.
        
        Args:
            delay_range: Random delay range between requests (min, max) seconds
        """
        self.delay_range = delay_range
        self.session = requests.Session()
        
        # Realistic headers that rotate
        self.user_agents = [
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0'
        ]
        
        # Load proxy configuration
        self.working_proxies = self._load_working_proxies()
        if not self.working_proxies:
            print("⚠️  No working proxies configured. Run: python proxy_config.py create")
        
        self.current_proxy = None
        
    def _get_random_headers(self) -> dict:
        """Get randomized realistic headers."""
        return {
            'User-Agent': random.choice(self.user_agents),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9,de;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Cache-Control': 'max-age=0'
        }
    
    def _load_working_proxies(self) -> List[dict]:
        """Load working proxies from configuration."""
        try:
            with open('working_proxies.json', 'r') as f:
                data = json.load(f)
                return data.get('working_proxies', [])
        except FileNotFoundError:
            return []
        except Exception as e:
            print(f"⚠️  Error loading working proxies: {e}")
            return []
    
    def _get_working_proxy(self) -> Optional[dict]:
        """Get a working proxy from available sources."""
        if not self.working_proxies:
            return None
        
        # Randomly select from working proxies
        proxy_info = random.choice(self.working_proxies)
        return proxy_info.get('config')
    
    def _test_proxy(self, proxy: dict) -> bool:
        """Test if a proxy is working."""
        try:
            response = requests.get('https://httpbin.org/ip', 
                                  proxies=proxy, 
                                  timeout=10,
                                  headers=self._get_random_headers())
            return response.status_code == 200
        except:
            return False
    
    def _make_request(self, url: str, max_retries: int = 3) -> Optional[requests.Response]:
        """Make a request with proxy rotation and retries."""
        
        for attempt in range(max_retries):
            try:
                # Random delay
                delay = random.uniform(*self.delay_range)
                time.sleep(delay)
                
                # Get headers
                headers = self._get_random_headers()
                
                # Try with proxy first
                proxy = self._get_working_proxy()
                if proxy:
                    print(f"🔄 Attempt {attempt + 1}: Using proxy...")
                    response = self.session.get(url, 
                                              headers=headers, 
                                              proxies=proxy,
                                              timeout=15)
                else:
                    # Fallback to direct connection with good headers
                    print(f"🔄 Attempt {attempt + 1}: Direct connection...")
                    response = self.session.get(url, 
                                              headers=headers,
                                              timeout=15)
                
                if response.status_code == 200:
                    return response
                elif response.status_code == 403:
                    print(f"⚠️  403 Forbidden on attempt {attempt + 1}")
                    continue
                else:
                    print(f"⚠️  Status {response.status_code} on attempt {attempt + 1}")
                    continue
                    
            except requests.RequestException as e:
                print(f"⚠️  Request error on attempt {attempt + 1}: {e}")
                continue
        
        return None
    
    def fetch_listings(self, url: str, max_listings: int = 20) -> FetchResult:
        """
        Fetch live listings from a Cardmarket product page.
        
        Args:
            url: The Cardmarket product URL
            max_listings: Maximum number of listings to fetch
            
        Returns:
            FetchResult with listings and available_items_total (liquidity indicator)
        """
        print(f"🔍 Fetching listings from: {url}")
        
        response = self._make_request(url)
        
        if not response:
            print("❌ Failed to fetch page after all retries")
            return FetchResult(listings=[], available_items_total=None)
        
        try:
            soup = BeautifulSoup(response.content, 'html.parser')
            listings = self._parse_listings_table(soup, max_listings)
            available_items = self._extract_available_items(soup)
            
            print(f"✅ Found {len(listings)} listings")
            if available_items:
                print(f"📊 Total available on Cardmarket: {available_items}")
            
            return FetchResult(listings=listings, available_items_total=available_items)
            
        except Exception as e:
            print(f"❌ Error parsing listings: {e}")
            return FetchResult(listings=[], available_items_total=None)
    
    def _extract_available_items(self, soup: BeautifulSoup) -> Optional[int]:
        """Extract 'Available items' count from the product info panel."""
        try:
            # Method 1: Look for the text pattern "Available items X" in the page
            page_text = soup.get_text()
            match = re.search(r'Available\s+items\s+(\d+)', page_text, re.IGNORECASE)
            if match:
                return int(match.group(1))
            
            # Method 2: Look for specific HTML structures
            # Try finding dt/dd pairs or table rows
            for dt in soup.find_all(['dt', 'th', 'label']):
                if 'available' in dt.get_text().lower() and 'items' in dt.get_text().lower():
                    # Find the corresponding value
                    dd = dt.find_next(['dd', 'td', 'span'])
                    if dd:
                        value_text = dd.get_text(strip=True)
                        value_match = re.search(r'(\d+)', value_text)
                        if value_match:
                            return int(value_match.group(1))
            
            # Method 3: Look in info sections
            info_sections = soup.select('.info-list, .product-info, [class*="info"]')
            for section in info_sections:
                text = section.get_text()
                match = re.search(r'Available\s+items\s*[:\s]*(\d+)', text, re.IGNORECASE)
                if match:
                    return int(match.group(1))
            
            return None
            
        except Exception as e:
            print(f"⚠️  Could not extract available items count: {e}")
            return None
    
    def _parse_listings_table(self, soup: BeautifulSoup, max_listings: int) -> List[LiveListing]:
        """Parse the listings table from Cardmarket HTML."""
        listings = []
        
        # Debug: Save HTML for inspection
        try:
            with open('debug_cardmarket.html', 'w', encoding='utf-8') as f:
                f.write(str(soup.prettify()))
            print("💾 Saved HTML to debug_cardmarket.html for inspection")
        except:
            pass
        
        # Look for common Cardmarket table patterns
        table_selectors = [
            'table.table-striped',
            'table[data-table="offers"]',
            '.offers-table',
            'table.offers',
            '#offersTable',
            'table.table',
            '.table-responsive table',
            '[data-testid*="offers"] table'
        ]
        
        listings_table = None
        for selector in table_selectors:
            listings_table = soup.select_one(selector)
            if listings_table:
                print(f"📋 Found listings table with selector: {selector}")
                break
        
        if not listings_table:
            print("⚠️  Could not find listings table")
            
            # Debug: Show available tables
            tables = soup.find_all('table')
            print(f"🔍 Found {len(tables)} table(s) on page:")
            for i, table in enumerate(tables[:5]):  # Show first 5
                classes = table.get('class', [])
                id_attr = table.get('id', '')
                data_attrs = [f"{k}={v}" for k, v in table.attrs.items() if k.startswith('data-')]
                print(f"  Table {i+1}: classes={classes}, id='{id_attr}', data={data_attrs}")
            
            # Try to find price elements as fallback
            price_elements = soup.find_all(text=re.compile(r'€\s*\d+[.,]\d+'))
            if price_elements:
                print(f"💰 Found {len(price_elements)} price elements - manual parsing needed")
            
            return listings
        
        # Parse table rows
        rows = listings_table.find_all('tr')[1:]  # Skip header row
        print(f"📊 Parsing {len(rows)} table rows...")
        
        for i, row in enumerate(rows[:max_listings]):
            try:
                listing = self._parse_listing_row(row)
                if listing and listing.price > 0:
                    listings.append(listing)
                    print(f"  ✅ Row {i+1}: €{listing.price:.2f} - {listing.condition} - {listing.seller}")
                else:
                    print(f"  ⚠️  Row {i+1}: Could not parse or invalid data")
            except Exception as e:
                print(f"  ❌ Row {i+1}: Parse error - {e}")
                continue
        
        return listings
    
    def _parse_listing_row(self, row) -> Optional[LiveListing]:
        """Parse a single listing row."""
        cells = row.find_all(['td', 'th'])
        row_text = row.get_text(' ', strip=True)
        
        if len(cells) < 3:
            return None
        
        try:
            # Price extraction
            price = 0.0
            
            # Look for price patterns in row text and individual cells
            price_patterns = [
                r'€\s*(\d+[.,]\d+)',
                r'(\d+[.,]\d+)\s*€',
                r'\$\s*(\d+[.,]\d+)',
                r'(\d+[.,]\d+)\s*\$'
            ]
            
            for pattern in price_patterns:
                matches = re.findall(pattern, row_text)
                if matches:
                    price_str = matches[0].replace(',', '.')
                    price = float(price_str)
                    break
            
            if price <= 0:
                # Try individual cells
                for cell in cells:
                    cell_text = cell.get_text(strip=True)
                    for pattern in price_patterns:
                        match = re.search(pattern, cell_text)
                        if match:
                            price_str = match.group(1).replace(',', '.')
                            price = float(price_str)
                            break
                    if price > 0:
                        break
            
            # Condition extraction
            condition = "Unknown"
            condition_keywords = ['mint', 'nm', 'near mint', 'excellent', 'ex', 'good', 'gd', 
                                'light played', 'lp', 'played', 'pl', 'poor', 'po']
            
            for keyword in condition_keywords:
                if keyword in row_text.lower():
                    # Find the actual condition text
                    for cell in cells:
                        cell_text = cell.get_text(strip=True)
                        if keyword in cell_text.lower():
                            condition = cell_text
                            break
                    break
            
            # Seller extraction
            seller = "Unknown"
            # Look for links that might be seller profiles
            seller_links = row.find_all('a', href=True)
            for link in seller_links:
                href = link.get('href', '')
                if 'user' in href.lower() or 'seller' in href.lower():
                    seller = link.get_text(strip=True)
                    break
            
            # If no seller link found, try to extract from text
            if seller == "Unknown":
                # Seller names are often in specific cells or have certain patterns
                for cell in cells:
                    cell_text = cell.get_text(strip=True)
                    # Skip cells with prices, conditions, or other known data
                    if (cell_text and 
                        not re.search(r'[€$]\s*\d+', cell_text) and
                        not any(cond in cell_text.lower() for cond in condition_keywords) and
                        len(cell_text) > 2 and len(cell_text) < 50):
                        seller = cell_text
                        break
            
            # Language extraction
            language = "Unknown"
            lang_keywords = ['english', 'german', 'french', 'italian', 'spanish', 'japanese']
            for lang in lang_keywords:
                if lang in row_text.lower():
                    language = lang.capitalize()
                    break
            
            # Quantity extraction
            quantity = 1
            qty_match = re.search(r'(\d+)\s*x', row_text.lower())
            if qty_match:
                quantity = int(qty_match.group(1))
            
            # Foil detection
            foil = 'foil' in row_text.lower()
            
            return LiveListing(
                price=price,
                condition=condition,
                seller=seller,
                language=language,
                quantity=quantity,
                foil=foil
            )
            
        except Exception as e:
            print(f"⚠️  Error parsing listing row: {e}")
            return None


def main():
    """Test the proxy scraper."""
    if len(sys.argv) > 1:
        test_url = sys.argv[1]
    else:
        test_url = "https://www.cardmarket.com/en/Magic/Products/Singles/Alpha/Animate-Artifact?sellerCountry=7&language=1&minCondition=3"
    
    print("🃏 Cardmarket Live Listings Scraper (Proxy)")
    print("=" * 60)
    print(f"🎯 Target: {test_url}")
    print()
    print("💡 This version uses:")
    print("   - Rotating user agents")
    print("   - Realistic browser headers")
    print("   - Proxy rotation (configure your proxies)")
    print("   - Random delays between requests")
    print()
    
    scraper = ProxyCardmarketScraper(delay_range=(2.0, 4.0))
    result = scraper.fetch_listings(test_url, max_listings=15)
    listings = result.listings
    
    if listings:
        print("\n📊 LIVE LISTINGS FOUND!")
        print("=" * 40)
        
        # Sort by price
        sorted_listings = sorted(listings, key=lambda x: x.price)
        
        for i, listing in enumerate(sorted_listings, 1):
            foil_indicator = " (Foil)" if listing.foil else ""
            print(f"{i:2d}. €{listing.price:6.2f} - {listing.condition:12} - {listing.seller}{foil_indicator}")
            if listing.quantity > 1:
                print(f"     Quantity: {listing.quantity}")
        
        # Analysis
        prices = [l.price for l in listings if l.price > 0]
        if prices:
            print(f"\n💰 PRICE ANALYSIS:")
            print(f"   Cheapest: €{min(prices):.2f}")
            print(f"   Most expensive: €{max(prices):.2f}")
            print(f"   Average: €{sum(prices)/len(prices):.2f}")
        
        # Save results
        output_data = {
            "url": test_url,
            "timestamp": time.time(),
            "listings": [asdict(listing) for listing in sorted_listings],
            "analysis": {
                "total_listings": len(listings),
                "available_items_total": result.available_items_total,
                "cheapest": min(prices) if prices else 0,
                "most_expensive": max(prices) if prices else 0,
                "average": sum(prices)/len(prices) if prices else 0
            }
        }
        
        output_file = f"data/live_listings_proxy_{int(time.time())}.json"
        try:
            import os
            os.makedirs('data', exist_ok=True)
            with open(output_file, 'w') as f:
                json.dump(output_data, f, indent=2)
            print(f"\n💾 Results saved to: {output_file}")
        except Exception as e:
            print(f"⚠️  Could not save results: {e}")
    
    else:
        print("❌ No listings found")
        print("\n🔧 Next steps:")
        print("1. Check debug_cardmarket.html to see the actual page structure")
        print("2. Configure working proxies in the script")
        print("3. Adjust table selectors based on HTML structure")
        print("4. Consider using paid proxy services for better success rate")
        
        print("\n🌐 Recommended proxy services:")
        print("   - BrightData (residential proxies)")
        print("   - SmartProxy (datacenter + residential)")
        print("   - Oxylabs (premium quality)")


if __name__ == "__main__":
    main()
