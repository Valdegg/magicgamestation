# Debug HTML System

This system automatically saves HTML responses when scraping fails, making it easier to debug and fix parsing issues.

## How It Works

When the scraper encounters issues, it automatically saves debug information to the `debug_html/` directory:

### File Types

1. **HTML files** (`YYYYMMDD_HHMMSS_cardname_status.html`)
   - Contains the full HTML response with debug metadata
   - Saved for: successful responses, parsing failures, blocked responses, etc.

2. **Info files** (`YYYYMMDD_HHMMSS_cardname_status.txt`)
   - Contains request metadata when HTML can't be decoded
   - Includes response headers, status codes, error messages

3. **Summary log** (`debug_summary.log`)
   - Running log of all debug saves
   - Easy to grep for patterns

### Status Types

- `success` - HTML saved successfully but may have other issues
- `no_listings_found` - HTML parsed but no listings found
- `parsing_failed` - Exception during HTML parsing
- `decompression_failed` - Brotli/gzip decompression failed
- `decode_failed` - Could not decode response at all
- `not_cardmarket` - Response doesn't appear to be from Cardmarket
- `blocked` - Response indicates blocking/forbidden

## Debug Analysis

Run the analysis script to understand patterns:

```bash
python analyze_debug_html.py
```

This will:
- Count failures by type and card
- Identify common error patterns
- Analyze HTML structure for parsing issues
- Suggest potential fixes

## Manual Investigation

1. **Check recent failures:**
   ```bash
   tail -20 debug_html/debug_summary.log
   ```

2. **Find specific card issues:**
   ```bash
   ls debug_html/*demonic-tutor*
   ```

3. **Look for blocked responses:**
   ```bash
   grep -l "blocked\|forbidden" debug_html/*.html
   ```

4. **Analyze HTML structure:**
   - Open HTML files in browser
   - Search for price patterns: `€`, `EUR`, `price`
   - Look for table structures, article rows, etc.

## Common Issues and Fixes

### No Listings Found
- HTML structure may have changed
- Check for new CSS classes/selectors
- Verify the page actually has listings

### Decompression Failed
- Brotli encoding issues
- May need updated decompression libraries
- Consider using different Accept-Encoding headers

### Blocked/Forbidden
- Anti-bot measures triggered
- Need better headers/user agents
- Consider proxy rotation
- Add delays between requests

### Parsing Failed
- BeautifulSoup parsing errors
- HTML may be malformed
- Try different parsers (lxml, html.parser)

## Improving the Scraper

Based on debug files, you can:

1. **Update selectors** in `_parse_listings_table()`
2. **Improve headers** in the request setup
3. **Add retry logic** for specific error types
4. **Implement fallback parsing** for different page layouts
5. **Add authentication** if login is required

## Cleanup

Debug files can accumulate quickly. Clean up periodically:

```bash
# Remove files older than 7 days
find debug_html -name "*.html" -mtime +7 -delete
find debug_html -name "*.txt" -mtime +7 -delete
```
